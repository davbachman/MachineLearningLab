Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
let fs = require("fs");
let path = require("path");
//#region src/data/decisionTreeDatasets.ts
var defaultDecisionTreeClasses = [{
	label: "Did not pass",
	color: "#b95f43"
}, {
	label: "Passed",
	color: "#1c7b8a"
}];
var hoursFeature = {
	id: "hours",
	label: "Study hours"
};
var decisionTreeDatasets = {
	giniWarmup: {
		id: "giniWarmup",
		kind: "giniWarmup",
		label: "Compare impurity levels from class counts",
		classes: defaultDecisionTreeClasses,
		features: [],
		nodes: [
			{
				id: "a",
				label: "Node A",
				counts: {
					negative: 4,
					positive: 0
				}
			},
			{
				id: "b",
				label: "Node B",
				counts: {
					negative: 3,
					positive: 1
				}
			},
			{
				id: "c",
				label: "Node C",
				counts: {
					negative: 2,
					positive: 2
				}
			},
			{
				id: "d",
				label: "Node D",
				counts: {
					negative: 1,
					positive: 3
				}
			}
		]
	},
	splitScore: {
		id: "splitScore",
		kind: "splitScore",
		label: "Score one proposed threshold split",
		classes: defaultDecisionTreeClasses,
		features: [hoursFeature],
		split: {
			featureId: "hours",
			threshold: 4.5
		},
		rows: [
			{
				id: "A",
				features: { hours: 1 },
				label: 0
			},
			{
				id: "B",
				features: { hours: 2 },
				label: 0
			},
			{
				id: "C",
				features: { hours: 3 },
				label: 1
			},
			{
				id: "D",
				features: { hours: 4 },
				label: 0
			},
			{
				id: "E",
				features: { hours: 6 },
				label: 1
			},
			{
				id: "F",
				features: { hours: 7 },
				label: 1
			},
			{
				id: "G",
				features: { hours: 8 },
				label: 1
			},
			{
				id: "H",
				features: { hours: 9 },
				label: 0
			}
		]
	},
	bestThreshold: {
		id: "bestThreshold",
		kind: "bestThreshold",
		label: "Choose the best threshold for one feature",
		classes: defaultDecisionTreeClasses,
		features: [hoursFeature],
		candidateSplits: [
			{
				id: "hours-2-5",
				featureId: "hours",
				threshold: 2.5
			},
			{
				id: "hours-3-5",
				featureId: "hours",
				threshold: 3.5
			},
			{
				id: "hours-5-5",
				featureId: "hours",
				threshold: 5.5
			},
			{
				id: "hours-6-5",
				featureId: "hours",
				threshold: 6.5
			}
		],
		rows: [
			{
				id: "A",
				features: { hours: 1 },
				label: 0
			},
			{
				id: "B",
				features: { hours: 2 },
				label: 0
			},
			{
				id: "C",
				features: { hours: 3 },
				label: 0
			},
			{
				id: "D",
				features: { hours: 4 },
				label: 1
			},
			{
				id: "E",
				features: { hours: 5 },
				label: 1
			},
			{
				id: "F",
				features: { hours: 6 },
				label: 1
			},
			{
				id: "G",
				features: { hours: 7 },
				label: 0
			},
			{
				id: "H",
				features: { hours: 8 },
				label: 1
			}
		]
	},
	bestRootSplit: {
		id: "bestRootSplit",
		kind: "bestRootSplit",
		label: "Compare root splits across two features",
		classes: defaultDecisionTreeClasses,
		features: [hoursFeature, {
			id: "attendance",
			label: "Attendance"
		}],
		candidateSplits: [
			{
				id: "hours-5-5",
				featureId: "hours",
				threshold: 5.5
			},
			{
				id: "hours-7-5",
				featureId: "hours",
				threshold: 7.5
			},
			{
				id: "hours-9-5",
				featureId: "hours",
				threshold: 9.5
			},
			{
				id: "attendance-77",
				featureId: "attendance",
				threshold: 77
			},
			{
				id: "attendance-81",
				featureId: "attendance",
				threshold: 81
			},
			{
				id: "attendance-85",
				featureId: "attendance",
				threshold: 85
			}
		],
		rows: [
			{
				id: "A",
				features: {
					hours: 1,
					attendance: 86
				},
				label: 1
			},
			{
				id: "B",
				features: {
					hours: 2,
					attendance: 72
				},
				label: 1
			},
			{
				id: "C",
				features: {
					hours: 3,
					attendance: 65
				},
				label: 0
			},
			{
				id: "D",
				features: {
					hours: 4,
					attendance: 90
				},
				label: 1
			},
			{
				id: "E",
				features: {
					hours: 5,
					attendance: 78
				},
				label: 0
			},
			{
				id: "F",
				features: {
					hours: 6,
					attendance: 84
				},
				label: 1
			},
			{
				id: "G",
				features: {
					hours: 7,
					attendance: 69
				},
				label: 0
			},
			{
				id: "H",
				features: {
					hours: 8,
					attendance: 88
				},
				label: 1
			},
			{
				id: "I",
				features: {
					hours: 9,
					attendance: 76
				},
				label: 0
			},
			{
				id: "J",
				features: {
					hours: 10,
					attendance: 82
				},
				label: 0
			},
			{
				id: "K",
				features: {
					hours: 11,
					attendance: 74
				},
				label: 0
			},
			{
				id: "L",
				features: {
					hours: 12,
					attendance: 92
				},
				label: 0
			}
		]
	},
	visualSplit: {
		id: "visualSplit",
		kind: "visualSplit",
		label: "Place one axis-aligned split on a scatterplot",
		classes: defaultDecisionTreeClasses,
		features: [{
			id: "x",
			label: "Feature x"
		}, {
			id: "y",
			label: "Feature y"
		}],
		candidateSplits: [
			{
				id: "x-1-5",
				featureId: "x",
				threshold: 1.5
			},
			{
				id: "x-2-5",
				featureId: "x",
				threshold: 2.5
			},
			{
				id: "x-3-5",
				featureId: "x",
				threshold: 3.5
			},
			{
				id: "x-4-5",
				featureId: "x",
				threshold: 4.5
			},
			{
				id: "x-5-5",
				featureId: "x",
				threshold: 5.5
			},
			{
				id: "x-6-5",
				featureId: "x",
				threshold: 6.5
			},
			{
				id: "x-7-5",
				featureId: "x",
				threshold: 7.5
			},
			{
				id: "y-1-5",
				featureId: "y",
				threshold: 1.5
			},
			{
				id: "y-2-5",
				featureId: "y",
				threshold: 2.5
			},
			{
				id: "y-3-5",
				featureId: "y",
				threshold: 3.5
			},
			{
				id: "y-4-5",
				featureId: "y",
				threshold: 4.5
			},
			{
				id: "y-5-5",
				featureId: "y",
				threshold: 5.5
			},
			{
				id: "y-6-5",
				featureId: "y",
				threshold: 6.5
			}
		],
		rows: [
			{
				id: "A",
				features: {
					x: 1,
					y: 2
				},
				label: 0
			},
			{
				id: "B",
				features: {
					x: 2,
					y: 1
				},
				label: 0
			},
			{
				id: "C",
				features: {
					x: 2,
					y: 5
				},
				label: 0
			},
			{
				id: "D",
				features: {
					x: 3,
					y: 3
				},
				label: 0
			},
			{
				id: "E",
				features: {
					x: 4,
					y: 2
				},
				label: 0
			},
			{
				id: "F",
				features: {
					x: 6,
					y: 1
				},
				label: 0
			},
			{
				id: "G",
				features: {
					x: 3,
					y: 6
				},
				label: 1
			},
			{
				id: "H",
				features: {
					x: 4,
					y: 5
				},
				label: 1
			},
			{
				id: "I",
				features: {
					x: 5,
					y: 3
				},
				label: 1
			},
			{
				id: "J",
				features: {
					x: 6,
					y: 4
				},
				label: 1
			},
			{
				id: "K",
				features: {
					x: 7,
					y: 2
				},
				label: 1
			},
			{
				id: "L",
				features: {
					x: 7,
					y: 6
				},
				label: 1
			},
			{
				id: "M",
				features: {
					x: 8,
					y: 4
				},
				label: 1
			},
			{
				id: "N",
				features: {
					x: 8,
					y: 7
				},
				label: 1
			}
		],
		bounds: {
			minX: 0,
			maxX: 9,
			minY: 0,
			maxY: 8
		}
	},
	visualDepthTwo: {
		id: "visualDepthTwo",
		kind: "visualDepthTwo",
		label: "Build two greedy splits from a scatterplot",
		classes: defaultDecisionTreeClasses,
		features: [{
			id: "x",
			label: "Feature x"
		}, {
			id: "y",
			label: "Feature y"
		}],
		rootCandidates: [
			{
				id: "x-2-5",
				featureId: "x",
				threshold: 2.5
			},
			{
				id: "x-3-5",
				featureId: "x",
				threshold: 3.5
			},
			{
				id: "x-4-5",
				featureId: "x",
				threshold: 4.5
			},
			{
				id: "x-5-5",
				featureId: "x",
				threshold: 5.5
			}
		],
		rightChildCandidates: [
			{
				id: "y-2-5",
				featureId: "y",
				threshold: 2.5
			},
			{
				id: "y-3-5",
				featureId: "y",
				threshold: 3.5
			},
			{
				id: "y-4-5",
				featureId: "y",
				threshold: 4.5
			},
			{
				id: "x-6-5",
				featureId: "x",
				threshold: 6.5
			}
		],
		rows: [
			{
				id: "A",
				features: {
					x: 1,
					y: 2
				},
				label: 0
			},
			{
				id: "B",
				features: {
					x: 2,
					y: 5
				},
				label: 0
			},
			{
				id: "C",
				features: {
					x: 3,
					y: 3
				},
				label: 0
			},
			{
				id: "D",
				features: {
					x: 4,
					y: 6
				},
				label: 0
			},
			{
				id: "E",
				features: {
					x: 6,
					y: 2
				},
				label: 0
			},
			{
				id: "F",
				features: {
					x: 7,
					y: 3
				},
				label: 0
			},
			{
				id: "G",
				features: {
					x: 2,
					y: 1
				},
				label: 1
			},
			{
				id: "H",
				features: {
					x: 4,
					y: 2
				},
				label: 1
			},
			{
				id: "I",
				features: {
					x: 5,
					y: 1
				},
				label: 1
			},
			{
				id: "J",
				features: {
					x: 5,
					y: 4
				},
				label: 1
			},
			{
				id: "K",
				features: {
					x: 6,
					y: 5
				},
				label: 1
			},
			{
				id: "L",
				features: {
					x: 7,
					y: 6
				},
				label: 1
			},
			{
				id: "M",
				features: {
					x: 8,
					y: 4
				},
				label: 1
			},
			{
				id: "N",
				features: {
					x: 8,
					y: 7
				},
				label: 1
			}
		],
		bounds: {
			minX: 0,
			maxX: 9,
			minY: 0,
			maxY: 8
		}
	},
	depthTwo: {
		id: "depthTwo",
		kind: "depthTwo",
		label: "Complete the second split of a depth-2 tree",
		classes: defaultDecisionTreeClasses,
		features: [hoursFeature, {
			id: "quiz",
			label: "Practice quiz"
		}],
		rootCandidates: [
			{
				id: "hours-3-5",
				featureId: "hours",
				threshold: 3.5
			},
			{
				id: "hours-5-5",
				featureId: "hours",
				threshold: 5.5
			},
			{
				id: "hours-6-5",
				featureId: "hours",
				threshold: 6.5
			}
		],
		rightChildCandidates: [
			{
				id: "quiz-5",
				featureId: "quiz",
				threshold: 5
			},
			{
				id: "quiz-6",
				featureId: "quiz",
				threshold: 6
			},
			{
				id: "hours-6-5",
				featureId: "hours",
				threshold: 6.5
			}
		],
		rows: [
			{
				id: "A",
				features: {
					hours: 1,
					quiz: 2
				},
				label: 0
			},
			{
				id: "B",
				features: {
					hours: 2,
					quiz: 3
				},
				label: 0
			},
			{
				id: "C",
				features: {
					hours: 3,
					quiz: 2
				},
				label: 0
			},
			{
				id: "D",
				features: {
					hours: 4,
					quiz: 8
				},
				label: 1
			},
			{
				id: "E",
				features: {
					hours: 5,
					quiz: 4
				},
				label: 0
			},
			{
				id: "F",
				features: {
					hours: 6,
					quiz: 7
				},
				label: 1
			},
			{
				id: "G",
				features: {
					hours: 7,
					quiz: 6
				},
				label: 0
			},
			{
				id: "H",
				features: {
					hours: 8,
					quiz: 9
				},
				label: 1
			}
		]
	}
};
//#endregion
//#region src/lib/decisionTreeMath.ts
function giniFromCounts(counts) {
	const total = counts.negative + counts.positive;
	if (total === 0) return 0;
	const negativeRatio = counts.negative / total;
	const positiveRatio = counts.positive / total;
	return 1 - negativeRatio ** 2 - positiveRatio ** 2;
}
function countClasses(rows) {
	return rows.reduce((counts, row) => row.label === 1 ? {
		...counts,
		positive: counts.positive + 1
	} : {
		...counts,
		negative: counts.negative + 1
	}, {
		negative: 0,
		positive: 0
	});
}
function evaluateNode(rows) {
	const counts = countClasses(rows);
	return {
		rows,
		counts,
		gini: giniFromCounts(counts)
	};
}
function evaluateSplit(rows, split) {
	const leftRows = rows.filter((row) => row.features[split.featureId] <= split.threshold);
	const rightRows = rows.filter((row) => row.features[split.featureId] > split.threshold);
	const parent = evaluateNode(rows);
	const left = evaluateNode(leftRows);
	const right = evaluateNode(rightRows);
	const total = rows.length || 1;
	const weightedGini = left.rows.length / total * left.gini + right.rows.length / total * right.gini;
	return {
		split,
		parent,
		left,
		right,
		weightedGini,
		gain: parent.gini - weightedGini
	};
}
function findBestSplit(rows, candidateSplits) {
	const [firstSplit, ...remainingSplits] = candidateSplits;
	if (!firstSplit) throw new Error("findBestSplit requires at least one candidate split.");
	return remainingSplits.reduce((best, split) => {
		const next = evaluateSplit(rows, split);
		return next.weightedGini < best.weightedGini ? next : best;
	}, evaluateSplit(rows, firstSplit));
}
//#endregion
//#region src/lib/codeLab.ts
function validateCodeLabStage(stage, answers) {
	const missingFieldIds = stage.fields.filter((field) => (answers === null || answers === void 0 ? void 0 : answers[field.id]) === void 0).map((field) => field.id);
	const incorrectFieldIds = stage.fields.filter((field) => (answers === null || answers === void 0 ? void 0 : answers[field.id]) !== void 0 && answers[field.id] !== field.correctOptionId).map((field) => field.id);
	return {
		correct: missingFieldIds.length === 0 && incorrectFieldIds.length === 0,
		missingFieldIds,
		incorrectFieldIds
	};
}
function validateCodeLabSubmission(question, submission) {
	if (!submission || typeof submission !== "object") return {
		correct: false,
		message: "No structured Code Lab submission was provided."
	};
	const payload = submission;
	if (payload.formatVersion !== 1 || payload.questionId !== question.id || payload.variantId !== question.variantId || !payload.stages) return {
		correct: false,
		message: "The Code Lab question ID, variant ID, or format version does not match."
	};
	const failedStage = question.stages.find((stage) => {
		var _payload$stages;
		return !validateCodeLabStage(stage, (_payload$stages = payload.stages) === null || _payload$stages === void 0 ? void 0 : _payload$stages[stage.id]).correct;
	});
	return failedStage ? {
		correct: false,
		message: `At least one answer in ${failedStage.id} is missing or incorrect.`
	} : {
		correct: true,
		message: "Every Code Lab stage is correct."
	};
}
function defineCodeLabQuestion(input) {
	return {
		...input,
		validator: (submission) => validateCodeLabSubmission(input, submission)
	};
}
var kmeansNotebookLab = defineCodeLabQuestion({
	id: "kmeans-code-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace the k-Means Implementation",
	prompt: "Use the completed `2Kmeans.ipynb` notebook to answer questions about its center calculation, squared-distance matrix, cluster assignments, prediction, and cluster-by-target confusion matrix.",
	instructions: "The displayed definitions reproduce the notebook implementations. The trace sets `model.centers` directly so that you can analyze `predict` without running the random initialization and convergence loop in `fit`.",
	datasetId: "kmeans-notebook-v1",
	variantId: "kmeans-notebook-v1",
	language: "python",
	code: `import numpy as np

def centers_from_labels(data,labels):
    width=data.shape[1]
    height=len(np.bincount(labels))
    centers=np.zeros((height,width))
    for i in range(height):
        centers[i,:]=np.mean(data[labels==i],axis=0)
    return centers

def sq_distances(data,centers):
  k=len(centers)
  n=len(data)
  distances=np.zeros((n,k))
  for i in range(k):
    distances[:,i]=np.sum((data-centers[i,:])**2,axis=1)
  return distances

def labels_from_centers(data,centers):
  distances=sq_distances(data,centers)
  return np.argmin(distances,axis=1)  # S1

class KMeans():
    def __init__(self,k):
        self.k=k #Record the hyperparameter

    def fit(self,data):
        rng = np.random.default_rng(seed=1)#Define random number generator. Set seed only for gradescope!
        self.centers=rng.choice(data,size=self.k,replace=False,axis=0) #Choose 10 centers randomly
        labels=labels_from_centers(data,self.centers) #Decide which center each point is closest to
        diff=10
        while diff!=0: #Do this until labeling doesn't change
            old_labels=labels
            self.centers=centers_from_labels(data,labels) #Find center of each cluster
            labels=labels_from_centers(data,self.centers) #update labels based on closest center
            diff=np.sum((old_labels-labels)**2) #measure if labeling has changed
            print(diff) #Watch the algorithm converge!

    def predict(self,x):
        return labels_from_centers(x,self.centers) #Prediction is based on which center is closest

def confusion_matrix(clusters,target,k):
  matrix=np.zeros((k,k))
  for i in range(k):
    for j in range(k):
      matrix[i,j]=np.sum((clusters==i) & (target==j))
  return matrix`,
	fixtureTitle: "Small deterministic trace input",
	fixtureHeading: "Trace input",
	fixture: `data = np.array([
    [0.0, 0.0],
    [2.0, 0.0],
    [8.0, 0.0],
    [10.0, 0.0],
])
labels = np.array([0, 0, 1, 1])
queries = np.array([
    [0.0, 0.0],
    [5.0, 0.0],
    [10.0, 0.0],
])
targets = np.array([0, 1, 1, 1])`,
	invocationTitle: "Statements to trace",
	invocationLead: "After the definitions and trace input run, Python evaluates:",
	invocation: `centers = centers_from_labels(data, labels)
distances = sq_distances(queries, centers)
assigned = labels_from_centers(data, centers)
matrix = confusion_matrix(labels, targets, 2)

model = KMeans(2)
model.centers = centers
prediction = model.predict(np.array([
    [5.0, 0.0],
    [10.0, 0.0],
]))`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"`sq_distances` returns one row per query and one column per center.",
		"The two computed centers are the coordinate-wise means of the points with labels 0 and 1.",
		"`np.argmin(..., axis=1)` selects one center-column index for every data row and resolves a tie by choosing the first minimum."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the completed notebook",
			prompt: "Mentally execute the displayed statements through the completed `2Kmeans.ipynb` functions.",
			successCopy: "Correct: the label means are `[1, 0]` and `[9, 0]`; the middle query is equally far from them, so `argmin` assigns it to cluster 0.",
			fields: [
				{
					id: "CENTERS",
					label: "centers.tolist()",
					correctOptionId: "CENTERS_MEANS",
					options: [
						{
							id: "CENTERS_MEANS",
							label: "[[1.0, 0.0], [9.0, 0.0]]"
						},
						{
							id: "CENTERS_ENDPOINTS",
							label: "[[0.0, 0.0], [10.0, 0.0]]"
						},
						{
							id: "CENTERS_INNER",
							label: "[[2.0, 0.0], [8.0, 0.0]]"
						}
					]
				},
				{
					id: "DISTANCES",
					label: "distances.tolist()",
					correctOptionId: "DISTANCES_SQUARED",
					options: [
						{
							id: "DISTANCES_SQUARED",
							label: "[[1.0, 81.0], [16.0, 16.0], [81.0, 1.0]]"
						},
						{
							id: "DISTANCES_UNSQUARED",
							label: "[[1.0, 9.0], [4.0, 4.0], [9.0, 1.0]]"
						},
						{
							id: "DISTANCES_TRANSPOSED",
							label: "[[1.0, 16.0, 81.0], [81.0, 16.0, 1.0]]"
						}
					]
				},
				{
					id: "ASSIGNED",
					label: "assigned.tolist()",
					correctOptionId: "ASSIGNED_BALANCED",
					options: [
						{
							id: "ASSIGNED_BALANCED",
							label: "[0, 0, 1, 1]"
						},
						{
							id: "ASSIGNED_LEFT_HEAVY",
							label: "[0, 0, 0, 1]"
						},
						{
							id: "ASSIGNED_RIGHT_HEAVY",
							label: "[0, 1, 1, 1]"
						}
					]
				},
				{
					id: "MATRIX",
					label: "matrix.tolist()",
					correctOptionId: "MATRIX_CLUSTER_ROWS",
					options: [
						{
							id: "MATRIX_CLUSTER_ROWS",
							label: "[[1.0, 1.0], [0.0, 2.0]]"
						},
						{
							id: "MATRIX_TRANSPOSED",
							label: "[[1.0, 0.0], [1.0, 2.0]]"
						},
						{
							id: "MATRIX_PURE",
							label: "[[2.0, 0.0], [0.0, 2.0]]"
						}
					]
				},
				{
					id: "PREDICTION",
					label: "prediction.tolist()",
					correctOptionId: "PREDICT_FIRST_TIE",
					options: [
						{
							id: "PREDICT_FIRST_TIE",
							label: "[0, 1]"
						},
						{
							id: "PREDICT_RIGHT_TIE",
							label: "[1, 1]"
						},
						{
							id: "PREDICT_LEFT_ONLY",
							label: "[0, 0]"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Read a changed notebook line",
			prompt: "Suppose S1 in `labels_from_centers` is changed from `np.argmin(distances,axis=1)` to `np.argmin(distances,axis=0)`. Using the displayed `data` and computed `centers`, what does the changed function return?",
			successCopy: "Correct: reducing along axis 0 returns one data-row index for each center. Ties select the first matching rows, 0 and 2.",
			fields: [{
				id: "MUTATED_RESULT",
				label: "labels_from_centers(data, centers).tolist() after the change",
				correctOptionId: "ROWS_PER_CENTER",
				options: [
					{
						id: "ROWS_PER_CENTER",
						label: "[0, 2]"
					},
					{
						id: "CENTER_PER_ROW",
						label: "[0, 0, 1, 1]"
					},
					{
						id: "CENTER_INDICES",
						label: "[0, 1]"
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which executable test passes for the notebook implementation but fails after the `axis=1` to `axis=0` mutation?",
			successCopy: "Correct: the reference returns one label for each of four rows, `[0, 0, 1, 1]`; the mutation instead returns the two row indices `[0, 3]`.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "FOUR_ROWS_TWO_CENTERS",
				options: [
					{
						id: "FOUR_ROWS_TWO_CENTERS",
						label: "Require one label for each of four rows",
						description: "`X = np.array([[0., 0.], [1., 0.], [9., 0.], [10., 0.]]); C = np.array([[0., 0.], [10., 0.]]); assert labels_from_centers(X, C).tolist() == [0, 0, 1, 1]`"
					},
					{
						id: "TWO_ROWS_TWO_CENTERS",
						label: "Use the centers themselves as two rows",
						description: "`X = np.array([[0., 0.], [10., 0.]]); C = X.copy(); assert labels_from_centers(X, C).tolist() == [0, 1]`"
					},
					{
						id: "DISTANCE_SHAPE",
						label: "Check only the distance-matrix shape",
						description: "`X = np.array([[0., 0.], [1., 0.], [9., 0.], [10., 0.]]); C = np.array([[0., 0.], [10., 0.]]); assert sq_distances(X, C).shape == (4, 2)`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "`sq_distances` has one row per data point and one column per center. The notebook uses `axis=1` to select a center for every row. The mutation uses `axis=0` and instead selects a row for every center. A useful distinguishing test therefore uses different numbers of data rows and centers." },
	successCopy: "Notebook Lab complete: center calculation, distance tracing, cluster assignment, and mutation testing are all correct."
});
//#endregion
//#region src/data/codeLabQuestions.ts
var numpyNotebookCode = `import numpy as np

X = np.ones((100, 10))  # S1
y = np.arange(1, 1001)  # S2
Y = y.reshape((100, 10))  # S3
z = y[:, np.newaxis]  # S4
A = Y[0:5, 2:6]  # S5
b = Y[(Y % 3 == 0) & (Y > 20) & (Y < 70)]  # S6
Z = np.sqrt(Y) + X  # S7
m = Y.max(axis=0)  # S8
s = Y.sum(axis=1)  # S9
P = np.matmul(X, Y.T)  # S10`;
var pcaCode = `import numpy as np

class PCA():
    def __init__(self, n_components):
        self.n_components = n_components

    def fit(self, X):
        centeredX = X - X.mean(axis=0)  # S1
        CVmatrix = centeredX.T @ centeredX / centeredX.shape[0]  # S2
        eigvals, eigvecs = np.linalg.eig(CVmatrix)  # S3
        indices = np.argsort(eigvals)[::-1]  # S4
        self.basis = eigvecs[:, indices[0:self.n_components]]  # S5

    def transform(self, X):
        centeredX = X - X.mean(axis=0)  # S6
        return centeredX @ self.basis  # S7

    def fit_transform(self, X):
        self.fit(X)
        return self.transform(X)  # S8`;
var kmeansCode = `import numpy as np

def lloyd_step(X, centroids):
    differences = X[:, None] - centroids[None, :]
    squared = (differences ** 2).sum(axis=2)  # S1
    labels = squared.argmin(axis=1)  # S2
    updated = centroids.copy()  # S3
    for cluster_id in range(len(centroids)):
        members = X[labels == cluster_id]  # S4
        if len(members) > 0:  # S5
            updated[cluster_id] = members.mean(axis=0)  # S6
    return labels, updated  # S7`;
var knnCode = `import numpy as np
from sklearn.datasets import load_iris

class KNeighborsClassifier():
    def __init__(self, k):
        self.n_neighbors = k  # S1

    def fit(self, X, y):
        self.X = X  # S2
        self.y = y  # S3

    def sq_distances(self, length, width):
        return (
            (self.X[:, 0] - length) ** 2
            + (self.X[:, 1] - width) ** 2
        )  # S4

    def SpeciesOfNeighbors(self, length, width):
        distances = self.sq_distances(length, width)
        indices = distances.argsort()[:self.n_neighbors]  # S5
        specieslist = self.y[indices]  # S6
        return specieslist

    def majority(self, labels):
        return np.bincount(labels).argmax()  # S7

    def predict(self, length, width):
        return self.majority(
            self.SpeciesOfNeighbors(length, width)
        )  # S8`;
var knnEvaluationCode = `from sklearn.neighbors import KNeighborsClassifier

def predict_labels(train_data, train_target, test_data, k):
    knn = KNeighborsClassifier(k)  # S1
    knn.fit(train_data, train_target)  # S2
    return knn.predict(test_data)  # S3

def accuracy(train_data, train_target, test_data, test_target, k):
    predictions = predict_labels(
        train_data, train_target, test_data, k
    )  # S4
    correct = (predictions == test_target).sum()  # S5
    return correct / len(predictions)  # S6`;
var decisionTreeCode = `import numpy as np

def Gini(labels):
    return 1 - ((np.bincount(labels) / len(labels)) ** 2).sum()  # S1

def GiniSplit(X, y, split_feature, split_threshold):
    num = len(y)
    mask = X[:, split_feature] >= split_threshold  # S2
    num_right = len(y[mask])
    num_left = num - num_right
    return (
        num_left * Gini(y[~mask]) + num_right * Gini(y[mask])
    ) / num  # S3

def BestSplit(X, y):
    num_obs, num_features = X.shape
    split_feature = 0
    split_threshold = 0
    minGini = 1
    for feat in range(num_features):
        vals = np.unique(X[:, feat])
        thresholds = (vals[1:] + vals[:-1]) / 2  # S4
        for thresh in thresholds:
            splitval = GiniSplit(X, y, feat, thresh)
            if splitval < minGini:  # S5
                minGini = splitval
                split_feature = feat
                split_threshold = thresh
    return split_feature, split_threshold  # S6

class Node():
    def __init__(self, X, y, depth, max_depth):
        self.leaf = depth == max_depth or len(np.unique(y)) == 1
        if self.leaf:
            self.label = np.bincount(y).argmax()  # S7
        else:
            self.split_feature, self.split_threshold = BestSplit(X, y)
            mask = X[:, self.split_feature] >= self.split_threshold
            self.right = Node(X[mask], y[mask], depth + 1, max_depth)
            self.left = Node(X[~mask], y[~mask], depth + 1, max_depth)

    def predict(self, x):
        if self.leaf:
            return self.label
        if x[self.split_feature] >= self.split_threshold:  # S8
            return self.right.predict(x)
        return self.left.predict(x)`;
var randomForestCode = `import numpy as np
from sklearn.tree import DecisionTreeClassifier

class RandomForestClassifier():
    def __init__(self, max_depth, n_estimators):
        self.max_depth = max_depth
        self.n_estimators = n_estimators

    def fit(self, X, y):
        self.trees = []
        for i in range(self.n_estimators):
            rows, cols = X.shape
            np.random.seed(i)  # S1
            samples = np.random.choice(range(rows), rows, replace=True)  # S2
            features = np.random.choice(
                range(cols), int(np.sqrt(cols)), replace=False
            )  # S3
            tree = DecisionTreeClassifier(max_depth=self.max_depth)
            tree.fit(X[samples][:, features], y[samples])  # S4
            self.trees.append((tree, features))  # S5

    def predict(self, x):
        preds = []
        for i in range(self.n_estimators):
            tree, feats = self.trees[i]
            preds.append(tree.predict(x[np.newaxis, feats])[0])  # S6
        return np.bincount(np.array(preds)).argmax()  # S7`;
var numpyNotebookLab = defineCodeLabQuestion({
	id: "numpy-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace the NumPy Arrays",
	prompt: "Use the completed `0Numpy.ipynb` notebook to answer questions about its array construction, slicing, Boolean masks, reductions, and matrix multiplication.",
	instructions: "The code below reproduces the completed notebook cells in their original order, with statement labels added for reference. Read each expression using NumPy row and column conventions.",
	datasetId: "numpy-notebook-v1",
	variantId: "numpy-notebook-v1",
	language: "python",
	code: numpyNotebookCode,
	fixtureTitle: "Notebook execution context",
	fixtureHeading: "Execution rule",
	fixture: `# Run S1 through S10 once, from top to bottom.
# No variables are reassigned after S10.`,
	invocationTitle: "Expressions to trace",
	invocationLead: "After the notebook cells S1 through S10 run, Python evaluates:",
	invocation: `array_shape = Y.shape
column_shape = z.shape
slice_value = A[3, 3]
filtered_values = b.tolist()
summary = (Z[5, 5], m[5], s[5])
matrix_summary = (P.shape, P[5, 5])`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"`reshape` fills rows from the one-dimensional array in order, while `np.newaxis` adds a length-one dimension without changing the values.",
		"The two coordinates in `A[3, 3]` are relative to the sliced array `A`, not to the original array `Y`.",
		"For S10, write the two matrix shapes after applying `.T`, then match the inner dimensions before calculating an entry."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the completed notebook",
			prompt: "Mentally execute the displayed expressions after running S1 through S10.",
			successCopy: "Correct: reshaping preserves the value order, the mask retains the multiples of three from 21 through 69, and each entry in row 5 of P is a dot product with one row of Y.",
			fields: [
				{
					id: "ARRAY_SHAPE",
					label: "array_shape",
					correctOptionId: "SHAPE_100_10",
					options: [
						{
							id: "SHAPE_100_10",
							label: "(100, 10)"
						},
						{
							id: "SHAPE_10_100",
							label: "(10, 100)"
						},
						{
							id: "SHAPE_1000",
							label: "(1000,)"
						}
					]
				},
				{
					id: "COLUMN_SHAPE",
					label: "column_shape",
					correctOptionId: "SHAPE_1000_1",
					options: [
						{
							id: "SHAPE_1000_1",
							label: "(1000, 1)"
						},
						{
							id: "SHAPE_1_1000",
							label: "(1, 1000)"
						},
						{
							id: "SHAPE_1000",
							label: "(1000,)"
						}
					]
				},
				{
					id: "SLICE_VALUE",
					label: "slice_value",
					correctOptionId: "VALUE_36",
					options: [
						{
							id: "VALUE_36",
							label: "36"
						},
						{
							id: "VALUE_34",
							label: "34"
						},
						{
							id: "VALUE_46",
							label: "46"
						}
					]
				},
				{
					id: "FILTERED_VALUES",
					label: "filtered_values",
					correctOptionId: "MULTIPLES_21_TO_69",
					options: [
						{
							id: "MULTIPLES_21_TO_69",
							label: "[21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60, 63, 66, 69]"
						},
						{
							id: "MULTIPLES_24_TO_69",
							label: "[24, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60, 63, 66, 69]"
						},
						{
							id: "MULTIPLES_21_TO_66",
							label: "[21, 24, 27, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60, 63, 66]"
						}
					]
				},
				{
					id: "SUMMARY",
					label: "summary",
					correctOptionId: "SUMMARY_8_483_996_555",
					options: [
						{
							id: "SUMMARY_8_483_996_555",
							label: "(8.483314773547882, 996, 555)"
						},
						{
							id: "SUMMARY_7_483_60_50100",
							label: "(7.483314773547883, 60, 50100)"
						},
						{
							id: "SUMMARY_8_416_995_545",
							label: "(8.416198487095663, 995, 545)"
						}
					]
				},
				{
					id: "MATRIX_SUMMARY",
					label: "matrix_summary",
					correctOptionId: "MATRIX_100_100_555",
					options: [
						{
							id: "MATRIX_100_100_555",
							label: "((100, 100), 555.0)"
						},
						{
							id: "MATRIX_10_10_50100",
							label: "((10, 10), 50100.0)"
						},
						{
							id: "MATRIX_100_10_56",
							label: "((100, 10), 56.0)"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Read a changed matrix product",
			prompt: "Suppose S10 were changed to `P = np.matmul(X.T, Y)`, leaving every other statement unchanged. What would `matrix_summary` become?",
			successCopy: "Correct: the changed product has shape `(10, 100) @ (100, 10) = (10, 10)`. Its entry at `[5, 5]` is the sum of column 5 of Y, which is 50100.",
			fields: [{
				id: "CHANGED_MATRIX_SUMMARY",
				label: "matrix_summary after the change",
				correctOptionId: "CHANGED_10_10_50100",
				options: [
					{
						id: "CHANGED_10_10_50100",
						label: "((10, 10), 50100.0)"
					},
					{
						id: "CHANGED_100_100_555",
						label: "((100, 100), 555.0)"
					},
					{
						id: "CHANGED_VALUE_ERROR",
						label: "a matrix-dimension ValueError"
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a comprehension check",
			prompt: "Which assertion passes for the notebook implementation but fails after S10 is changed to `np.matmul(X.T, Y)`?",
			successCopy: "Correct: the original product is 100 by 100, and its `[5, 5]` entry equals the sum of row 5 of Y. The changed product satisfies neither property.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_NOTEBOOK_PRODUCT",
				options: [
					{
						id: "TEST_NOTEBOOK_PRODUCT",
						label: "Check the product shape and a row-sum entry",
						description: "`assert P.shape == (100, 100) and P[5, 5] == s[5]`"
					},
					{
						id: "TEST_TWO_DIMENSIONS",
						label: "Check only the number of dimensions",
						description: "`assert P.ndim == 2`"
					},
					{
						id: "TEST_FLOAT_DTYPE",
						label: "Check only that the result is floating point",
						description: "`assert np.issubdtype(P.dtype, np.floating)`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The notebook reshapes the integers 1 through 1000 into 100 rows, adds a column dimension with `np.newaxis`, slices by row and column positions, filters with a combined Boolean mask, and reduces different axes for column maxima and row sums. The original matrix product uses `Y.T`, so `(100, 10) @ (10, 100)` produces a 100 by 100 matrix; changing the transpose to `X.T` instead produces a different valid 10 by 10 product." },
	successCopy: "Notebook Lab complete: construction, slicing, filtering, reductions, and matrix multiplication are all correct."
});
var pcaCodeLab = defineCodeLabQuestion({
	id: "pca-code-lab",
	kind: "codeLab",
	title: "Notebook Lab: Read the PCA Implementation",
	prompt: "Use the completed `1PCA.ipynb` notebook to answer questions about its PCA implementation and the way `fit_transform` combines its methods.",
	instructions: "The class below is the notebook implementation, reformatted only for readability. The trace matrix has a diagonal covariance matrix, so the displayed basis and projections are exact.",
	datasetId: "pca-notebook-v1",
	variantId: "pca-notebook-v1",
	language: "python",
	code: pcaCode,
	fixtureTitle: "Notebook class with a small trace matrix",
	fixture: `X_trace = np.array([
    [-2.0, 0.0],
    [ 0.0, 0.0],
    [ 2.0, 0.0],
])

pca = PCA(n_components=1)`,
	invocationTitle: "Statements to trace",
	invocation: `projected = pca.fit_transform(X_trace)

X_new = np.array([
    [10.0, 0.0],
    [12.0, 0.0],
])
new_projected = pca.transform(X_new)`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"S1 centers each column before S2 forms the covariance matrix. Here only the first column varies.",
		"`fit_transform` first creates `self.basis`, then calls `transform` on the same matrix.",
		"S6 computes the mean of the array passed to `transform`; the class does not store the mean used during `fit`."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the notebook methods",
			prompt: "Mentally execute the displayed statements through the completed notebook class.",
			successCopy: "Correct: the single principal direction is the first coordinate. `fit_transform` produces three rows, while `transform(X_new)` centers `X_new` around its own mean and produces `[-1, 1]`.",
			fields: [
				{
					id: "BASIS_SHAPE",
					label: "pca.basis.shape",
					correctOptionId: "SHAPE_2_1",
					options: [
						{
							id: "SHAPE_2_1",
							label: "(2, 1)"
						},
						{
							id: "SHAPE_1_2",
							label: "(1, 2)"
						},
						{
							id: "SHAPE_3_1",
							label: "(3, 1)"
						}
					]
				},
				{
					id: "PROJECTED",
					label: "projected.tolist()",
					correctOptionId: "PROJECTED_NEG2_0_2",
					options: [
						{
							id: "PROJECTED_NEG2_0_2",
							label: "[[-2.0], [0.0], [2.0]]"
						},
						{
							id: "PROJECTED_4_0_4",
							label: "[[4.0], [0.0], [4.0]]"
						},
						{
							id: "PROJECTED_NEG2_0",
							label: "[[-2.0, 0.0], [0.0, 0.0], [2.0, 0.0]]"
						}
					]
				},
				{
					id: "NEW_PROJECTED",
					label: "new_projected.tolist()",
					correctOptionId: "NEW_NEG1_1",
					options: [
						{
							id: "NEW_NEG1_1",
							label: "[[-1.0], [1.0]]"
						},
						{
							id: "NEW_10_12",
							label: "[[10.0], [12.0]]"
						},
						{
							id: "NEW_8_10",
							label: "[[8.0], [10.0]]"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Read a changed notebook line",
			prompt: "Suppose S6 were changed to `centeredX = X`, leaving every other line unchanged. What would `new_projected.tolist()` become?",
			successCopy: "Correct: without S6 centering, the already-fitted basis projects the raw first coordinates 10 and 12.",
			fields: [{
				id: "CHANGED_S6_EFFECT",
				label: "new_projected.tolist() after the change",
				correctOptionId: "CHANGED_10_12",
				options: [
					{
						id: "CHANGED_10_12",
						label: "[[10.0], [12.0]]"
					},
					{
						id: "CHANGED_NEG1_1",
						label: "[[-1.0], [1.0]]"
					},
					{
						id: "CHANGED_8_10",
						label: "[[8.0], [10.0]]"
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a comprehension check",
			prompt: "Which assertion passes for the notebook implementation but fails after S6 is changed to skip centering?",
			successCopy: "Correct: the notebook centers the two rows passed to `transform`, so their one-dimensional projections have mean zero.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_TRANSFORM_MEAN_ZERO",
				options: [
					{
						id: "TEST_TRANSFORM_MEAN_ZERO",
						label: "Check the mean of the transformed rows",
						description: "`assert np.allclose(pca.transform(X_new).mean(axis=0), [0.0])`"
					},
					{
						id: "TEST_OUTPUT_SHAPE",
						label: "Check only the output shape",
						description: "`assert pca.transform(X_new).shape == (2, 1)`"
					},
					{
						id: "TEST_BASIS_SHAPE",
						label: "Check only the fitted basis shape",
						description: "`assert pca.basis.shape == (2, 1)`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The notebook sorts the covariance eigenvectors by descending eigenvalue and retains `n_components` columns. Its `transform` method then centers whichever array it receives before projecting it. Thus `X_new` becomes `[[-1, 0], [1, 0]]`; skipping S6 centering instead projects the raw values 10 and 12." },
	successCopy: "Notebook Lab complete: PCA fitting, transformation, and code comprehension are all correct."
});
defineCodeLabQuestion({
	id: "kmeans-code-lab",
	kind: "codeLab",
	title: "Code Lab: Trace and Test One Lloyd Step",
	prompt: "Read `lloyd_step`, trace the values produced by both displayed statements, diagnose incorrect empty-cluster behavior, and choose an input that exposes it.",
	instructions: "Centroid indices 0 and 1 refer to rows 0 and 1 of `centroids`, even after those rows move.",
	datasetId: "kmeans-code-v4",
	variantId: "kmeans-code-v4",
	language: "python",
	code: kmeansCode,
	fixtureTitle: "Executable trace setup",
	fixture: `X = np.array([[0, 0], [2, 0], [8, 0], [10, 0]], dtype=float)
centroids = np.array([[0, 0], [7, 0]], dtype=float)`,
	invocationTitle: "Statements to trace",
	invocation: `labels, updated_centroids = lloyd_step(X, centroids)
post_objective = ((X - updated_centroids[labels]) ** 2).sum()`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"S1 stores squared distances. Taking square roots would not change the nearest-centroid labels at S2.",
		"At S6, `members` contains exactly the rows whose S2 label equals the current `cluster_id`.",
		"Choose an input for which no row’s S2 label equals one centroid index."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Predict one Lloyd step",
			prompt: "Mentally execute both displayed statements. What are `labels.tolist()`, `updated_centroids.tolist()`, and `post_objective`?",
			successCopy: "Correct: S7 returns labels `[0, 0, 1, 1]` and centroids `[[1, 0], [9, 0]]`; the second statement then gives `post_objective = 4`.",
			fields: [
				{
					id: "ASSIGNMENTS",
					label: "labels.tolist()",
					correctOptionId: "LABELS_0_0_1_1",
					options: [
						{
							id: "LABELS_0_0_1_1",
							label: "[0, 0, 1, 1]"
						},
						{
							id: "LABELS_0_1_1_1",
							label: "[0, 1, 1, 1]"
						},
						{
							id: "LABELS_0_0_0_1",
							label: "[0, 0, 0, 1]"
						}
					]
				},
				{
					id: "UPDATED_CENTROIDS",
					label: "updated_centroids.tolist()",
					correctOptionId: "CENTROIDS_1_0_9_0",
					options: [
						{
							id: "CENTROIDS_1_0_9_0",
							label: "[[1.0, 0.0], [9.0, 0.0]]"
						},
						{
							id: "CENTROIDS_0_0_7_0",
							label: "[[0.0, 0.0], [7.0, 0.0]]"
						},
						{
							id: "CENTROIDS_2_0_8_0",
							label: "[[2.0, 0.0], [8.0, 0.0]]"
						}
					]
				},
				{
					id: "POST_OBJECTIVE",
					label: "post_objective",
					correctOptionId: "OBJECTIVE_4",
					options: [
						{
							id: "OBJECTIVE_2",
							label: "2.0"
						},
						{
							id: "OBJECTIVE_4",
							label: "4.0"
						},
						{
							id: "OBJECTIVE_8",
							label: "8.0"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Diagnose the mutation",
			prompt: "Now use three centroids, with no row assigned to centroid 2. A mutant writes `[nan, nan]` into `updated[2]` instead of retaining centroid 2’s previous position. Which code change causes that result?",
			successCopy: "Correct: without the S5 guard, S6 takes the mean of an empty array and writes `[nan, nan]` into row 2.",
			fields: [{
				id: "MUTATION_ID",
				label: "Code change",
				correctOptionId: "M_REMOVE_EMPTY_GUARD",
				options: [
					{
						id: "M_REMOVE_EMPTY_GUARD",
						label: "Run S6 even when members is empty",
						description: "Delete the S5 guard and execute `updated[cluster_id] = members.mean(axis=0)` unconditionally."
					},
					{
						id: "M_USE_L1_DISTANCE",
						label: "Use Manhattan distance at S1",
						description: "Change S1 to `squared = np.abs(differences).sum(axis=2)`."
					},
					{
						id: "M_ZERO_INITIALIZATION",
						label: "Initialize updated with zeros at S3",
						description: "Change S3 to `updated = np.zeros_like(centroids)`."
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which executable test passes for the reference implementation but fails for the guard-removal mutation?",
			successCopy: "Correct: centroid 2 receives no rows. The reference keeps it at `[100, 100]`; the mutant writes `[nan, nan]`.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_EMPTY_CLUSTER",
				options: [
					{
						id: "TEST_EMPTY_CLUSTER",
						label: "Leave a third centroid unused",
						description: "`X = np.array([[0, 0], [1, 0]], dtype=float); centroids = np.array([[0, 0], [1, 0], [100, 100]], dtype=float); _, updated = lloyd_step(X, centroids); assert np.allclose(updated[2], [100, 100])`"
					},
					{
						id: "TEST_WELL_SEPARATED",
						label: "Give both centroids members",
						description: "`X = np.array([[0, 0], [1, 0], [9, 0], [10, 0]], dtype=float); centroids = np.array([[0, 0], [10, 0]], dtype=float); _, updated = lloyd_step(X, centroids); assert np.allclose(updated, [[0.5, 0], [9.5, 0]])`"
					},
					{
						id: "TEST_PERMUTED_ROWS",
						label: "Reverse the trace rows",
						description: "`X = np.array([[10, 0], [8, 0], [2, 0], [0, 0]], dtype=float); centroids = np.array([[0, 0], [7, 0]], dtype=float); _, updated = lloyd_step(X, centroids); assert np.allclose(updated, [[1, 0], [9, 0]])`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "S3 begins with a copy of every input centroid. If a cluster is empty, S5 skips S6, so that copied row remains unchanged. In the selected test, centroid 2 stays at `[100, 100]`; removing the guard replaces it with `[nan, nan]`." },
	successCopy: "Code Lab complete: trace, diagnosis, and test are all correct."
});
var knnCodeLab = defineCodeLabQuestion({
	id: "knn-code-lab",
	kind: "codeLab",
	title: "Notebook Lab: Read the k-NN Implementation",
	prompt: "Use the completed `3KNN.ipynb` notebook to answer questions about its Iris data preparation and `KNeighborsClassifier` implementation.",
	instructions: "The code below is the classifier from the notebook, reformatted only for readability. The small trace dataset uses the same column order as the notebook: petal length, then petal width.",
	datasetId: "knn-notebook-v1",
	variantId: "knn-notebook-v1",
	language: "python",
	code: knnCode,
	fixtureTitle: "Notebook context and trace input",
	fixture: `# Earlier notebook cells:
iris = load_iris()
X = iris.data
y = iris.target
X = X[:, 2:]

# Smaller data for tracing the same class:
X_trace = np.array([
    [1.0, 1.0],
    [2.0, 1.0],
    [4.0, 3.0],
    [5.0, 4.0],
])
y_trace = np.array([1, 0, 0, 2])

knn = KNeighborsClassifier(2)
knn.fit(X_trace, y_trace)`,
	invocationTitle: "Statements to trace",
	invocation: `distances = knn.sq_distances(3.0, 1.5)
neighbor_species = knn.SpeciesOfNeighbors(3.0, 1.5)
prediction = knn.predict(3.0, 1.5)`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"The original Iris feature matrix has four columns. The slice `X[:, 2:]` retains columns 2 and 3.",
		"At S5, `argsort()` returns row indices ordered from the smallest squared distance to the largest.",
		"`np.bincount(labels).argmax()` returns the most frequent nonnegative integer label."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Connect the notebook cells",
			prompt: "Read the Iris preprocessing and then trace the three displayed statements through the completed class.",
			successCopy: "Correct: the notebook retains two petal measurements per flower. On the trace data, rows 1 and 2 are nearest, both have label 0, and `predict` returns 0.",
			fields: [
				{
					id: "IRIS_X_SHAPE",
					label: "X.shape after X = X[:, 2:] in the notebook",
					correctOptionId: "SHAPE_150_2",
					options: [
						{
							id: "SHAPE_150_2",
							label: "(150, 2)"
						},
						{
							id: "SHAPE_2_150",
							label: "(2, 150)"
						},
						{
							id: "SHAPE_150_4",
							label: "(150, 4)"
						}
					]
				},
				{
					id: "IRIS_X_COLUMNS",
					label: "columns remaining in X after the slice",
					correctOptionId: "PETAL_LENGTH_WIDTH",
					options: [
						{
							id: "PETAL_LENGTH_WIDTH",
							label: "petal length, petal width"
						},
						{
							id: "SEPAL_LENGTH_WIDTH",
							label: "sepal length, sepal width"
						},
						{
							id: "SEPAL_WIDTH_PETAL_LENGTH",
							label: "sepal width, petal length"
						}
					]
				},
				{
					id: "DISTANCES",
					label: "distances.tolist()",
					correctOptionId: "DISTANCES_4_25_1_25_3_25_10_25",
					options: [
						{
							id: "DISTANCES_4_25_1_25_3_25_10_25",
							label: "[4.25, 1.25, 3.25, 10.25]"
						},
						{
							id: "DISTANCES_2_0625_1_118_1_803_3_202",
							label: "[2.062, 1.118, 1.803, 3.202]"
						},
						{
							id: "DISTANCES_10_25_3_25_1_25_4_25",
							label: "[10.25, 3.25, 1.25, 4.25]"
						}
					]
				},
				{
					id: "NEIGHBOR_SPECIES",
					label: "neighbor_species.tolist()",
					correctOptionId: "SPECIES_0_0",
					options: [
						{
							id: "SPECIES_0_0",
							label: "[0, 0]"
						},
						{
							id: "SPECIES_1_2",
							label: "[1, 2]"
						},
						{
							id: "SPECIES_0_0_1_2",
							label: "[0, 0, 1, 2]"
						}
					]
				},
				{
					id: "PREDICTION",
					label: "prediction",
					correctOptionId: "PREDICTION_0",
					options: [
						{
							id: "PREDICTION_0",
							label: "0"
						},
						{
							id: "PREDICTION_1",
							label: "1"
						},
						{
							id: "PREDICTION_2",
							label: "2"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Read a changed notebook line",
			prompt: "Suppose S5 used `distances.argsort()[-self.n_neighbors:]` instead of `distances.argsort()[:self.n_neighbors]`. What would the changed class do on the trace input?",
			successCopy: "Correct: the negative slice keeps the final two sorted indices, so the changed class selects the two farthest rows. Their labels are [1, 2], and `argmax()` breaks the 1–1 tie in favor of label 1.",
			fields: [{
				id: "CHANGED_SLICE_EFFECT",
				label: "effect of the changed S5 slice",
				correctOptionId: "FARTHEST_LABELS_1_2_PREDICTION_1",
				options: [
					{
						id: "FARTHEST_LABELS_1_2_PREDICTION_1",
						label: "Select the two farthest rows",
						description: "`neighbor_species.tolist()` is `[1, 2]`; `prediction` is `1`."
					},
					{
						id: "REVERSE_NEAREST_LABELS_0_0_PREDICTION_0",
						label: "Reverse the same two nearest rows",
						description: "`neighbor_species.tolist()` is `[0, 0]`; `prediction` is `0`."
					},
					{
						id: "LAST_TRAINING_LABELS_0_2_PREDICTION_0",
						label: "Select the final two rows of X",
						description: "`neighbor_species.tolist()` is `[0, 2]`; `prediction` is `0`."
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a comprehension check",
			prompt: "Which assertion passes for the notebook implementation but fails after the S5 slice is changed to select the farthest rows?",
			successCopy: "Correct: checking the exact neighbor labels directly tests whether S5 keeps the beginning or the end of the sorted index array.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_EXACT_NEIGHBOR_LABELS",
				options: [
					{
						id: "TEST_EXACT_NEIGHBOR_LABELS",
						label: "Check the exact neighbor labels",
						description: "`assert knn.SpeciesOfNeighbors(3.0, 1.5).tolist() == [0, 0]`"
					},
					{
						id: "TEST_NEIGHBOR_COUNT",
						label: "Check only the number of neighbors",
						description: "`assert len(knn.SpeciesOfNeighbors(3.0, 1.5)) == 2`"
					},
					{
						id: "TEST_VALID_SPECIES_LABELS",
						label: "Check only that labels are valid",
						description: "`assert set(knn.SpeciesOfNeighbors(3.0, 1.5)) <= {0, 1, 2}`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The notebook narrows Iris to petal length and petal width, stores the fitted arrays on `self`, sorts squared distances, keeps the first k indices, and takes the majority label. On the trace data, `[:2]` selects labels `[0, 0]`, while `[-2:]` selects labels `[1, 2]`." },
	successCopy: "Notebook Lab complete: data preparation, implementation trace, and test are all correct."
});
var knnEvaluationNotebookLab = defineCodeLabQuestion({
	id: "knn-evaluation-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Evaluate and Select a k-NN Model",
	prompt: "Use the completed `4KNN.ipynb` notebook to answer questions about its train/test split, accuracy function, and selection of k.",
	instructions: "Read the NumPy operations exactly as written. In particular, `np.random.choice` samples with replacement unless `replace=False` is supplied.",
	datasetId: "knn-evaluation-notebook-v1",
	variantId: "knn-evaluation-notebook-v1",
	language: "python",
	code: knnEvaluationCode,
	fixtureTitle: "Notebook data and split cells",
	fixture: `import numpy as np
from sklearn.datasets import load_iris

iris = load_iris()
X = iris.data
y = iris.target

np.random.seed(6)
size = len(X)
test_frac = 0.2
test_size = int(size * test_frac)
test_indices = np.random.choice(np.arange(size), test_size)
test_mask = np.zeros(size, dtype=bool)
test_mask[test_indices] = True
train_mask = ~test_mask

train_data = X[train_mask]
train_target = y[train_mask]
test_data = X[test_mask]
test_target = y[test_mask]`,
	invocationTitle: "Accuracy sweep and values to inspect",
	invocation: `k = np.arange(1, 20)
accuracies = np.array([
    accuracy(train_data, train_target, test_data, test_target, i)
    for i in k
])

requested_test_size = test_size
actual_test_size = int(test_mask.sum())
actual_train_size = int(train_mask.sum())
best_position = int(accuracies.argmax())
best_k = int(k[best_position])
best_accuracy = float(accuracies[best_position])`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"The notebook requests 30 random indices, but repeated indices set the same Boolean mask entry to True more than once.",
		"`train_mask = ~test_mask` flips every Boolean value, so every row belongs to exactly one of the two masks.",
		"`argmax()` returns the zero-based position of the first maximum, not the corresponding value stored in `k`."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the notebook split",
			prompt: "For the seed and split code shown above, distinguish the requested test size from the number of distinct rows selected by the Boolean mask.",
			successCopy: "Correct: the code requests 30 indices, but three repeated draws leave 27 True entries in `test_mask`. The complementary training mask therefore contains 123 rows.",
			fields: [
				{
					id: "ORIGINAL_X_SHAPE",
					label: "X.shape in 4KNN.ipynb",
					correctOptionId: "SHAPE_150_4",
					options: [
						{
							id: "SHAPE_150_4",
							label: "(150, 4)"
						},
						{
							id: "SHAPE_150_2",
							label: "(150, 2)"
						},
						{
							id: "SHAPE_4_150",
							label: "(4, 150)"
						}
					]
				},
				{
					id: "REQUESTED_TEST_SIZE",
					label: "requested_test_size",
					correctOptionId: "REQUESTED_30",
					options: [
						{
							id: "REQUESTED_27",
							label: "27"
						},
						{
							id: "REQUESTED_30",
							label: "30"
						},
						{
							id: "REQUESTED_120",
							label: "120"
						}
					]
				},
				{
					id: "ACTUAL_TEST_SIZE",
					label: "actual_test_size",
					correctOptionId: "ACTUAL_TEST_27",
					options: [
						{
							id: "ACTUAL_TEST_27",
							label: "27"
						},
						{
							id: "ACTUAL_TEST_30",
							label: "30"
						},
						{
							id: "ACTUAL_TEST_123",
							label: "123"
						}
					]
				},
				{
					id: "ACTUAL_TRAIN_SIZE",
					label: "actual_train_size",
					correctOptionId: "ACTUAL_TRAIN_123",
					options: [
						{
							id: "ACTUAL_TRAIN_120",
							label: "120"
						},
						{
							id: "ACTUAL_TRAIN_123",
							label: "123"
						},
						{
							id: "ACTUAL_TRAIN_150",
							label: "150"
						}
					]
				},
				{
					id: "TEST_DATA_SHAPE",
					label: "test_data.shape",
					correctOptionId: "TEST_SHAPE_27_4",
					options: [
						{
							id: "TEST_SHAPE_27_4",
							label: "(27, 4)"
						},
						{
							id: "TEST_SHAPE_30_4",
							label: "(30, 4)"
						},
						{
							id: "TEST_SHAPE_123_4",
							label: "(123, 4)"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Read a changed sampling call",
			prompt: "Suppose the notebook instead used `np.random.choice(np.arange(size), test_size, replace=False)`. What would change about the split?",
			successCopy: "Correct: sampling without replacement guarantees 30 distinct test indices, leaving 120 training indices.",
			fields: [{
				id: "WITHOUT_REPLACEMENT_EFFECT",
				label: "effect of replace=False",
				correctOptionId: "EXACTLY_30_TEST_120_TRAIN",
				options: [
					{
						id: "EXACTLY_30_TEST_120_TRAIN",
						label: "30 test rows and 120 training rows",
						description: "Every sampled index is distinct before the mask is constructed."
					},
					{
						id: "STILL_27_TEST_123_TRAIN",
						label: "27 test rows and 123 training rows",
						description: "The same repeated indices would still be present."
					},
					{
						id: "EXACTLY_120_TEST_30_TRAIN",
						label: "120 test rows and 30 training rows",
						description: "The meaning of the train and test masks would be reversed."
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Interpret the accuracy sweep",
			prompt: "The notebook output has the same maximum accuracy at k = 5 and k = 11. Which assertion correctly verifies the notebook’s rule of choosing the first k that reaches the maximum?",
			successCopy: "Correct: `accuracies.argmax()` is position 4, and `k[4]` is 5. The maximum accuracy is 26/27, approximately 0.962963.",
			fields: [{
				id: "BEST_K_ASSERTION",
				label: "Assertion",
				correctOptionId: "ASSERT_FIRST_MAX_K_5",
				options: [
					{
						id: "ASSERT_FIRST_MAX_K_5",
						label: "Check the k value and maximum accuracy",
						description: "`assert k[accuracies.argmax()] == 5 and np.isclose(accuracies.max(), 26 / 27)`"
					},
					{
						id: "ASSERT_ARGMAX_POSITION_5",
						label: "Treat the array position as the k value",
						description: "`assert accuracies.argmax() == 5`"
					},
					{
						id: "ASSERT_FIRST_MAX_K_11",
						label: "Choose the later tied maximum",
						description: "`assert k[accuracies.argmax()] == 11`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "With seed 6, the 30 draws contain three repeats, so Boolean indexing produces 27 test rows and 123 training rows. The recorded accuracy array reaches 26/27 first at k = 5 and again at k = 11; NumPy `argmax()` returns the position of the first occurrence." },
	successCopy: "Notebook Lab complete: split construction, sampling behavior, and model selection are all correct."
});
var randomForestCodeLab = defineCodeLabQuestion({
	id: "rf-code-lab",
	kind: "codeLab",
	title: "Notebook Lab: Read the Random Forest Implementation",
	prompt: "Use the completed `homework5solutions.ipynb` notebook to answer questions about its seeded bootstrap samples, random feature subsets, and majority vote.",
	instructions: "The class below is the notebook implementation, reformatted only for readability. NumPy seeds make the fit trace reproducible. `FixedTree` is used only to isolate and trace the notebook’s voting code.",
	datasetId: "rf-notebook-v1",
	variantId: "rf-notebook-v1",
	language: "python",
	code: randomForestCode,
	fixtureTitle: "Small fit trace and isolated voting trace",
	fixture: `# X_trace has 5 rows and 4 feature columns.
X_trace = np.arange(20).reshape(5, 4)
y_trace = np.array([0, 0, 1, 1, 2])
forest = RandomForestClassifier(max_depth=2, n_estimators=2)

class FixedTree:
    def __init__(self, label):
        self.label = label

    def predict(self, X):
        return np.array([self.label])

voting_forest = RandomForestClassifier(max_depth=2, n_estimators=4)
voting_forest.trees = [
    (FixedTree(2), np.array([0, 2])),
    (FixedTree(1), np.array([1, 3])),
    (FixedTree(2), np.array([0, 1])),
    (FixedTree(1), np.array([2, 3])),
]`,
	invocationTitle: "Statements to trace",
	invocation: `forest.fit(X_trace, y_trace)

# The same S1-S3 statements, isolated for inspection:
np.random.seed(0)
samples_0 = np.random.choice(range(5), 5, replace=True)
features_0 = np.random.choice(range(4), 2, replace=False)

np.random.seed(1)
samples_1 = np.random.choice(range(5), 5, replace=True)
features_1 = np.random.choice(range(4), 2, replace=False)

prediction = voting_forest.predict(np.array([10, 20, 30, 40]))`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"For each tree, S1 resets NumPy’s random generator to that tree’s index before S2 and S3 draw values.",
		"`int(np.sqrt(4))` is 2, so every tree is fitted with two of the four columns.",
		"The four fixed trees vote `[2, 1, 2, 1]`. `np.bincount(...).argmax()` returns the smallest label when counts tie."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace sampling, features, and voting",
			prompt: "Read the arrays generated inside the first two fit iterations, then trace the separate `FixedTree` vote through S6 and S7.",
			successCopy: "Correct: tree 0 bootstraps `[4, 0, 3, 3, 3]` and uses columns `[0, 2]`; tree 1 bootstraps `[3, 4, 0, 1, 3]` and uses columns `[3, 2]`. The tied vote is resolved as class 1.",
			fields: [
				{
					id: "SAMPLES_0",
					label: "samples.tolist() when i == 0",
					correctOptionId: "SAMPLES_4_0_3_3_3",
					options: [
						{
							id: "SAMPLES_4_0_3_3_3",
							label: "[4, 0, 3, 3, 3]"
						},
						{
							id: "SAMPLES_0_1_2_3_4",
							label: "[0, 1, 2, 3, 4]"
						},
						{
							id: "SAMPLES_3_4_0_1_3",
							label: "[3, 4, 0, 1, 3]"
						}
					]
				},
				{
					id: "FEATURES_0",
					label: "features.tolist() when i == 0",
					correctOptionId: "FEATURES_0_2",
					options: [
						{
							id: "FEATURES_0_2",
							label: "[0, 2]"
						},
						{
							id: "FEATURES_0_1",
							label: "[0, 1]"
						},
						{
							id: "FEATURES_3_2",
							label: "[3, 2]"
						}
					]
				},
				{
					id: "SAMPLES_1",
					label: "samples.tolist() when i == 1",
					correctOptionId: "SAMPLES_3_4_0_1_3",
					options: [
						{
							id: "SAMPLES_3_4_0_1_3",
							label: "[3, 4, 0, 1, 3]"
						},
						{
							id: "SAMPLES_4_0_3_3_3",
							label: "[4, 0, 3, 3, 3]"
						},
						{
							id: "SAMPLES_1_3_4_0_2",
							label: "[1, 3, 4, 0, 2]"
						}
					]
				},
				{
					id: "FEATURES_1",
					label: "features.tolist() when i == 1",
					correctOptionId: "FEATURES_3_2",
					options: [
						{
							id: "FEATURES_3_2",
							label: "[3, 2]"
						},
						{
							id: "FEATURES_0_2",
							label: "[0, 2]"
						},
						{
							id: "FEATURES_2_3",
							label: "[2, 3]"
						}
					]
				},
				{
					id: "PREDICTION",
					label: "prediction",
					correctOptionId: "CLASS_1",
					options: [
						{
							id: "CLASS_1",
							label: "1"
						},
						{
							id: "CLASS_2",
							label: "2"
						},
						{
							id: "CLASS_NONE",
							label: "None"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Read a changed notebook line",
			prompt: "Suppose S2 used `replace=False` instead of `replace=True`. Which statement best describes the training rows selected for each tree?",
			successCopy: "Correct: drawing five indices without replacement from five rows produces a permutation, so every tree sees every row exactly once rather than a bootstrap sample with omissions and repeats.",
			fields: [{
				id: "WITHOUT_REPLACEMENT_EFFECT",
				label: "effect of replace=False at S2",
				correctOptionId: "PERMUTATION_EACH_ROW_ONCE",
				options: [
					{
						id: "PERMUTATION_EACH_ROW_ONCE",
						label: "Every row appears exactly once",
						description: "Each sample array is a permutation of `[0, 1, 2, 3, 4]`."
					},
					{
						id: "DUPLICATES_WITH_NO_OMISSIONS",
						label: "Some rows repeat but none are omitted",
						description: "The sample still contains duplicate row indices."
					},
					{
						id: "TWO_ROWS_SQRT_FIVE",
						label: "Only two rows are selected",
						description: "The row count is reduced to `int(np.sqrt(5))`."
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a comprehension check",
			prompt: "Which assertion directly verifies how the notebook resolves the 2–2 tie in the fixed-tree voting trace?",
			successCopy: "Correct: the notebook counts votes by class index, and `argmax()` returns the first maximum, so the smaller tied label 1 wins.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_TIE_BREAK",
				options: [
					{
						id: "TEST_TIE_BREAK",
						label: "Check the tied vote’s exact prediction",
						description: "`assert voting_forest.predict(np.array([10, 20, 30, 40])) == 1`"
					},
					{
						id: "TEST_VALID_CLASS",
						label: "Check only that the result is a voter label",
						description: "`assert voting_forest.predict(np.array([10, 20, 30, 40])) in {1, 2}`"
					},
					{
						id: "TEST_TREE_COUNT",
						label: "Check only the number of trees",
						description: "`assert len(voting_forest.trees) == 4`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The notebook deliberately seeds each estimator with its loop index. S2 samples rows with replacement, while S3 selects `sqrt(number of columns)` distinct features. At prediction time, the four fixed trees vote twice for class 1 and twice for class 2; `np.bincount(...).argmax()` chooses class 1 because it is the first maximum." },
	successCopy: "Notebook Lab complete: bootstrap sampling, feature subsampling, and voting are all correct."
});
var decisionTreeCodeLab = defineCodeLabQuestion({
	id: "decision-tree-code-lab",
	kind: "codeLab",
	title: "Notebook Lab: Read the Decision Tree Implementation",
	prompt: "Use the completed `homework4solutions.ipynb` notebook to answer questions about Gini impurity, split search, node construction, and prediction routing.",
	instructions: "The code below is the notebook implementation, reformatted only for readability. The small trace input follows the same NumPy array conventions as the Wine data used in the notebook.",
	datasetId: "decision-tree-notebook-v1",
	variantId: "decision-tree-notebook-v1",
	language: "python",
	code: decisionTreeCode,
	fixtureTitle: "Small trace input",
	fixture: `X_trace = np.array([
    [0.0],
    [1.0],
    [3.0],
    [4.0],
])
y_trace = np.array([0, 0, 1, 1])`,
	invocationTitle: "Statements to trace",
	invocation: `impurity = Gini(y_trace)
mask = X_trace[:, 0] >= 2.0
split_impurity = GiniSplit(X_trace, y_trace, 0, 2.0)
best_split = BestSplit(X_trace, y_trace)

root = Node(X_trace, y_trace, depth=0, max_depth=1)
left_prediction = root.predict(np.array([0.5]))
right_prediction = root.predict(np.array([2.5]))`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"The threshold 2.0 sends the final two rows to `mask` and leaves two class-0 rows on the other side.",
		"S4 tests only midpoints between successive distinct values: 0.5, 2.0, and 3.5.",
		"At S8, equality follows the `right` child because the comparison is `>=`."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the notebook functions",
			prompt: "Mentally execute the displayed statements through the completed notebook code.",
			successCopy: "Correct: the labels have impurity 0.5, threshold 2.0 makes two pure children, `BestSplit` returns `(0, 2.0)`, and the depth-one tree predicts 0 on the left and 1 on the right.",
			fields: [
				{
					id: "IMPURITY",
					label: "impurity",
					correctOptionId: "IMPURITY_0_5",
					options: [
						{
							id: "IMPURITY_0_5",
							label: "0.5"
						},
						{
							id: "IMPURITY_0_25",
							label: "0.25"
						},
						{
							id: "IMPURITY_0",
							label: "0.0"
						}
					]
				},
				{
					id: "MASK",
					label: "mask.tolist()",
					correctOptionId: "MASK_F_F_T_T",
					options: [
						{
							id: "MASK_F_F_T_T",
							label: "[False, False, True, True]"
						},
						{
							id: "MASK_T_T_F_F",
							label: "[True, True, False, False]"
						},
						{
							id: "MASK_F_F_F_T",
							label: "[False, False, False, True]"
						}
					]
				},
				{
					id: "SPLIT_IMPURITY",
					label: "split_impurity",
					correctOptionId: "SPLIT_0",
					options: [
						{
							id: "SPLIT_0",
							label: "0.0"
						},
						{
							id: "SPLIT_0_25",
							label: "0.25"
						},
						{
							id: "SPLIT_0_5",
							label: "0.5"
						}
					]
				},
				{
					id: "BEST_SPLIT",
					label: "best_split",
					correctOptionId: "BEST_0_2",
					options: [
						{
							id: "BEST_0_2",
							label: "(0, 2.0)"
						},
						{
							id: "BEST_0_0_5",
							label: "(0, 0.5)"
						},
						{
							id: "BEST_0_3_5",
							label: "(0, 3.5)"
						}
					]
				},
				{
					id: "PREDICTIONS",
					label: "left_prediction, right_prediction",
					correctOptionId: "PREDICTIONS_0_1",
					options: [
						{
							id: "PREDICTIONS_0_1",
							label: "0, 1"
						},
						{
							id: "PREDICTIONS_1_0",
							label: "1, 0"
						},
						{
							id: "PREDICTIONS_0_0",
							label: "0, 0"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Read a changed notebook line",
			prompt: "Suppose S8 used `>` instead of `>=`, without changing the split construction. What would `root.predict(np.array([2.0]))` return?",
			successCopy: "Correct: the notebook sends a value equal to the threshold right, but the changed comparison sends it left. The left leaf predicts class 0.",
			fields: [{
				id: "CHANGED_BOUNDARY_PREDICTION",
				label: "prediction at x == 2.0 after the change",
				correctOptionId: "BOUNDARY_CLASS_0",
				options: [
					{
						id: "BOUNDARY_CLASS_0",
						label: "0"
					},
					{
						id: "BOUNDARY_CLASS_1",
						label: "1"
					},
					{
						id: "BOUNDARY_ERROR",
						label: "an IndexError"
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a comprehension check",
			prompt: "Which assertion passes for the notebook implementation but fails after S8 is changed from `>=` to `>`?",
			successCopy: "Correct: only a query exactly on the learned threshold distinguishes the two routing comparisons in this tree.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_EXACT_THRESHOLD",
				options: [
					{
						id: "TEST_EXACT_THRESHOLD",
						label: "Test a query exactly on the threshold",
						description: "`assert root.predict(np.array([2.0])) == 1`"
					},
					{
						id: "TEST_LEFT_OF_THRESHOLD",
						label: "Test a query left of the threshold",
						description: "`assert root.predict(np.array([0.5])) == 0`"
					},
					{
						id: "TEST_RIGHT_OF_THRESHOLD",
						label: "Test a query right of the threshold",
						description: "`assert root.predict(np.array([2.5])) == 1`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The notebook tests midpoints between sorted distinct values and keeps the first split that strictly improves `minGini`. On the trace input, 2.0 is the unique perfect split. Node construction uses the same `>=` rule as prediction, so a query at 2.0 belongs to the right leaf and receives class 1." },
	successCopy: "Notebook Lab complete: impurity, split search, and prediction routing are all correct."
});
//#endregion
//#region src/data/decisionTreeAssignment.ts
var NUMERIC_TOLERANCE$1 = .015;
var SCORE_TIE_TOLERANCE = 1e-9;
function almostEqual(actual, expected, tolerance = NUMERIC_TOLERANCE$1) {
	return typeof actual === "number" && Math.abs(actual - expected) <= tolerance;
}
function validateGiniWarmup(datasetId) {
	const dataset = decisionTreeDatasets[datasetId];
	const answers = Object.fromEntries(dataset.nodes.map((node) => [node.id, giniFromCounts(node.counts)]));
	return (submission) => {
		var _payload$values;
		const values = (_payload$values = submission.values) !== null && _payload$values !== void 0 ? _payload$values : {};
		const correct = Object.entries(answers).every(([nodeId, answer]) => almostEqual(values[nodeId], answer));
		return {
			correct,
			message: correct ? "Correct! Good Job!" : "At least one node impurity does not match 1 - p(pass)^2 - p(not pass)^2."
		};
	};
}
function validateSplitScore(datasetId) {
	const dataset = decisionTreeDatasets[datasetId];
	const splitScore = evaluateSplit(dataset.rows, dataset.split);
	const expectedLeftRowIds = splitScore.left.rows.map((row) => row.id).sort();
	const sameRowIds = (rowIds) => {
		const submitted = [...rowIds !== null && rowIds !== void 0 ? rowIds : []].sort();
		return submitted.length === expectedLeftRowIds.length && submitted.every((rowId, index) => rowId === expectedLeftRowIds[index]);
	};
	return (submission) => {
		var _payload$counts, _payload$counts2, _payload$counts3, _payload$counts4, _payload$values2, _payload$values3;
		const payload = submission;
		const partitionCorrect = sameRowIds(payload.leftRowIds);
		if (payload.step === "partition") return {
			correct: partitionCorrect,
			message: partitionCorrect ? "Correct! Good Job!" : "Check the <= rule carefully and select every row sent to the left child."
		};
		const countsCorrect = ((_payload$counts = payload.counts) === null || _payload$counts === void 0 || (_payload$counts = _payload$counts.left) === null || _payload$counts === void 0 ? void 0 : _payload$counts.negative) === splitScore.left.counts.negative && ((_payload$counts2 = payload.counts) === null || _payload$counts2 === void 0 || (_payload$counts2 = _payload$counts2.left) === null || _payload$counts2 === void 0 ? void 0 : _payload$counts2.positive) === splitScore.left.counts.positive && ((_payload$counts3 = payload.counts) === null || _payload$counts3 === void 0 || (_payload$counts3 = _payload$counts3.right) === null || _payload$counts3 === void 0 ? void 0 : _payload$counts3.negative) === splitScore.right.counts.negative && ((_payload$counts4 = payload.counts) === null || _payload$counts4 === void 0 || (_payload$counts4 = _payload$counts4.right) === null || _payload$counts4 === void 0 ? void 0 : _payload$counts4.positive) === splitScore.right.counts.positive;
		const childGiniCorrect = almostEqual((_payload$values2 = payload.values) === null || _payload$values2 === void 0 ? void 0 : _payload$values2.left, splitScore.left.gini) && almostEqual((_payload$values3 = payload.values) === null || _payload$values3 === void 0 ? void 0 : _payload$values3.right, splitScore.right.gini);
		if (payload.step === "childStats") {
			const correct = partitionCorrect && countsCorrect && childGiniCorrect;
			return {
				correct,
				message: correct ? "Correct! Good Job!" : "Use your row partition to recount both outcomes in each child, then compute each Gini."
			};
		}
		const correct = partitionCorrect && countsCorrect && childGiniCorrect && almostEqual(payload.value, splitScore.weightedGini);
		return {
			correct,
			message: correct ? "Correct! Good Job!" : "Weight each child Gini by the fraction of rows that went to that child."
		};
	};
}
function validateBestSplit(datasetId) {
	const dataset = decisionTreeDatasets[datasetId];
	const best = findBestSplit(dataset.rows, dataset.candidateSplits);
	return (submission) => {
		const correct = submission.splitId === best.split.id;
		return {
			correct,
			message: correct ? "Correct! Good Job!" : "A different candidate has a lower weighted Gini after the split."
		};
	};
}
function validateVisualSplit(datasetId) {
	const dataset = decisionTreeDatasets[datasetId];
	const best = findBestSplit(dataset.rows, dataset.candidateSplits);
	return (submission) => {
		const payload = submission;
		if (!payload.featureId || typeof payload.threshold !== "number") return {
			correct: false,
			message: "Choose a split direction and threshold before checking."
		};
		const correct = evaluateSplit(dataset.rows, {
			featureId: payload.featureId,
			threshold: payload.threshold
		}).weightedGini <= best.weightedGini + SCORE_TIE_TOLERANCE;
		return {
			correct,
			message: correct ? "Correct! Good Job!" : "That line still mixes the two classes more than the best available split."
		};
	};
}
function validateDepthTwo(datasetId) {
	const dataset = decisionTreeDatasets[datasetId];
	const root = findBestSplit(dataset.rows, dataset.rootCandidates);
	const child = findBestSplit(root.right.rows, dataset.rightChildCandidates);
	return (submission) => {
		const payload = submission;
		const correct = payload.rootSplitId === root.split.id && payload.rightChildSplitId === child.split.id;
		return {
			correct,
			message: correct ? "Correct! Good Job!" : "Choose the lowest-Gini root first, then rescore the child candidates using only rows in the right branch."
		};
	};
}
var decisionTreeAssignment = {
	id: "decision-trees",
	version: 7,
	title: "Decision Trees",
	topic: "Classification",
	description: "Practice binary decision-tree splits by computing Gini impurity, weighted split scores, and first tree-building choices.",
	published: false,
	questions: [
		{
			id: "dt-gini-warmup",
			kind: "decisionTree",
			title: "Compute Node Gini",
			prompt: "Compute the Gini impurity for each node using only the pass and not-pass counts.",
			instructions: "Use Gini = 1 - p(pass)^2 - p(not pass)^2. A pure node has Gini 0; a perfectly balanced binary node has Gini 0.5.",
			datasetId: "giniWarmup",
			interactionMode: "giniWarmup",
			hintSchedule: [2, 4],
			hints: ["Convert the counts to proportions before squaring.", "The two mixed 3-to-1 nodes have the same impurity, even though the majority class is different."],
			validator: validateGiniWarmup("giniWarmup"),
			reveal: { explanation: "Gini measures how mixed the labels are in a node. Pure nodes have impurity 0, and a 50-50 binary split has impurity 0.5." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "dt-score-one-split",
			kind: "decisionTree",
			title: "Score One Split",
			prompt: "Trace the proposed threshold through the raw data: route the rows, count both outcomes in each child, and compute the child and weighted Gini values.",
			instructions: "Complete all three stages. Rows with study hours less than or equal to the threshold go left; the rest go right.",
			datasetId: "splitScore",
			interactionMode: "splitScore",
			hintSchedule: [2, 4],
			hints: ["Start with the threshold comparison only. Do not use the outcome column until every row has a side.", "The weighted score is not the simple average unless both children contain the same number of rows."],
			validator: validateSplitScore("splitScore"),
			reveal: { explanation: "A split is scored by the weighted impurity of its children. Lower weighted Gini means the split has separated the labels more cleanly." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "dt-best-threshold",
			kind: "decisionTree",
			title: "Find the Best Threshold",
			prompt: "Compare the candidate thresholds for study hours and choose the split with the lowest weighted Gini.",
			datasetId: "bestThreshold",
			interactionMode: "bestThreshold",
			hintSchedule: [2, 4],
			hints: ["Do not just look for the purest child. Both child sizes matter in the weighted score.", "The best threshold makes the left child pure while keeping the right child mostly pass labels."],
			validator: validateBestSplit("bestThreshold"),
			reveal: { explanation: "Decision trees greedily choose the candidate split with the lowest weighted child impurity at the current node." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "dt-best-root-split",
			kind: "decisionTree",
			title: "Choose the Root Split",
			prompt: "Compare split candidates across two features and choose the best root split for the tree.",
			datasetId: "bestRootSplit",
			interactionMode: "bestRootSplit",
			hintSchedule: [2, 4],
			hints: ["Score each candidate independently; the feature names do not matter except through the labels they separate.", "The strongest candidates are close. Keep the child-size weights instead of comparing only the purer child."],
			validator: validateBestSplit("bestRootSplit"),
			reveal: { explanation: "The best root split is the candidate with the lowest weighted Gini across all features being considered." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "dt-visual-axis-split",
			kind: "decisionTree",
			title: "Place a Visual Split",
			prompt: "Place the vertical or horizontal split with the lowest weighted Gini. No split is perfect, and the visually widest gap is not necessarily best.",
			instructions: "The line represents x <= threshold or y <= threshold. Split scores remain hidden until you commit an answer.",
			datasetId: "visualSplit",
			interactionMode: "visualSplit",
			hintSchedule: [2, 4],
			hints: ["For each promising line, count both colors on each side and weight each child impurity by its number of points.", "A small pure child can outweigh a more balanced-looking division of the plot."],
			validator: validateVisualSplit("visualSplit"),
			reveal: { explanation: "The best vertical cut sits just to the right of x = 2. It isolates three did-not-pass points in a pure child; every more central cut leaves enough mixing to score worse." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "dt-visual-depth-two",
			kind: "decisionTree",
			title: "Build a Tree from Geometry",
			prompt: "Use the scatterplot to choose the greedy root split, then choose the best split for the root's right child.",
			instructions: "Choose the root first. The second line is scored using only points with x greater than the chosen root threshold; scores stay hidden until you submit.",
			datasetId: "visualDepthTwo",
			interactionMode: "depthTwo",
			hintSchedule: [2, 4],
			hints: ["The two strongest root candidates are close: calculate their weighted impurities rather than choosing the line that looks most central.", "For the second split, completely ignore every point to the left of the root line."],
			validator: validateDepthTwo("visualDepthTwo"),
			reveal: { explanation: "Greedy tree building scores the root by itself. It then restricts attention to the selected branch and scores the next candidates on that subset only." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "dt-depth-two-tree",
			kind: "decisionTree",
			title: "Complete a Depth-2 Tree",
			prompt: "Choose the best root split, then choose the best split for the impure right child.",
			instructions: "Only the right child of the root needs a second split in this dataset.",
			datasetId: "depthTwo",
			interactionMode: "depthTwo",
			hintSchedule: [2, 4],
			hints: ["After the best root split, the left child is already pure.", "For the right child, ignore rows that went left at the root and score the child candidates only on the remaining rows."],
			validator: validateDepthTwo("depthTwo"),
			reveal: { explanation: "Tree building is recursive: after choosing the root split, each impure child is treated as its own smaller split-selection problem." },
			successCopy: "Correct! Good Job!"
		},
		decisionTreeCodeLab
	]
};
//#endregion
//#region src/lib/kmeansMath.ts
function squaredEuclideanDistance(point, centroid) {
	return (point[0] - centroid[0]) ** 2 + (point[1] - centroid[1]) ** 2;
}
function manhattanDistance(point, centroid) {
	return Math.abs(point[0] - centroid[0]) + Math.abs(point[1] - centroid[1]);
}
function distanceForMetric(point, centroid, metric) {
	return metric === "manhattan" ? manhattanDistance(point, centroid) : squaredEuclideanDistance(point, centroid);
}
function assignPointsToCentroids(points, centroids, metric = "euclidean") {
	return points.map((point) => centroids.reduce((best, centroid, index) => {
		const distance = distanceForMetric(point, centroid, metric);
		return distance < best.distance ? {
			index,
			distance
		} : best;
	}, {
		index: 0,
		distance: Number.POSITIVE_INFINITY
	}).index);
}
function computeCentroidsFromAssignments(points, assignments, k, fallbackCentroids) {
	return Array.from({ length: k }, (_, clusterIndex) => {
		const clusterPoints = points.filter((_, pointIndex) => assignments[pointIndex] === clusterIndex);
		if (!clusterPoints.length) {
			var _fallbackCentroids$cl;
			return (_fallbackCentroids$cl = fallbackCentroids === null || fallbackCentroids === void 0 ? void 0 : fallbackCentroids[clusterIndex]) !== null && _fallbackCentroids$cl !== void 0 ? _fallbackCentroids$cl : [0, 0];
		}
		return [clusterPoints.reduce((sum, point) => sum + point[0], 0) / clusterPoints.length, clusterPoints.reduce((sum, point) => sum + point[1], 0) / clusterPoints.length];
	});
}
function withinClusterSumOfSquares(points, assignments, centroids) {
	return points.reduce((sum, point, index) => sum + squaredEuclideanDistance(point, centroids[assignments[index]]), 0);
}
function runLloydToConvergence(points, initialCentroids, metric = "euclidean", maxIterations = 20) {
	let centroids = initialCentroids.map((centroid) => [...centroid]);
	let assignments = assignPointsToCentroids(points, centroids, metric);
	for (let iteration = 0; iteration < maxIterations; iteration += 1) {
		const nextCentroids = computeCentroidsFromAssignments(points, assignments, centroids.length, centroids);
		const nextAssignments = assignPointsToCentroids(points, nextCentroids, metric);
		const centroidsUnchanged = nextCentroids.every((centroid, index) => Math.abs(centroid[0] - centroids[index][0]) < 1e-9 && Math.abs(centroid[1] - centroids[index][1]) < 1e-9);
		const assignmentsUnchanged = nextAssignments.every((assignment, index) => assignment === assignments[index]);
		centroids = nextCentroids;
		assignments = nextAssignments;
		if (centroidsUnchanged && assignmentsUnchanged) break;
	}
	return {
		centroids,
		assignments
	};
}
function permute(values) {
	if (values.length <= 1) return [values];
	return values.flatMap((value, index) => {
		return permute(values.filter((_, restIndex) => restIndex !== index)).map((suffix) => [value, ...suffix]);
	});
}
function assignmentsMatchUpToPermutation(actual, expected, k) {
	return permute(Array.from({ length: k }, (_, index) => index)).some((mapping) => actual.every((assignment, index) => mapping[assignment] === expected[index]));
}
function centroidsMatchUpToPermutation(actual, expected, tolerance) {
	return permute(Array.from({ length: expected.length }, (_, index) => index)).some((mapping) => actual.every((centroid, index) => {
		const target = expected[mapping[index]];
		return Math.abs(centroid[0] - target[0]) <= tolerance && Math.abs(centroid[1] - target[1]) <= tolerance;
	}));
}
//#endregion
//#region src/data/kmeansDatasets.ts
var baseClusterPoints = [
	[-5, -1],
	[-4, 1],
	[-3, 0],
	[-4, -2],
	[3, 3],
	[4, 2],
	[5, 4],
	[4, 5]
];
var baseCentroids = computeCentroidsFromAssignments(baseClusterPoints, [
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1
], 2);
var outlierPoints = [...baseClusterPoints, [9, 6]];
var outlierAssignments = assignPointsToCentroids(outlierPoints, baseCentroids, "euclidean");
var outlierCentroids = computeCentroidsFromAssignments(outlierPoints, outlierAssignments, 2, baseCentroids);
var multiIterationPoints = [
	[-6, 3],
	[-5, 4],
	[-4, 2],
	[-5, 1],
	[-1, -5],
	[0, -4],
	[1, -3],
	[0, -6],
	[5, 3],
	[6, 2],
	[7, 4],
	[6, 5],
	[-1, 1],
	[2, -1],
	[2, 2]
];
var multiIterationInitialCentroids = [
	[-6, -1],
	[0, 4],
	[6, 0]
];
function buildLloydSequence(points, initialCentroids, k) {
	const iterationAssignments = [];
	const iterationCentroids = [];
	const objectiveSequence = [];
	let currentCentroids = initialCentroids;
	for (let iteration = 0; iteration < 8; iteration += 1) {
		const assignments = assignPointsToCentroids(points, currentCentroids, "euclidean");
		const nextCentroids = computeCentroidsFromAssignments(points, assignments, k, currentCentroids);
		iterationAssignments.push(assignments);
		iterationCentroids.push(nextCentroids);
		objectiveSequence.push(withinClusterSumOfSquares(points, assignments, currentCentroids));
		if (nextCentroids.every((centroid, index) => Math.abs(centroid[0] - currentCentroids[index][0]) < 1e-9 && Math.abs(centroid[1] - currentCentroids[index][1]) < 1e-9)) break;
		currentCentroids = nextCentroids;
	}
	return {
		iterationAssignments,
		iterationCentroids,
		objectiveSequence
	};
}
var multiIterationSequence = buildLloydSequence(multiIterationPoints, multiIterationInitialCentroids, 3);
var badInitializationPoints = [
	[-8, 0],
	[-7, 1],
	[-7, -1],
	[-6, 0],
	[-2, 5],
	[-1, 6],
	[0, 5],
	[-1, 4],
	[5, 0],
	[6, 1],
	[6, -1],
	[7, 0],
	[8, 0]
];
var badInitializationObviousAssignments = [
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	2
];
var metricComparisonCentroids = [[-5, -4], [-1, -1]];
var metricComparisonPoints = [
	[-8, -4],
	[-7, -5],
	[-6, -4],
	[-2, -1],
	[-1, -2],
	[0, -1],
	[-1, -8],
	[0, -9]
];
var kmeansInteractiveDatasets = {
	fullIteration: {
		id: "fullIteration",
		label: "Run Lloyd's algorithm until it converges",
		points: multiIterationPoints,
		k: 3,
		metric: "euclidean",
		initialCentroids: multiIterationInitialCentroids,
		iterationAssignments: multiIterationSequence.iterationAssignments,
		iterationCentroids: multiIterationSequence.iterationCentroids,
		targetAssignments: multiIterationSequence.iterationAssignments[multiIterationSequence.iterationAssignments.length - 1],
		targetCentroids: multiIterationSequence.iterationCentroids[multiIterationSequence.iterationCentroids.length - 1],
		objectiveSequence: multiIterationSequence.objectiveSequence,
		objectiveBefore: multiIterationSequence.objectiveSequence[0],
		objectiveAfter: multiIterationSequence.objectiveSequence[multiIterationSequence.objectiveSequence.length - 1],
		regionVisibility: "resolved"
	},
	badInitialization: {
		id: "badInitialization",
		label: "Pick a bad initialization for k = 3",
		points: badInitializationPoints,
		k: 3,
		metric: "euclidean",
		obviousAssignments: badInitializationObviousAssignments,
		regionVisibility: "never"
	},
	metricComparison: {
		id: "metricComparison",
		label: "Euclidean vs Manhattan assignments",
		points: metricComparisonPoints,
		k: 2,
		metric: "euclidean",
		fixedCentroids: metricComparisonCentroids,
		targetAssignments: assignPointsToCentroids(metricComparisonPoints, metricComparisonCentroids, "euclidean"),
		comparisonAssignments: assignPointsToCentroids(metricComparisonPoints, metricComparisonCentroids, "manhattan"),
		comparisonMetric: "manhattan",
		regionVisibility: "never"
	},
	outlierShift: {
		id: "outlierShift",
		label: "Outlier sensitivity",
		points: outlierPoints,
		k: 2,
		metric: "euclidean",
		initialCentroids: baseCentroids,
		displayAssignments: outlierAssignments,
		targetCentroids: outlierCentroids,
		comparisonCentroids: baseCentroids,
		comparisonLabel: "Centroids without the outlier",
		regionVisibility: "always"
	}
};
//#endregion
//#region src/lib/questionValidation.ts
function validateMultipleChoiceSelections(correctSelections, incorrectMessage = "That selection is not right yet.") {
	return (submission) => {
		var _payload$selectedIds;
		const selectedIds = (_payload$selectedIds = submission.selectedIds) !== null && _payload$selectedIds !== void 0 ? _payload$selectedIds : {};
		const allCorrect = Object.entries(correctSelections).every(([partId, answerId]) => selectedIds[partId] === answerId);
		return {
			correct: allCorrect,
			message: allCorrect ? "Correct! Good Job!" : incorrectMessage
		};
	};
}
//#endregion
//#region src/data/kmeansAssignment.ts
function validateLloydIteration(datasetId, tolerance) {
	var _dataset$iterationAss, _dataset$iterationCen;
	const dataset = kmeansInteractiveDatasets[datasetId];
	const iterationAssignments = (_dataset$iterationAss = dataset.iterationAssignments) !== null && _dataset$iterationAss !== void 0 ? _dataset$iterationAss : [];
	const iterationCentroids = (_dataset$iterationCen = dataset.iterationCentroids) !== null && _dataset$iterationCen !== void 0 ? _dataset$iterationCen : [];
	return (submission) => {
		var _payload$iteration, _payload$referenceCen, _payload$referenceCen2, _payload$referenceAss, _payload$referenceAss2, _iterationAssignments, _iterationCentroids$i, _payload$centroids$le, _payload$centroids, _payload$centroids2;
		const payload = submission;
		const iterationIndex = (_payload$iteration = payload.iteration) !== null && _payload$iteration !== void 0 ? _payload$iteration : 0;
		const hasReferenceCentroids = ((_payload$referenceCen = (_payload$referenceCen2 = payload.referenceCentroids) === null || _payload$referenceCen2 === void 0 ? void 0 : _payload$referenceCen2.length) !== null && _payload$referenceCen !== void 0 ? _payload$referenceCen : 0) === dataset.k;
		const hasReferenceAssignments = ((_payload$referenceAss = (_payload$referenceAss2 = payload.referenceAssignments) === null || _payload$referenceAss2 === void 0 ? void 0 : _payload$referenceAss2.length) !== null && _payload$referenceAss !== void 0 ? _payload$referenceAss : 0) === dataset.points.length;
		const targetAssignments = hasReferenceCentroids && payload.referenceCentroids ? assignPointsToCentroids(dataset.points, payload.referenceCentroids, dataset.metric) : (_iterationAssignments = iterationAssignments[iterationIndex]) !== null && _iterationAssignments !== void 0 ? _iterationAssignments : [];
		const targetCentroids = hasReferenceAssignments && payload.referenceAssignments ? computeCentroidsFromAssignments(dataset.points, payload.referenceAssignments, dataset.k, payload.referenceCentroids) : (_iterationCentroids$i = iterationCentroids[iterationIndex]) !== null && _iterationCentroids$i !== void 0 ? _iterationCentroids$i : [];
		if (payload.step === "assignments") {
			var _payload$assignments$, _payload$assignments, _payload$assignments2;
			const assignmentCorrect = ((_payload$assignments$ = (_payload$assignments = payload.assignments) === null || _payload$assignments === void 0 ? void 0 : _payload$assignments.length) !== null && _payload$assignments$ !== void 0 ? _payload$assignments$ : 0) === targetAssignments.length && ((_payload$assignments2 = payload.assignments) !== null && _payload$assignments2 !== void 0 ? _payload$assignments2 : []).every((assignment, index) => assignment === targetAssignments[index]);
			return {
				correct: assignmentCorrect,
				message: assignmentCorrect ? "Correct! Good Job!" : "That assignment still violates the nearest-centroid rule for at least one point."
			};
		}
		const centroidCorrect = ((_payload$centroids$le = (_payload$centroids = payload.centroids) === null || _payload$centroids === void 0 ? void 0 : _payload$centroids.length) !== null && _payload$centroids$le !== void 0 ? _payload$centroids$le : 0) === targetCentroids.length && centroidsMatchUpToPermutation((_payload$centroids2 = payload.centroids) !== null && _payload$centroids2 !== void 0 ? _payload$centroids2 : [], targetCentroids, tolerance);
		return {
			correct: centroidCorrect,
			message: centroidCorrect ? "Correct! Good Job!" : "Those centroids are not at the means of their assigned clusters yet."
		};
	};
}
function validateBadInitialization(datasetId) {
	var _dataset$obviousAssig;
	const dataset = kmeansInteractiveDatasets[datasetId];
	const obviousAssignments = (_dataset$obviousAssig = dataset.obviousAssignments) !== null && _dataset$obviousAssig !== void 0 ? _dataset$obviousAssig : [];
	return (submission) => {
		var _payload$centroids3;
		const centroids = (_payload$centroids3 = submission.centroids) !== null && _payload$centroids3 !== void 0 ? _payload$centroids3 : [];
		if (centroids.length !== dataset.k) return {
			correct: false,
			message: `Place all ${dataset.k} initialization points before checking.`
		};
		const convergesToObvious = assignmentsMatchUpToPermutation(runLloydToConvergence(dataset.points, centroids, dataset.metric).assignments, obviousAssignments, dataset.k);
		return {
			correct: !convergesToObvious,
			message: !convergesToObvious ? "Correct! Good Job!" : "Those starting points still converge to the obvious three-cluster solution. Try a more lopsided initialization."
		};
	};
}
function validateMetricComparison$1(datasetId) {
	var _dataset$targetAssign, _dataset$comparisonAs;
	const dataset = kmeansInteractiveDatasets[datasetId];
	const euclideanAssignments = (_dataset$targetAssign = dataset.targetAssignments) !== null && _dataset$targetAssign !== void 0 ? _dataset$targetAssign : [];
	const manhattanAssignments = (_dataset$comparisonAs = dataset.comparisonAssignments) !== null && _dataset$comparisonAs !== void 0 ? _dataset$comparisonAs : [];
	return (submission) => {
		var _payload$assignments$2, _payload$assignments3, _payload$assignments4;
		const payload = submission;
		const targetAssignments = payload.step === "manhattan" ? manhattanAssignments : euclideanAssignments;
		const assignmentCorrect = ((_payload$assignments$2 = (_payload$assignments3 = payload.assignments) === null || _payload$assignments3 === void 0 ? void 0 : _payload$assignments3.length) !== null && _payload$assignments$2 !== void 0 ? _payload$assignments$2 : 0) === targetAssignments.length && ((_payload$assignments4 = payload.assignments) !== null && _payload$assignments4 !== void 0 ? _payload$assignments4 : []).every((assignment, index) => assignment === targetAssignments[index]);
		return {
			correct: assignmentCorrect,
			message: assignmentCorrect ? "Correct! Good Job!" : payload.step === "manhattan" ? "Those labels do not match the Manhattan-distance nearest-centroid assignments yet." : "Those labels do not match the Euclidean nearest-centroid assignments yet."
		};
	};
}
var kmeansAssignment = {
	id: "kmeans",
	displayNumber: 2,
	version: 6,
	title: "K-means Clustering",
	topic: "Clustering",
	description: "Practice full Lloyd iterations, bad initialization, metric changes, and elbow-method model selection.",
	published: true,
	questions: [
		{
			id: "kmeans-two-iterations",
			kind: "kmeans2d",
			title: "Run Lloyd's Algorithm to Convergence",
			prompt: "Keep alternating assignment and centroid-update steps until Lloyd’s algorithm converges.",
			instructions: "This question uses three centroids and three visible point clusters, with only a few bridge points between the clusters. The initial centroids do not start at the cluster centers.",
			datasetId: "fullIteration",
			interactionMode: "lloydIteration",
			centroidTolerance: .55,
			hintSchedule: [
				2,
				4,
				6
			],
			hints: [
				"Do not move the centroids yet. First make every point join its nearest current centroid.",
				"Once an assignment step is correct, each centroid should move to the arithmetic mean of the points with its color.",
				"The few bridge points between the clusters are the ones most likely to switch labels in the later iterations."
			],
			validator: validateLloydIteration("fullIteration", .55),
			reveal: { explanation: "Lloyd’s algorithm alternates between nearest-centroid assignments and centroid updates until the assignments and centroids stop changing. Because the centroids start away from the cluster centers here, the bridge points and centroid locations keep shifting for several rounds before the algorithm settles." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "kmeans-bad-initialization",
			kind: "kmeans2d",
			title: "Pick a Bad Initialization",
			prompt: "Place three initialization points so Lloyd's algorithm does not converge to the obvious three-cluster solution.",
			instructions: "The clusters are visually clear. Your goal is to choose a bad starting configuration that pushes Lloyd’s algorithm into a different local optimum.",
			datasetId: "badInitialization",
			interactionMode: "placeCentroids",
			centroidTolerance: .5,
			hintSchedule: [2, 4],
			hints: ["Try placing two initialization points so they compete for the same natural cluster while another cluster starts under-covered.", "You are not looking for the visible cluster centers here. You want a starting state that makes Lloyd's algorithm settle into the wrong partition."],
			validator: validateBadInitialization("badInitialization"),
			reveal: { explanation: "K-means can converge to a poor local optimum when the initialization is bad. Even with three visually distinct clusters, Lloyd's algorithm is not guaranteed to recover the obvious grouping from every starting configuration." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "kmeans-metric-assignments",
			kind: "kmeans2d",
			title: "Seeing the effect of different notions of distance.",
			prompt: "Using the same points and the same centroids, first color the points by the closest centroid under Euclidean distance, then repeat for Manhattan distance.",
			instructions: "The centroids stay fixed in both parts. Only the distance metric changes.",
			datasetId: "metricComparison",
			interactionMode: "metricComparison",
			centroidTolerance: .5,
			hintSchedule: [2, 4],
			hints: ["Under Euclidean distance, diagonal closeness matters directly.", "Under Manhattan distance, horizontal-plus-vertical travel matters more than diagonal shortcuts."],
			validator: validateMetricComparison$1("metricComparison"),
			reveal: { explanation: "Changing the metric changes the nearest-centroid assignments even when the points and centroids stay fixed. Manhattan distance can relabel points that look diagonally close under Euclidean distance." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "kmeans-elbow",
			kind: "multipleChoice",
			title: "The Elbow Method",
			prompt: "Choose the most reasonable value of k from the elbow curve.",
			instructions: "Look for the point where increasing k still helps, but the gains start flattening out instead of dropping sharply.",
			datasetId: "elbowCurve",
			parts: [{
				id: "best-k",
				prompt: "Which k is the best tradeoff suggested by this elbow curve?",
				correctOptionId: "k2",
				options: [
					{
						id: "k1",
						title: "k = 1",
						description: "The objective is still far too large there, so the curve has not bent yet."
					},
					{
						id: "k2",
						title: "k = 2",
						description: "The biggest drop has already happened, and the curve starts flattening after this point."
					},
					{
						id: "k3",
						title: "k = 3",
						description: "The improvement from 2 to 3 is real, but it is much smaller than the jump from 1 to 2."
					},
					{
						id: "k4",
						title: "k = 4",
						description: "By that point the curve is already in the flatter regime."
					}
				]
			}],
			hints: ["The elbow is where one more cluster stops buying you a comparably large improvement.", "Compare the size of the 1-to-2 drop with the later decreases."],
			validator: validateMultipleChoiceSelections({ "best-k": "k2" }, "That choice misses the main elbow in the plotted objective values."),
			reveal: { explanation: "The elbow method looks for the point where adding more clusters gives diminishing returns. Here the big structural gain is at k = 2, and later improvements are much smaller." },
			successCopy: "Correct! Good Job!"
		},
		kmeansNotebookLab
	]
};
//#endregion
//#region src/lib/knnMath.ts
function distanceBetween(a, b, metric) {
	const dx = Math.abs(a[0] - b[0]);
	const dy = Math.abs(a[1] - b[1]);
	return metric === "manhattan" ? dx + dy : Math.hypot(dx, dy);
}
function classifyKnnPoint(trainingPoints, queryPoint, k, metric) {
	var _neighbors$0$label, _neighbors$;
	const orderedNeighbors = trainingPoints.map((entry, index) => ({
		index,
		label: entry.label,
		point: entry.point,
		distance: distanceBetween(entry.point, queryPoint, metric)
	})).sort((left, right) => left.distance - right.distance || left.index - right.index);
	const effectiveK = Math.max(1, Math.min(k, orderedNeighbors.length));
	const neighbors = orderedNeighbors.slice(0, effectiveK);
	const voteTable = /* @__PURE__ */ new Map();
	for (const neighbor of neighbors) {
		var _voteTable$get;
		const current = (_voteTable$get = voteTable.get(neighbor.label)) !== null && _voteTable$get !== void 0 ? _voteTable$get : {
			count: 0,
			totalDistance: 0
		};
		voteTable.set(neighbor.label, {
			count: current.count + 1,
			totalDistance: current.totalDistance + neighbor.distance
		});
	}
	let bestLabel = (_neighbors$0$label = (_neighbors$ = neighbors[0]) === null || _neighbors$ === void 0 ? void 0 : _neighbors$.label) !== null && _neighbors$0$label !== void 0 ? _neighbors$0$label : 0;
	let bestCount = -1;
	let bestDistance = Number.POSITIVE_INFINITY;
	for (const [label, summary] of voteTable.entries()) if (summary.count > bestCount || summary.count === bestCount && summary.totalDistance < bestDistance - 1e-9 || summary.count === bestCount && Math.abs(summary.totalDistance - bestDistance) <= 1e-9 && label < bestLabel) {
		bestLabel = label;
		bestCount = summary.count;
		bestDistance = summary.totalDistance;
	}
	return {
		label: bestLabel,
		neighbors
	};
}
function computeAccuracy(trainingPoints, evaluationPoints, k, metric) {
	const correctCount = evaluationPoints.reduce((total, point) => {
		return total + (classifyKnnPoint(trainingPoints, point.point, k, metric).label === point.label ? 1 : 0);
	}, 0);
	return evaluationPoints.length > 0 ? correctCount / evaluationPoints.length : 0;
}
function findBestK(trainingPoints, evaluationPoints, kValues, metric) {
	var _kValues$;
	return kValues.reduce((best, currentK) => {
		const accuracy = computeAccuracy(trainingPoints, evaluationPoints, currentK, metric);
		if (accuracy > best.accuracy + 1e-9 || Math.abs(accuracy - best.accuracy) <= 1e-9 && currentK < best.k) return {
			k: currentK,
			accuracy
		};
		return best;
	}, {
		k: (_kValues$ = kValues[0]) !== null && _kValues$ !== void 0 ? _kValues$ : 1,
		accuracy: Number.NEGATIVE_INFINITY
	});
}
function createGridCenters(bounds, columns, rows) {
	return Array.from({ length: columns * rows }, (_, cellIndex) => {
		const columnIndex = cellIndex % columns;
		const rowIndex = Math.floor(cellIndex / columns);
		const x0 = bounds.minX + columnIndex / columns * (bounds.maxX - bounds.minX);
		const x1 = bounds.minX + (columnIndex + 1) / columns * (bounds.maxX - bounds.minX);
		const y0 = bounds.minY + rowIndex / rows * (bounds.maxY - bounds.minY);
		const y1 = bounds.minY + (rowIndex + 1) / rows * (bounds.maxY - bounds.minY);
		return [(x0 + x1) / 2, (y0 + y1) / 2];
	});
}
function classifyGridCells(trainingPoints, bounds, columns, rows, k, metric) {
	return createGridCenters(bounds, columns, rows).map((center) => classifyKnnPoint(trainingPoints, center, k, metric).label);
}
function fitMinMaxNormalizer(points) {
	const xs = points.map((point) => point[0]);
	const ys = points.map((point) => point[1]);
	return {
		min: [Math.min(...xs), Math.min(...ys)],
		max: [Math.max(...xs), Math.max(...ys)]
	};
}
function applyMinMaxNormalizer(point, normalizer) {
	const [minX, minY] = normalizer.min;
	const [maxX, maxY] = normalizer.max;
	return [(point[0] - minX) / Math.max(maxX - minX, 1e-9), (point[1] - minY) / Math.max(maxY - minY, 1e-9)];
}
function normalizeLabeledPoints(points, normalizer) {
	return points.map((entry) => ({
		...entry,
		point: applyMinMaxNormalizer(entry.point, normalizer)
	}));
}
//#endregion
//#region src/data/knnDatasets.ts
var defaultKnnClasses = [{
	label: "Teal",
	color: "#1c7b8a"
}, {
	label: "Orange",
	color: "#cc7c31"
}];
var scalingTrainingPoints = [
	{
		point: [4, .91],
		label: 0
	},
	{
		point: [10, .84],
		label: 0
	},
	{
		point: [16, .88],
		label: 0
	},
	{
		point: [24, .88],
		label: 0
	},
	{
		point: [72, .12],
		label: 1
	},
	{
		point: [78, .18],
		label: 1
	},
	{
		point: [85, .15],
		label: 1
	},
	{
		point: [92, .2],
		label: 1
	}
];
var scalingQueryPoint = [60, .86];
var scalingNormalizer = fitMinMaxNormalizer(scalingTrainingPoints.map((entry) => entry.point));
var knnInteractiveDatasets = {
	predictSequence: {
		id: "predictSequence",
		kind: "predictSequence",
		label: "One query point, three different choices of k",
		classes: defaultKnnClasses,
		trainingPoints: [
			{
				point: [-.5, .25],
				label: 0
			},
			{
				point: [.2, -.55],
				label: 0
			},
			{
				point: [-3, 3],
				label: 0
			},
			{
				point: [.65, .15],
				label: 1
			},
			{
				point: [1, -.1],
				label: 1
			},
			{
				point: [.1, 1.15],
				label: 1
			},
			{
				point: [2.3, 2.1],
				label: 1
			},
			{
				point: [2.8, -2],
				label: 1
			},
			{
				point: [3.2, .5],
				label: 1
			}
		],
		queryPoint: [0, 0],
		metric: "euclidean",
		kSequence: [
			3,
			5,
			9
		],
		bounds: {
			minX: -4.2,
			maxX: 4.2,
			minY: -3.2,
			maxY: 3.6
		}
	},
	decisionBoundary: {
		id: "decisionBoundary",
		kind: "decisionBoundary",
		label: "Paint the class of each cell in the grid",
		classes: defaultKnnClasses,
		trainingPoints: [
			{
				point: [-3.75, 2.25],
				label: 0
			},
			{
				point: [-2.25, .75],
				label: 0
			},
			{
				point: [-3, -.75],
				label: 0
			},
			{
				point: [-2.25, -2.25],
				label: 0
			},
			{
				point: [-.9, 2.25],
				label: 0
			},
			{
				point: [.45, .75],
				label: 0
			},
			{
				point: [2.25, 2.25],
				label: 1
			},
			{
				point: [3.75, .75],
				label: 1
			},
			{
				point: [2.25, -.75],
				label: 1
			},
			{
				point: [2.25, -2.25],
				label: 1
			},
			{
				point: [3.75, -2.25],
				label: 1
			},
			{
				point: [.75, -.75],
				label: 1
			}
		],
		metric: "euclidean",
		gridColumns: 6,
		gridRows: 6,
		kSequence: [1, 5],
		bounds: {
			minX: -4.5,
			maxX: 4.5,
			minY: -4.5,
			maxY: 4.5
		}
	},
	bestK: {
		id: "bestK",
		kind: "bestK",
		label: "Use the slider to balance fit and generalization",
		classes: defaultKnnClasses,
		trainingPoints: [
			{
				point: [-.32, -1.99],
				label: 0
			},
			{
				point: [-3.42, -1.91],
				label: 0
			},
			{
				point: [-2.27, -.94],
				label: 0
			},
			{
				point: [-1.24, -.73],
				label: 0
			},
			{
				point: [.21, 3.1],
				label: 0
			},
			{
				point: [.99, -.12],
				label: 0
			},
			{
				point: [1.05, 1.96],
				label: 0
			},
			{
				point: [-.13, .29],
				label: 0
			},
			{
				point: [1.06, 1.85],
				label: 1
			},
			{
				point: [2.24, -.21],
				label: 1
			},
			{
				point: [1.4, .66],
				label: 1
			},
			{
				point: [1.44, .77],
				label: 1
			},
			{
				point: [2.26, -1.08],
				label: 1
			},
			{
				point: [.06, -1.71],
				label: 1
			},
			{
				point: [.01, -1.88],
				label: 1
			},
			{
				point: [1.17, -.61],
				label: 1
			},
			{
				point: [.2, .1],
				label: 0
			},
			{
				point: [.7, .2],
				label: 1
			}
		],
		testPoints: [
			{
				point: [-1.97, -.49],
				label: 0
			},
			{
				point: [-1.59, -1.34],
				label: 0
			},
			{
				point: [-2.62, -1.21],
				label: 0
			},
			{
				point: [-.89, 2.22],
				label: 0
			},
			{
				point: [-.79, 3.67],
				label: 0
			},
			{
				point: [.47, -.51],
				label: 0
			},
			{
				point: [1.65, 2.46],
				label: 1
			},
			{
				point: [1.32, -.13],
				label: 1
			},
			{
				point: [2.02, -.09],
				label: 1
			},
			{
				point: [-.21, -2.56],
				label: 1
			},
			{
				point: [2.86, -2.74],
				label: 1
			},
			{
				point: [.91, -2.12],
				label: 1
			},
			{
				point: [.1, .25],
				label: 0
			},
			{
				point: [.8, -.1],
				label: 1
			}
		],
		metric: "euclidean",
		kValues: Array.from({ length: 11 }, (_, index) => index + 1),
		initialK: 1,
		boundaryResolution: 20,
		bounds: {
			minX: -4.2,
			maxX: 3.4,
			minY: -3.1,
			maxY: 4
		}
	},
	scalingTrap: {
		id: "scalingTrap",
		kind: "scalingTrap",
		label: "The same points before and after feature normalization",
		classes: defaultKnnClasses,
		trainingPoints: scalingTrainingPoints,
		normalizedTrainingPoints: normalizeLabeledPoints(scalingTrainingPoints, scalingNormalizer),
		queryPoint: scalingQueryPoint,
		normalizedQueryPoint: applyMinMaxNormalizer(scalingQueryPoint, scalingNormalizer),
		metric: "euclidean",
		k: 3,
		featureLabels: ["Feature 1", "Feature 2"],
		bounds: {
			minX: 0,
			maxX: 100,
			minY: 0,
			maxY: 1
		},
		normalizedBounds: {
			minX: -.05,
			maxX: 1.05,
			minY: -.05,
			maxY: 1.05
		},
		boundaryResolution: 20
	},
	metricComparison: {
		id: "metricComparison",
		kind: "metricComparison",
		label: "Euclidean distance versus Manhattan distance",
		classes: defaultKnnClasses,
		trainingPoints: [
			{
				point: [1.4, 1.4],
				label: 0
			},
			{
				point: [1.5, -1.3],
				label: 0
			},
			{
				point: [-1.35, 1.45],
				label: 0
			},
			{
				point: [0, 2.2],
				label: 1
			},
			{
				point: [2.2, 0],
				label: 1
			},
			{
				point: [-2.2, 0],
				label: 1
			},
			{
				point: [0, -3],
				label: 1
			}
		],
		queryPoint: [0, 0],
		metric: "euclidean",
		comparisonMetric: "manhattan",
		k: 3,
		bounds: {
			minX: -3.2,
			maxX: 3.2,
			minY: -3.4,
			maxY: 3
		},
		boundaryResolution: 18
	},
	adversarialPlacement: {
		id: "adversarialPlacement",
		kind: "adversarialPlacement",
		label: "Add one new point that flips the current vote",
		classes: defaultKnnClasses,
		trainingPoints: [
			{
				point: [-.9, 0],
				label: 0
			},
			{
				point: [.75, -.42],
				label: 0
			},
			{
				point: [-1.8, 1.4],
				label: 0
			},
			{
				point: [1.9, 1.5],
				label: 0
			},
			{
				point: [.62, .62],
				label: 1
			},
			{
				point: [1.8, -1.3],
				label: 1
			},
			{
				point: [-1.7, -1.5],
				label: 1
			}
		],
		queryPoint: [0, 0],
		metric: "euclidean",
		k: 3,
		examplePoint: {
			point: [.06, .12],
			label: 1
		},
		bounds: {
			minX: -2.6,
			maxX: 2.6,
			minY: -2.2,
			maxY: 2.2
		},
		boundaryResolution: 18
	}
};
//#endregion
//#region src/data/knnAssignment.ts
function validatePredictSequence(datasetId) {
	const dataset = knnInteractiveDatasets[datasetId];
	if (dataset.kind !== "predictSequence") throw new Error(`Dataset ${datasetId} is not a predict-sequence dataset.`);
	return (submission) => {
		var _payload$step;
		const payload = submission;
		const stepIndex = Math.max(0, Math.min((_payload$step = payload.step) !== null && _payload$step !== void 0 ? _payload$step : 0, dataset.kSequence.length - 1));
		const k = dataset.kSequence[stepIndex];
		const targetLabel = classifyKnnPoint(dataset.trainingPoints, dataset.queryPoint, k, dataset.metric).label;
		return {
			correct: payload.predictedLabel === targetLabel,
			message: payload.predictedLabel === targetLabel ? "Correct! Good Job!" : `Look more carefully at the ${k} nearest neighbors around the query point.`
		};
	};
}
function validateDecisionBoundary(datasetId) {
	const dataset = knnInteractiveDatasets[datasetId];
	if (dataset.kind !== "decisionBoundary") throw new Error(`Dataset ${datasetId} is not a decision-boundary dataset.`);
	return (submission) => {
		var _payload$step2, _payload$cells;
		const payload = submission;
		const stepIndex = Math.max(0, Math.min((_payload$step2 = payload.step) !== null && _payload$step2 !== void 0 ? _payload$step2 : 0, dataset.kSequence.length - 1));
		const k = dataset.kSequence[stepIndex];
		const targetCells = classifyGridCells(dataset.trainingPoints, dataset.bounds, dataset.gridColumns, dataset.gridRows, k, dataset.metric);
		const submittedCells = (_payload$cells = payload.cells) !== null && _payload$cells !== void 0 ? _payload$cells : [];
		const correct = submittedCells.length === targetCells.length && submittedCells.every((cell, index) => cell === targetCells[index]);
		return {
			correct,
			message: correct ? "Correct! Good Job!" : `At least one grid cell still disagrees with the ${k}-NN decision rule.`
		};
	};
}
function validateBestK(datasetId) {
	const dataset = knnInteractiveDatasets[datasetId];
	if (dataset.kind !== "bestK") throw new Error(`Dataset ${datasetId} is not a best-k dataset.`);
	const bestChoice = findBestK(dataset.trainingPoints, dataset.testPoints, dataset.kValues, dataset.metric);
	return (submission) => {
		const correct = submission.k === bestChoice.k;
		return {
			correct,
			message: correct ? "Correct! Good Job!" : "A different value of k gets higher accuracy on the held-out test points."
		};
	};
}
function validateScalingTrap(datasetId) {
	const dataset = knnInteractiveDatasets[datasetId];
	if (dataset.kind !== "scalingTrap") throw new Error(`Dataset ${datasetId} is not a scaling-trap dataset.`);
	const rawLabel = classifyKnnPoint(dataset.trainingPoints, dataset.queryPoint, dataset.k, dataset.metric).label;
	const normalizedLabel = classifyKnnPoint(dataset.normalizedTrainingPoints, dataset.normalizedQueryPoint, dataset.k, dataset.metric).label;
	return (submission) => {
		const payload = submission;
		const targetLabel = payload.step === "normalized" ? normalizedLabel : rawLabel;
		return {
			correct: payload.predictedLabel === targetLabel,
			message: payload.predictedLabel === targetLabel ? "Correct! Good Job!" : payload.step === "normalized" ? "After normalization, the distance geometry changes. Re-check the closest neighbors." : "Without normalization, the wide-range feature dominates the distance calculation."
		};
	};
}
function validateMetricComparison(datasetId) {
	const dataset = knnInteractiveDatasets[datasetId];
	if (dataset.kind !== "metricComparison") throw new Error(`Dataset ${datasetId} is not a metric-comparison dataset.`);
	const euclideanLabel = classifyKnnPoint(dataset.trainingPoints, dataset.queryPoint, dataset.k, dataset.metric).label;
	const manhattanLabel = classifyKnnPoint(dataset.trainingPoints, dataset.queryPoint, dataset.k, dataset.comparisonMetric).label;
	return (submission) => {
		const payload = submission;
		const targetLabel = payload.step === "manhattan" ? manhattanLabel : euclideanLabel;
		return {
			correct: payload.predictedLabel === targetLabel,
			message: payload.predictedLabel === targetLabel ? "Correct! Good Job!" : payload.step === "manhattan" ? "Under Manhattan distance, axis-aligned paths matter more than diagonal shortcuts." : "Under Euclidean distance, the diagonally nearby points matter more than under Manhattan distance."
		};
	};
}
function validateAdversarialPlacement(datasetId) {
	const dataset = knnInteractiveDatasets[datasetId];
	if (dataset.kind !== "adversarialPlacement") throw new Error(`Dataset ${datasetId} is not an adversarial-placement dataset.`);
	const originalLabel = classifyKnnPoint(dataset.trainingPoints, dataset.queryPoint, dataset.k, dataset.metric).label;
	return (submission) => {
		const payload = submission;
		if (!payload.point) return {
			correct: false,
			message: "Place the new training point somewhere on the plot before checking."
		};
		const updatedLabel = classifyKnnPoint([...dataset.trainingPoints, {
			point: payload.point,
			label: dataset.examplePoint.label
		}], dataset.queryPoint, dataset.k, dataset.metric).label;
		return {
			correct: updatedLabel !== originalLabel,
			message: updatedLabel !== originalLabel ? "Correct! Good Job!" : "That new point still does not change the majority among the three nearest neighbors."
		};
	};
}
var knnAssignment = {
	id: "knn",
	displayNumber: 3,
	version: 8,
	title: "k-Nearest Neighbors",
	topic: "Classification",
	description: "Practice local voting, boundary shape, choosing k, train/test evaluation, scaling, distance metrics, and adversarial sensitivity.",
	published: true,
	questions: [
		{
			id: "knn-predict-sequence",
			kind: "knn2d",
			title: "Predict the Classification",
			prompt: "Predict the class of the query point for k = 3, then k = 5, then k = n on the same dataset.",
			instructions: "The points do not move. Only the size of the neighborhood changes from one step to the next.",
			datasetId: "predictSequence",
			interactionMode: "predictSequence",
			hintSchedule: [
				2,
				4,
				6
			],
			hints: [
				"For k = 3, look only at the three closest points to the query point, not the whole cloud.",
				"For k = 5, the local majority changes because more orange points enter the vote.",
				"For k = n, every training point votes, so the global class balance matters most."
			],
			validator: validatePredictSequence("predictSequence"),
			reveal: { explanation: "Small k values focus on very local structure, while larger k values smooth the decision toward the broader class balance. The same query point can change labels as k grows." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "knn-decision-boundary",
			kind: "knn2d",
			title: "Sketch the Decision Boundary",
			prompt: "Color each grid cell with the class that k-NN would predict there, first for k = 1 and then for k = 5.",
			instructions: "Use the class brush buttons below the plot. The points stay fixed while the boundary changes between the two rounds.",
			datasetId: "decisionBoundary",
			interactionMode: "decisionBoundary",
			hintSchedule: [2, 4],
			hints: ["At k = 1, a single outlier can carve out a tiny island of its own class.", "At k = 5, the local islands shrink because each cell listens to a larger neighborhood."],
			validator: validateDecisionBoundary("decisionBoundary"),
			reveal: { explanation: "The k = 1 boundary hugs individual points closely, including isolated outliers. With k = 5, each location averages over a wider neighborhood, so the boundary becomes much smoother." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "knn-best-k",
			kind: "knn2d",
			title: "Choose the Best k",
			prompt: "Move the slider and find the value of k that maximizes accuracy on the held-out test points.",
			instructions: "Training points are filled. Test points are shown in a different style. Watch how the boundary and the training/test accuracies move together.",
			datasetId: "bestK",
			interactionMode: "bestK",
			hintSchedule: [2, 4],
			hints: ["Very small k can fit every training point but still generalize badly to held-out data.", "Very large k smooths too aggressively and can blur the messy overlap region."],
			validator: validateBestK("bestK"),
			reveal: { explanation: "The best choice of k is the one that generalizes best, not the one that merely memorizes the training set. The test-accuracy curve peaks at an intermediate value here." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "knn-scaling-trap",
			kind: "knn2d",
			title: "The Scaling Trap",
			prompt: "Using k = 3, predict the query point before normalization and then again after min-max normalization.",
			instructions: "Feature 1 has a much wider numerical range than Feature 2. After the first step, the plot switches to min-max normalized coordinates.",
			datasetId: "scalingTrap",
			interactionMode: "scalingTrap",
			hintSchedule: [2, 4],
			hints: ["Without scaling, the wide-range horizontal feature dominates the Euclidean distance.", "After normalization, vertical differences matter on the same footing as horizontal differences."],
			validator: validateScalingTrap("scalingTrap"),
			reveal: { explanation: "KNN depends directly on geometric distance, so feature scale matters immediately. Normalizing the features changes the geometry of the space and can change the predicted label." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "knn-metric-comparison",
			kind: "knn2d",
			title: "Distance Metric Comparison",
			prompt: "Using k = 3, predict the query point’s class under Euclidean distance, then repeat under Manhattan distance.",
			instructions: "Use k = 3 in both parts. Only the metric changes; the points stay fixed.",
			datasetId: "metricComparison",
			interactionMode: "metricComparison",
			hintSchedule: [2, 4],
			hints: ["Euclidean distance treats diagonal closeness directly.", "Manhattan distance favors axis-aligned travel, so the nearest set can change."],
			validator: validateMetricComparison("metricComparison"),
			reveal: { explanation: "Different distance metrics define “near” differently. Even with the same data and the same k, Euclidean and Manhattan distance can produce different nearest neighbors and different class predictions." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "knn-adversarial-placement",
			kind: "knn2d",
			title: "Adversarial Placement",
			prompt: "Add one new orange training point that flips the current 3-NN prediction for the query point.",
			instructions: "Click on the plot to place the new point. You can reposition it by clicking again before checking your answer.",
			datasetId: "adversarialPlacement",
			interactionMode: "adversarialPlacement",
			hintSchedule: [2, 4],
			hints: ["The new point has to enter the set of the three nearest neighbors to matter.", "You only need to flip a 2-to-1 vote into a 2-to-1 vote for the other class."],
			validator: validateAdversarialPlacement("adversarialPlacement"),
			reveal: { explanation: "Because KNN is a local voting rule, a single carefully placed point can change the prediction if it enters the neighborhood that determines the vote." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "knn-train-test-accuracy",
			kind: "multipleChoice",
			title: "Train vs Test Accuracy",
			prompt: "Use the prediction table to compute the training and test accuracies, then decide which one better estimates future performance.",
			instructions: "Count correct predictions separately on the train rows and the test rows before converting each count into an accuracy.",
			datasetId: "trainTestAccuracy",
			parts: [
				{
					id: "train-correct",
					prompt: "How many training examples are classified correctly?",
					correctOptionId: "train-7",
					options: [
						{
							id: "train-6",
							title: "6 correct",
							description: "This misses one of the correctly predicted training rows."
						},
						{
							id: "train-7",
							title: "7 correct",
							description: "Exactly one of the eight training rows is misclassified."
						},
						{
							id: "train-8",
							title: "8 correct",
							description: "That would mean the model made no training mistakes at all."
						}
					]
				},
				{
					id: "train-accuracy",
					prompt: "What is the training accuracy?",
					correctOptionId: "train-87-5",
					options: [
						{
							id: "train-75",
							title: "75%",
							description: "This corresponds to 6 correct out of 8 training examples."
						},
						{
							id: "train-87-5",
							title: "87.5%",
							description: "This is 7 correct out of 8 training examples."
						},
						{
							id: "train-100",
							title: "100%",
							description: "This would mean every training example is correct."
						}
					]
				},
				{
					id: "test-correct",
					prompt: "How many test examples are classified correctly?",
					correctOptionId: "test-2",
					options: [
						{
							id: "test-1",
							title: "1 correct",
							description: "This undercounts the correctly predicted test rows."
						},
						{
							id: "test-2",
							title: "2 correct",
							description: "Two of the four test rows match the true label."
						},
						{
							id: "test-3",
							title: "3 correct",
							description: "That would mean only one test mistake, which is not what the table shows."
						}
					]
				},
				{
					id: "test-accuracy",
					prompt: "What is the test accuracy?",
					correctOptionId: "test-50",
					options: [
						{
							id: "test-25",
							title: "25%",
							description: "This corresponds to 1 correct out of 4 test examples."
						},
						{
							id: "test-50",
							title: "50%",
							description: "This is 2 correct out of 4 test examples."
						},
						{
							id: "test-75",
							title: "75%",
							description: "This corresponds to 3 correct out of 4 test examples."
						}
					]
				},
				{
					id: "future-performance",
					prompt: "Which accuracy is the better estimate of performance on future unseen data?",
					correctOptionId: "use-test",
					options: [
						{
							id: "use-train",
							title: "Training accuracy",
							description: "This is measured on the data the model already saw."
						},
						{
							id: "use-test",
							title: "Test accuracy",
							description: "This is measured on held-out examples and is meant to estimate future generalization."
						},
						{
							id: "average-both",
							title: "Average the two",
							description: "Averaging them mixes seen and unseen data instead of focusing on held-out performance."
						}
					]
				}
			],
			hintSchedule: [2, 4],
			hints: [
				"Accuracy means correct predictions divided by the number of examples in that split.",
				"Do not combine train and test rows. Compute the two accuracies separately first.",
				"The held-out test split is the one meant to estimate performance on unseen data."
			],
			validator: validateMultipleChoiceSelections({
				"train-correct": "train-7",
				"train-accuracy": "train-87-5",
				"test-correct": "test-2",
				"test-accuracy": "test-50",
				"future-performance": "use-test"
			}, "At least one of those counts or accuracies does not match the table yet."),
			reveal: { explanation: "The model gets 7 of 8 training examples correct, so training accuracy is 87.5%. It gets 2 of 4 test examples correct, so test accuracy is 50%. The test accuracy is the better estimate of future performance because it is measured on held-out data." },
			successCopy: "Correct! Good Job!"
		},
		knnCodeLab,
		knnEvaluationNotebookLab
	]
};
//#endregion
//#region src/data/numpyAssignment.ts
var numpyAssignment = {
	id: "numpy",
	displayNumber: 0,
	version: 1,
	title: "Numpy",
	topic: "Python Foundations",
	description: "Practice the NumPy array shapes, indexing, slicing, Boolean masks, reductions, and matrix operations used throughout the course.",
	published: true,
	questions: [
		{
			id: "numpy-shapes-indexing",
			kind: "multipleChoice",
			title: "Construct and Reshape Arrays",
			prompt: "Trace the three array definitions in the reference table, then determine their shapes and one indexed value.",
			instructions: "Remember that a one-dimensional array does not have a row dimension. NumPy indices begin at zero.",
			datasetId: "numpyMiniArrays",
			parts: [
				{
					id: "y-shape",
					prompt: "What is `y.shape`?",
					correctOptionId: "shape-12",
					options: [
						{
							id: "shape-12",
							title: "(12,)",
							description: "A one-dimensional NumPy array records one axis in its shape."
						},
						{
							id: "shape-1-12",
							title: "(1, 12)",
							description: "This would be a two-dimensional row array."
						},
						{
							id: "shape-12-1",
							title: "(12, 1)",
							description: "This would be a two-dimensional column array."
						}
					]
				},
				{
					id: "Y-shape",
					prompt: "What is `Y.shape`?",
					correctOptionId: "shape-3-4",
					options: [
						{
							id: "shape-3-4",
							title: "(3, 4)",
							description: "The reshape call requests three rows and four columns."
						},
						{
							id: "shape-4-3",
							title: "(4, 3)",
							description: "This reverses the two dimensions passed to reshape."
						},
						{
							id: "shape-12",
							title: "(12,)",
							description: "This is the shape before reshaping."
						}
					]
				},
				{
					id: "indexed-value",
					prompt: "What is `Y[1, 2]`?",
					correctOptionId: "value-7",
					options: [
						{
							id: "value-6",
							title: "6",
							description: "This is one column to the left of the requested entry."
						},
						{
							id: "value-7",
							title: "7",
							description: "Row 1 is the second row, and column 2 is the third column."
						},
						{
							id: "value-8",
							title: "8",
							description: "This is the last entry in the second row."
						}
					]
				},
				{
					id: "newaxis-shape",
					prompt: "What is `(y[:, np.newaxis]).shape`?",
					correctOptionId: "shape-12-1",
					options: [
						{
							id: "shape-12",
							title: "(12,)",
							description: "`np.newaxis` adds a dimension, so the shape cannot remain one-dimensional."
						},
						{
							id: "shape-1-12",
							title: "(1, 12)",
							description: "This would add the new axis before the existing one."
						},
						{
							id: "shape-12-1",
							title: "(12, 1)",
							description: "The new axis is inserted after the existing array index."
						}
					]
				}
			],
			hintSchedule: [2, 4],
			hints: ["`np.arange(1, 13)` includes 1 but stops before 13, so it creates twelve values.", "Write Y as three rows of four values before applying the two zero-based indices."],
			validator: validateMultipleChoiceSelections({
				"y-shape": "shape-12",
				"Y-shape": "shape-3-4",
				"indexed-value": "value-7",
				"newaxis-shape": "shape-12-1"
			}, "At least one shape or indexed value does not follow the displayed NumPy operations."),
			reveal: { explanation: "`y` is a one-dimensional array with shape `(12,)`. Reshaping places the values into three rows of four, so `Y[1, 2]` is 7. Inserting a new axis after the existing index changes the shape to `(12, 1)`." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "numpy-slicing-masks",
			kind: "multipleChoice",
			title: "Slice and Filter an Array",
			prompt: "Use the same array Y to trace a rectangular slice and a Boolean mask.",
			instructions: "Slice endpoints are excluded. In the mask, `&` requires every condition to be true for an entry to remain.",
			datasetId: "numpyMiniArrays",
			parts: [{
				id: "rectangular-slice",
				prompt: "What is `Y[0:2, 1:3].tolist()`?",
				correctOptionId: "slice-2-3-6-7",
				options: [
					{
						id: "slice-2-3-6-7",
						title: "[[2, 3], [6, 7]]",
						description: "The slice keeps rows 0 and 1 and columns 1 and 2."
					},
					{
						id: "slice-1-2-5-6",
						title: "[[1, 2], [5, 6]]",
						description: "This starts the column slice at column 0."
					},
					{
						id: "slice-2-3-4-6-7-8",
						title: "[[2, 3, 4], [6, 7, 8]]",
						description: "This incorrectly includes the ending column index 3."
					}
				]
			}, {
				id: "boolean-filter",
				prompt: "What is `Y[(Y % 3 == 0) & (Y > 3)].tolist()`?",
				correctOptionId: "filter-6-9-12",
				options: [
					{
						id: "filter-6-9-12",
						title: "[6, 9, 12]",
						description: "These entries satisfy both the divisibility and strict-bound conditions."
					},
					{
						id: "filter-3-6-9-12",
						title: "[3, 6, 9, 12]",
						description: "The strict comparison excludes 3 itself."
					},
					{
						id: "filter-4-through-12",
						title: "[4, 5, 6, 7, 8, 9, 10, 11, 12]",
						description: "This applies only the greater-than condition."
					}
				]
			}],
			hintSchedule: [2, 4],
			hints: ["The slice `1:3` includes positions 1 and 2, not position 3.", "Evaluate each Boolean condition separately, then keep only entries where both masks are true."],
			validator: validateMultipleChoiceSelections({
				"rectangular-slice": "slice-2-3-6-7",
				"boolean-filter": "filter-6-9-12"
			}, "At least one result includes an entry outside the requested slice or Boolean mask."),
			reveal: { explanation: "The rectangular slice selects two rows and two columns, producing `[[2, 3], [6, 7]]`. Boolean indexing flattens the selected entries into a one-dimensional result and retains 6, 9, and 12." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "numpy-elementwise-reductions",
			kind: "multipleChoice",
			title: "Apply Functions and Reduce Axes",
			prompt: "Let `Z = np.sqrt(Y) + X`. Trace one elementwise value and two reductions of Y.",
			instructions: "`axis=0` reduces down the rows and leaves one result per column. `axis=1` reduces across the columns and leaves one result per row.",
			datasetId: "numpyMiniArrays",
			parts: [
				{
					id: "elementwise-value",
					prompt: "What is `Z[1, 2]`?",
					correctOptionId: "one-plus-sqrt-7",
					options: [
						{
							id: "one-plus-sqrt-7",
							title: "1 + √7 ≈ 3.646",
							description: "The operations are applied to the corresponding entry 7 in Y and entry 1 in X."
						},
						{
							id: "sqrt-8",
							title: "√8 ≈ 2.828",
							description: "NumPy does not add the arrays before applying the square root here."
						},
						{
							id: "one-plus-sqrt-6",
							title: "1 + √6 ≈ 3.449",
							description: "This uses the entry one column to the left."
						}
					]
				},
				{
					id: "column-maxima",
					prompt: "What is `Y.max(axis=0).tolist()`?",
					correctOptionId: "max-9-10-11-12",
					options: [
						{
							id: "max-9-10-11-12",
							title: "[9, 10, 11, 12]",
							description: "Reducing axis 0 leaves the maximum of each column."
						},
						{
							id: "max-4-8-12",
							title: "[4, 8, 12]",
							description: "These are the row maxima produced by reducing axis 1."
						},
						{
							id: "max-12",
							title: "[12]",
							description: "This reduces the whole array rather than a specified axis."
						}
					]
				},
				{
					id: "row-sums",
					prompt: "What is `Y.sum(axis=1).tolist()`?",
					correctOptionId: "sums-10-26-42",
					options: [
						{
							id: "sums-10-26-42",
							title: "[10, 26, 42]",
							description: "Reducing axis 1 produces one sum for each row."
						},
						{
							id: "sums-15-18-21-24",
							title: "[15, 18, 21, 24]",
							description: "These are column sums produced by reducing axis 0."
						},
						{
							id: "sum-78",
							title: "[78]",
							description: "This is the sum of the entire array rather than one sum per row."
						}
					]
				}
			],
			hintSchedule: [2, 4],
			hints: ["Elementwise operations do not change which row and column an entry occupies.", "The dimension named by `axis` disappears from the result."],
			validator: validateMultipleChoiceSelections({
				"elementwise-value": "one-plus-sqrt-7",
				"column-maxima": "max-9-10-11-12",
				"row-sums": "sums-10-26-42"
			}, "At least one elementwise value or axis reduction is incorrect."),
			reveal: { explanation: "The entry at `[1, 2]` is computed from 7 and 1, so it is `sqrt(7) + 1`. Reducing axis 0 produces four column maxima; reducing axis 1 produces three row sums." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "numpy-matrix-product",
			kind: "multipleChoice",
			title: "Read a Matrix Product",
			prompt: "Let `P = np.matmul(X, Y.T)`. Determine the result shape and the values in its first row.",
			instructions: "Write the operand shapes after transposing Y. Each entry of P is a dot product between one row of X and one row of Y.",
			datasetId: "numpyMiniArrays",
			parts: [{
				id: "product-shape",
				prompt: "What is `P.shape`?",
				correctOptionId: "shape-3-3",
				options: [
					{
						id: "shape-3-3",
						title: "(3, 3)",
						description: "The product keeps the outer dimensions of `(3, 4) @ (4, 3)`."
					},
					{
						id: "shape-3-4",
						title: "(3, 4)",
						description: "This is the shape of X and Y before the transpose and product."
					},
					{
						id: "shape-4-4",
						title: "(4, 4)",
						description: "The matching inner dimension is summed over rather than retained."
					}
				]
			}, {
				id: "first-product-row",
				prompt: "What is `P[0].tolist()`?",
				correctOptionId: "row-10-26-42",
				options: [
					{
						id: "row-10-26-42",
						title: "[10.0, 26.0, 42.0]",
						description: "A row of four ones dotted with each row of Y produces that row’s sum."
					},
					{
						id: "row-1-2-3-4",
						title: "[1.0, 2.0, 3.0, 4.0]",
						description: "This copies the first row of Y instead of taking dot products."
					},
					{
						id: "row-15-18-21-24",
						title: "[15.0, 18.0, 21.0, 24.0]",
						description: "These are the sums of the columns of Y."
					}
				]
			}],
			hintSchedule: [2, 4],
			hints: ["After transposing Y, the multiplication is `(3, 4) @ (4, 3)`.", "Every row of X contains four ones, so its dot product with a row of Y is simply the sum of that Y row."],
			validator: validateMultipleChoiceSelections({
				"product-shape": "shape-3-3",
				"first-product-row": "row-10-26-42"
			}, "Check the transposed operand shape and compute each dot product again."),
			reveal: { explanation: "`Y.T` has shape `(4, 3)`, so multiplying it by X produces a `(3, 3)` matrix. Because each row of X contains only ones, every output row contains the three row sums of Y: 10, 26, and 42." },
			successCopy: "Correct! Good Job!"
		},
		numpyNotebookLab
	]
};
//#endregion
//#region src/lib/pcaMath.ts
function clamp(value, min, max) {
	return Math.min(max, Math.max(min, value));
}
function degrees(radiansValue) {
	return radiansValue * 180 / Math.PI;
}
function add2(a, b) {
	return [a[0] + b[0], a[1] + b[1]];
}
function subtract2(a, b) {
	return [a[0] - b[0], a[1] - b[1]];
}
function dot2(a, b) {
	return a[0] * b[0] + a[1] * b[1];
}
function norm2(v) {
	return Math.hypot(v[0], v[1]);
}
function normalize2(v) {
	const length = norm2(v);
	if (length === 0) return [1, 0];
	return [v[0] / length, v[1] / length];
}
function mean2(points) {
	const total = points.reduce((accumulator, point) => add2(accumulator, point), [0, 0]);
	return [total[0] / points.length, total[1] / points.length];
}
function centerPoints2D(points) {
	const center = mean2(points);
	return points.map((point) => subtract2(point, center));
}
function secondMoment2D(points) {
	const matrix = [[0, 0], [0, 0]];
	for (const [x, y] of points) {
		matrix[0][0] += x * x;
		matrix[0][1] += x * y;
		matrix[1][0] += x * y;
		matrix[1][1] += y * y;
	}
	return matrix.map((row) => row.map((value) => value / points.length));
}
function covariance2D(points) {
	return secondMoment2D(centerPoints2D(points));
}
function largestEigenvector2x2(matrix) {
	const a = matrix[0][0];
	const b = matrix[0][1];
	const d = matrix[1][1];
	if (Math.abs(b) < 1e-12) return a >= d ? [1, 0] : [0, 1];
	return normalize2([b, (a + d + Math.sqrt((a - d) ** 2 + 4 * b * b)) / 2 - a]);
}
function principalDirectionFromPoints2D(points, scoring) {
	return largestEigenvector2x2(scoring === "covariance" ? covariance2D(points) : secondMoment2D(points));
}
function signInvariantAngle2(a, b) {
	const normalizedA = normalize2(a);
	const normalizedB = normalize2(b);
	const cosine = clamp(Math.abs(dot2(normalizedA, normalizedB)), -1, 1);
	return Math.acos(cosine);
}
function explainedVarianceForLine(points, direction, scoring) {
	const prepared = scoring === "covariance" ? centerPoints2D(points) : points;
	const unitDirection = normalize2(direction);
	return prepared.reduce((accumulator, point) => {
		const scalar = dot2(point, unitDirection);
		return accumulator + scalar * scalar;
	}, 0) / prepared.length;
}
function add3(a, b) {
	return [
		a[0] + b[0],
		a[1] + b[1],
		a[2] + b[2]
	];
}
function subtract3(a, b) {
	return [
		a[0] - b[0],
		a[1] - b[1],
		a[2] - b[2]
	];
}
function dot3(a, b) {
	return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
}
function cross3(a, b) {
	return [
		a[1] * b[2] - a[2] * b[1],
		a[2] * b[0] - a[0] * b[2],
		a[0] * b[1] - a[1] * b[0]
	];
}
function norm3(v) {
	return Math.hypot(v[0], v[1], v[2]);
}
function normalize3(v) {
	const length = norm3(v);
	if (length === 0) return [
		1,
		0,
		0
	];
	return [
		v[0] / length,
		v[1] / length,
		v[2] / length
	];
}
function mean3(points) {
	const total = points.reduce((accumulator, point) => add3(accumulator, point), [
		0,
		0,
		0
	]);
	return [
		total[0] / points.length,
		total[1] / points.length,
		total[2] / points.length
	];
}
function centerPoints3D(points) {
	const center = mean3(points);
	return points.map((point) => subtract3(point, center));
}
function covariance3D(points) {
	const centered = centerPoints3D(points);
	const matrix = [
		[
			0,
			0,
			0
		],
		[
			0,
			0,
			0
		],
		[
			0,
			0,
			0
		]
	];
	for (const [x, y, z] of centered) {
		matrix[0][0] += x * x;
		matrix[0][1] += x * y;
		matrix[0][2] += x * z;
		matrix[1][0] += x * y;
		matrix[1][1] += y * y;
		matrix[1][2] += y * z;
		matrix[2][0] += x * z;
		matrix[2][1] += y * z;
		matrix[2][2] += z * z;
	}
	return matrix.map((row) => row.map((value) => value / centered.length));
}
function identityMatrix(size) {
	return Array.from({ length: size }, (_, row) => Array.from({ length: size }, (_, column) => row === column ? 1 : 0));
}
function jacobiEigenDecomposition(matrix) {
	const size = matrix.length;
	const values = matrix.map((row) => [...row]);
	const vectors = identityMatrix(size);
	for (let iteration = 0; iteration < 60; iteration += 1) {
		let p = 0;
		let q = 1;
		let max = Math.abs(values[p][q]);
		for (let row = 0; row < size; row += 1) for (let column = row + 1; column < size; column += 1) {
			const candidate = Math.abs(values[row][column]);
			if (candidate > max) {
				max = candidate;
				p = row;
				q = column;
			}
		}
		if (max < 1e-10) break;
		const app = values[p][p];
		const aqq = values[q][q];
		const apq = values[p][q];
		const angle = .5 * Math.atan2(2 * apq, aqq - app);
		const cosine = Math.cos(angle);
		const sine = Math.sin(angle);
		for (let column = 0; column < size; column += 1) {
			const vip = vectors[column][p];
			const viq = vectors[column][q];
			vectors[column][p] = cosine * vip - sine * viq;
			vectors[column][q] = sine * vip + cosine * viq;
		}
		for (let column = 0; column < size; column += 1) if (column !== p && column !== q) {
			const aip = values[column][p];
			const aiq = values[column][q];
			values[column][p] = cosine * aip - sine * aiq;
			values[p][column] = values[column][p];
			values[column][q] = sine * aip + cosine * aiq;
			values[q][column] = values[column][q];
		}
		values[p][p] = cosine * cosine * app - 2 * sine * cosine * apq + sine * sine * aqq;
		values[q][q] = sine * sine * app + 2 * sine * cosine * apq + cosine * cosine * aqq;
		values[p][q] = 0;
		values[q][p] = 0;
	}
	const eigenpairs = values.map((row, index) => ({
		value: row[index],
		vector: normalize3([
			vectors[0][index],
			vectors[1][index],
			vectors[2][index]
		])
	}));
	eigenpairs.sort((left, right) => right.value - left.value);
	return {
		eigenvalues: eigenpairs.map((pair) => pair.value),
		eigenvectors: eigenpairs.map((pair) => pair.vector)
	};
}
function topTwoPrincipalComponents3D(points) {
	const decomposition = jacobiEigenDecomposition(covariance3D(points));
	return {
		first: decomposition.eigenvectors[0],
		second: decomposition.eigenvectors[1],
		eigenvalues: decomposition.eigenvalues
	};
}
function explainedVarianceForPlane(points, first, second) {
	const unitFirst = normalize3(first);
	const unitSecond = normalize3(second);
	return centerPoints3D(points).reduce((accumulator, point) => {
		const firstCoordinate = dot3(point, unitFirst);
		const secondCoordinate = dot3(point, unitSecond);
		return accumulator + firstCoordinate * firstCoordinate + secondCoordinate * secondCoordinate;
	}, 0) / points.length;
}
function signInvariantAngle3(a, b) {
	const normalizedA = normalize3(a);
	const normalizedB = normalize3(b);
	const cosine = clamp(Math.abs(dot3(normalizedA, normalizedB)), -1, 1);
	return Math.acos(cosine);
}
function pointsAlmostEqual(expected, actual, tolerance) {
	if (expected.length !== actual.length) return false;
	return expected.every((value, index) => Math.abs(value - actual[index]) <= tolerance);
}
function matrixAlmostEqual(expected, actual, tolerance) {
	if (expected.length !== actual.length) return false;
	return expected.every((row, rowIndex) => {
		var _actual$rowIndex;
		return pointsAlmostEqual(row, (_actual$rowIndex = actual[rowIndex]) !== null && _actual$rowIndex !== void 0 ? _actual$rowIndex : [], tolerance);
	});
}
function mulberry32(seed) {
	let current = seed >>> 0;
	return () => {
		current += 1831565813;
		let value = current;
		value = Math.imul(value ^ value >>> 15, value | 1);
		value ^= value + Math.imul(value ^ value >>> 7, value | 61);
		return ((value ^ value >>> 14) >>> 0) / 4294967296;
	};
}
function seededGaussian(seed) {
	const random = mulberry32(seed);
	return () => {
		const u = Math.max(random(), 1e-9);
		const v = Math.max(random(), 1e-9);
		return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
	};
}
//#endregion
//#region src/data/pcaDatasets.ts
function generate2DCloud(options) {
	var _options$translation;
	const gaussian = seededGaussian(options.seed);
	const translation = (_options$translation = options.translation) !== null && _options$translation !== void 0 ? _options$translation : [0, 0];
	const cosine = Math.cos(options.rotationRadians);
	const sine = Math.sin(options.rotationRadians);
	return Array.from({ length: options.count }, () => {
		const major = gaussian() * options.majorScale;
		const minor = gaussian() * options.minorScale;
		return [translation[0] + major * cosine - minor * sine, translation[1] + major * sine + minor * cosine];
	});
}
function generate3DCloud() {
	const gaussian = seededGaussian(314);
	const first = normalize3([
		1,
		1.2,
		.55
	]);
	const helper = normalize3([
		-.72,
		.3,
		.88
	]);
	const second = normalize3([
		helper[0] - first[0] * (first[0] * helper[0] + first[1] * helper[1] + first[2] * helper[2]),
		helper[1] - first[1] * (first[0] * helper[0] + first[1] * helper[1] + first[2] * helper[2]),
		helper[2] - first[2] * (first[0] * helper[0] + first[1] * helper[1] + first[2] * helper[2])
	]);
	const third = normalize3(cross3(first, second));
	return centerPoints3D(Array.from({ length: 34 }, () => {
		const coordinates = [
			gaussian() * 3.4,
			gaussian() * 1.4,
			gaussian() * .45
		];
		return add3(add3([
			first[0] * coordinates[0],
			first[1] * coordinates[0],
			first[2] * coordinates[0]
		], [
			second[0] * coordinates[1],
			second[1] * coordinates[1],
			second[2] * coordinates[1]
		]), [
			third[0] * coordinates[2],
			third[1] * coordinates[2],
			third[2] * coordinates[2]
		]);
	}));
}
var nonCenteredBase = generate2DCloud({
	seed: 7,
	count: 24,
	majorScale: 2.5,
	minorScale: .55,
	rotationRadians: .97,
	translation: [4.4, -3.6]
});
var centeredBase = centerPoints2D(nonCenteredBase);
var nearCircular = centerPoints2D(generate2DCloud({
	seed: 19,
	count: 24,
	majorScale: 1.5,
	minorScale: 1.18,
	rotationRadians: .43
}));
var outlierCore = centerPoints2D(generate2DCloud({
	seed: 33,
	count: 22,
	majorScale: 1.45,
	minorScale: .4,
	rotationRadians: 1.47
}));
var outlierPulled = centerPoints2D([...outlierCore, [5.3, 1.1]]);
var pca3DPoints = generate3DCloud();
var pca3DAnswer = topTwoPrincipalComponents3D(pca3DPoints);
var pca2dDatasets = {
	uncentered: {
		id: "uncentered",
		label: "Uncentered elongated cloud",
		points: nonCenteredBase,
		scoring: "secondMoment",
		answerDirection: principalDirectionFromPoints2D(nonCenteredBase, "secondMoment")
	},
	centered: {
		id: "centered",
		label: "Centered elongated cloud",
		points: centeredBase,
		scoring: "covariance",
		answerDirection: principalDirectionFromPoints2D(centeredBase, "covariance")
	},
	nearCircular: {
		id: "nearCircular",
		label: "Centered almost-circular cloud",
		points: nearCircular,
		scoring: "covariance",
		answerDirection: principalDirectionFromPoints2D(nearCircular, "covariance")
	},
	outlierSensitive: {
		id: "outlierSensitive",
		label: "Outlier-sensitive centered cloud",
		points: outlierPulled,
		scoring: "covariance",
		answerDirection: principalDirectionFromPoints2D(outlierPulled, "covariance"),
		comparisonDirection: principalDirectionFromPoints2D(outlierCore, "covariance"),
		comparisonLabel: "PC1 without the outlier"
	}
};
var pca3dDatasets = { centered3d: {
	id: "centered3d",
	label: "Centered 3D cloud",
	points: pca3DPoints,
	answerFirst: pca3DAnswer.first,
	answerSecond: pca3DAnswer.second
} };
var handCalculationRows = [
	[0, 1],
	[2, 5],
	[4, 9],
	[6, 13]
];
var handCalculationDatasets = { workedExample: {
	id: "workedExample",
	headers: ["x1", "x2"],
	rows: handCalculationRows,
	centeredRows: centerPoints2D(handCalculationRows),
	covariance: covariance2D(handCalculationRows),
	firstDirection: [1, 2]
} };
//#endregion
//#region src/data/pcaAssignment.ts
function validate2DDirection(datasetId, toleranceDegrees, minimumVarianceRatio) {
	const dataset = pca2dDatasets[datasetId];
	const optimalVariance = explainedVarianceForLine(dataset.points, dataset.answerDirection, dataset.scoring);
	return (submission) => {
		const payload = submission;
		const angle = degrees(signInvariantAngle2(payload.direction, dataset.answerDirection));
		const varianceRatio = explainedVarianceForLine(dataset.points, payload.direction, dataset.scoring) / optimalVariance;
		return {
			correct: angle <= toleranceDegrees && varianceRatio >= minimumVarianceRatio,
			message: angle <= toleranceDegrees && varianceRatio >= minimumVarianceRatio ? "Correct! Good Job!" : dataset.scoring === "secondMoment" ? "This is the uncentered case. Rotate toward the line that keeps the projected points far from the origin on average, not the line that merely makes them look most spread out." : "That direction still leaves variance on the table. Rotate toward the longest spread of projected points."
		};
	};
}
function validatePlane(datasetId, toleranceDegrees, minimumVarianceRatio) {
	const dataset = pca3dDatasets[datasetId];
	const optimalVariance = explainedVarianceForPlane(dataset.points, dataset.answerFirst, dataset.answerSecond);
	return (submission) => {
		const payload = submission;
		const firstAngle = degrees(signInvariantAngle3(payload.first, dataset.answerFirst));
		const planeIsGood = explainedVarianceForPlane(dataset.points, payload.first, payload.second) / optimalVariance >= minimumVarianceRatio;
		const firstDirectionIsGood = firstAngle <= toleranceDegrees;
		return {
			correct: firstDirectionIsGood && planeIsGood,
			message: firstDirectionIsGood && planeIsGood ? "Correct! Good Job!" : planeIsGood ? "You found essentially the right plane, but the red first direction is not aligned with the first principal direction yet." : "The plane is close, but you can still capture more variance by rotating the first direction and then rolling the second around it."
		};
	};
}
function validateTableEntry(datasetId) {
	const dataset = handCalculationDatasets[datasetId];
	const targetDirection = normalize2(dataset.firstDirection);
	const sampleCovariance = dataset.covariance.map((row) => row.map((value) => value * dataset.rows.length / (dataset.rows.length - 1)));
	const scatterMatrix = dataset.covariance.map((row) => row.map((value) => value * dataset.rows.length));
	return (submission) => {
		var _rawDirection$, _rawDirection$2;
		const payload = submission;
		if (payload.step === "centeredData") return {
			correct: matrixAlmostEqual(dataset.centeredRows, payload.values, .05),
			message: "Check the mean of each column again, then subtract it from every entry."
		};
		if (payload.step === "covariance") return {
			correct: matrixAlmostEqual(dataset.covariance, payload.values, .05) || matrixAlmostEqual(sampleCovariance, payload.values, .05) || matrixAlmostEqual(scatterMatrix, payload.values, .05),
			message: "Use the centered data from the previous step to compute the covariance matrix."
		};
		const rawDirection = payload.values;
		if (Math.hypot((_rawDirection$ = rawDirection[0]) !== null && _rawDirection$ !== void 0 ? _rawDirection$ : 0, (_rawDirection$2 = rawDirection[1]) !== null && _rawDirection$2 !== void 0 ? _rawDirection$2 : 0) < 1e-9) return {
			correct: false,
			message: "Enter a non-zero direction vector for the first principal direction."
		};
		const normalizedDirection = normalize2([rawDirection[0], rawDirection[1]]);
		return {
			correct: pointsAlmostEqual(targetDirection, normalizedDirection, .08) || pointsAlmostEqual(targetDirection, [-normalizedDirection[0], -normalizedDirection[1]], .08),
			message: "The first principal direction should line up with the largest eigenvector of the covariance matrix."
		};
	};
}
var pcaAssignment = {
	id: "pca",
	displayNumber: 1,
	version: 7,
	title: "Principal Component Analysis",
	topic: "Dimensionality Reduction",
	description: "Work through centered and uncentered PCA, outlier sensitivity, scaling choices, and one hand-calculation problem before exporting your JSON submission.",
	published: true,
	questions: [
		{
			id: "pca-uncentered",
			kind: "pca2dLine",
			title: "Uncentered PCA",
			prompt: "Rotate the line until the projected variance is as large as possible. This is the PCA objective.",
			instructions: "The line always passes through the origin. Watch the right-hand view with the origin fixed in place: the uncentered PCA direction can look wrong if you are expecting the widest visible spread.",
			datasetId: "uncentered",
			minimumVarianceRatio: .985,
			initialAngleDeg: -18,
			tolerance: 12,
			hintSchedule: [2, 4],
			hints: ["Do not re-center the projected points mentally. The origin stays fixed in the middle of the right-hand view.", "Because the data are not centered, the direction chosen by uncentered PCA follows large average squared distance from the origin rather than the visually longest spread of the cluster."],
			validator: validate2DDirection("uncentered", 12, .985),
			reveal: { explanation: "Without centering, the objective is dominated by how far projections sit from the origin. That pulls the chosen line away from the cloud’s natural elongation, which is why centering matters before PCA." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "pca-centered",
			kind: "pca2dLine",
			title: "Centered PCA",
			prompt: "Rotate the line until the projected variance is as large as possible. This is the PCA objective.",
			datasetId: "centered",
			minimumVarianceRatio: .99,
			initialAngleDeg: 132,
			tolerance: 10,
			hints: ["Centering removes the mean offset, so only the shape of the cloud matters now.", "The best line should follow the long diagonal direction of the points."],
			validator: validate2DDirection("centered", 10, .99),
			reveal: { explanation: "Once the mean is removed, PCA finds the direction of largest spread relative to the centered cloud. That matches the long axis you can see directly." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "pca-near-circular",
			kind: "pca2dLine",
			title: "Nearly Circular Cloud",
			prompt: "This centered cloud is much closer to circular. Rotate the line until the projected points spread out as much as possible.",
			instructions: "The best direction still exists, but the answer is less obvious because the two axis spreads are closer together.",
			datasetId: "nearCircular",
			minimumVarianceRatio: .995,
			initialAngleDeg: 86,
			tolerance: 8,
			hintSchedule: [2, 5],
			hints: ["Because the cloud is close to circular, small angle changes make smaller variance changes than before.", "Look for the slightly longer diameter rather than a dramatic long axis."],
			validator: validate2DDirection("nearCircular", 8, .995),
			reveal: { explanation: "Even when the cloud looks almost round, PCA still picks the direction with the slightly larger variance. The difference is smaller, so the optimum is harder to see." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "pca-outlier",
			kind: "pca2dLine",
			title: "Outlier Sensitivity",
			prompt: "Rotate the line until the projected points spread out as much as possible, then compare the revealed answer with the ghost reference.",
			instructions: "One extreme point has been added to this centered cloud. PCA still follows variance, even when a single point changes that variance a lot.",
			datasetId: "outlierSensitive",
			minimumVarianceRatio: .985,
			initialAngleDeg: 24,
			tolerance: 12,
			hintSchedule: [2, 4],
			hints: ["An outlier can drag the best direction toward itself because it contributes a lot of squared distance.", "When the answer is revealed, compare it with the ghost line that shows what the cloud wanted before the outlier was added."],
			validator: validate2DDirection("outlierSensitive", 12, .985),
			reveal: { explanation: "PCA is sensitive to outliers because variance squares large deviations. The ghost line shows how the dominant direction would look without the extreme point." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "pca-standardize",
			kind: "multipleChoice",
			title: "House Prices and Bedrooms",
			prompt: "Answer both questions about running PCA on centered house-price and bedroom data.",
			instructions: "First predict what centered-but-unscaled PCA will do, then choose how to make the representation sensitive to all features.",
			datasetId: "housePrices",
			parts: [{
				id: "pca-behavior",
				prompt: "Suppose you are predicting a particular house's value. You have information about housing prices in the area and the number of bedrooms for each. If you center the data and run PCA, what will happen?",
				correctOptionId: "price-dominates",
				options: [
					{
						id: "equal-weight",
						title: "PCA will weight price and bedrooms equally",
						description: "Centering alone does not force equal influence across features."
					},
					{
						id: "price-dominates",
						title: "PCA will mostly follow housing price",
						description: "Because price is on a much larger numerical scale, its variance dominates the principal direction."
					},
					{
						id: "bedrooms-dominate",
						title: "PCA will mostly follow bedrooms",
						description: "Bedroom count has smaller numerical scale here, so it will not dominate the covariance."
					}
				]
			}, {
				id: "pca-fix",
				prompt: "What can you do so that predictions will be sensitive to all features?",
				correctOptionId: "standardize",
				options: [
					{
						id: "recenter",
						title: "Center the data again",
						description: "Repeated centering does not change the scale imbalance between price and bedrooms."
					},
					{
						id: "change-denominator",
						title: "Use 1/(n-1) instead of 1/n",
						description: "Changing the covariance denominator does not fix feature-scale dominance."
					},
					{
						id: "standardize",
						title: "Standardize each feature after centering",
						description: "Put price and bedrooms on comparable scales before PCA so both can matter."
					}
				]
			}],
			tolerance: 0,
			hints: ["Centering changes the mean but not the units, so the larger-scale feature still contributes much larger squared values.", "To make PCA sensitive to all features, you need a preprocessing step that changes scale, not just location."],
			validator: validateMultipleChoiceSelections({
				"pca-behavior": "price-dominates",
				"pca-fix": "standardize"
			}, "Centering alone does not stop the larger-scale price feature from dominating. Try again."),
			reveal: { explanation: "With centered but unscaled inputs, PCA is driven mostly by house price because its numerical variation is so much larger than bedroom count. Standardizing after centering makes both features contribute on comparable footing." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "pca-3d-plane",
			kind: "pca3dPlane",
			title: "A Two-Dimensional PCA Plane",
			prompt: "Rotate the first principal direction with your mouse or trackpad, then use the left and right arrow keys to rotate the second direction around it until the projected points spread out as much as possible.",
			instructions: "The left panel shows the centered 3D cloud and the candidate projection plane. The right panel shows the orthogonal view of that plane with the projected points.",
			datasetId: "centered3d",
			minimumVarianceRatio: .985,
			initialAzimuthDeg: 34,
			initialElevationDeg: 11,
			initialRollDeg: 35,
			tolerance: 18,
			hintSchedule: [2, 5],
			hints: ["Start by rotating the red first-direction arrow toward the longest spread in the point cloud.", "Then use the arrow keys to roll the second direction so the right-hand plane view captures as much spread as possible."],
			validator: validatePlane("centered3d", 18, .985),
			reveal: { explanation: "The best PCA plane is spanned by the top two eigenvectors of the covariance matrix. The right-hand view makes it easier to judge how much of the 3D variance your plane retains." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "pca-hand-calculation",
			kind: "tableEntry",
			title: "Work the Numbers by Hand",
			prompt: "Center the data, enter the covariance matrix, and then enter a first principal direction for the four 2D points below.",
			instructions: "The direction can be any non-zero vector pointing along the first principal direction.",
			datasetId: "workedExample",
			substeps: [
				"Center the data",
				"Enter the covariance matrix",
				"Enter the first principal direction"
			],
			tolerance: .05,
			hintSchedule: [2, 4],
			hints: ["First compute the mean of each column, then subtract that mean from every row.", "Once the covariance matrix is filled in, the first principal direction points along its largest eigenvector."],
			validator: validateTableEntry("workedExample"),
			reveal: { explanation: "Because the centered points all lie on the same diagonal line, the covariance matrix has one dominant direction. Any non-zero multiple of that direction represents the same principal axis." },
			successCopy: "Correct! Good Job!"
		},
		pcaCodeLab
	]
};
principalDirectionFromPoints2D(handCalculationDatasets.workedExample.rows, "covariance");
//#endregion
//#region src/data/randomForestDatasets.ts
var randomForestClasses = [{
	label: "Class 0",
	color: "#b95f43"
}, {
	label: "Class 1",
	color: "#1c7b8a"
}];
var forestRows = [
	{
		id: "A",
		x: 1,
		y: 1,
		label: 0
	},
	{
		id: "B",
		x: 2,
		y: 3,
		label: 0
	},
	{
		id: "C",
		x: 3,
		y: 4,
		label: 0
	},
	{
		id: "D",
		x: 4,
		y: 2,
		label: 1
	},
	{
		id: "E",
		x: 5,
		y: 7,
		label: 0
	},
	{
		id: "F",
		x: 6,
		y: 5,
		label: 1
	},
	{
		id: "G",
		x: 7,
		y: 6,
		label: 1
	},
	{
		id: "H",
		x: 8,
		y: 8,
		label: 1
	}
];
var plotBounds = {
	minX: 0,
	maxX: 9,
	minY: 0,
	maxY: 9
};
var randomForestDatasets = {
	bootstrapAudit: {
		id: "bootstrapAudit",
		kind: "bootstrapAudit",
		label: "One bootstrap sample of eight training rows",
		classes: randomForestClasses,
		rows: forestRows,
		draws: [
			"C",
			"A",
			"C",
			"H",
			"F",
			"C",
			"A",
			"D"
		]
	},
	featureSubsamplingGeometry: {
		id: "featureSubsamplingGeometry",
		kind: "featureSubsamplingGeometry",
		label: "Two trees, two random feature subsets",
		classes: randomForestClasses,
		rows: forestRows,
		trees: [{
			id: "tree-a",
			label: "Tree A (x only)",
			allowedFeature: "x",
			draws: [
				"A",
				"B",
				"B",
				"C",
				"D",
				"E",
				"F",
				"G"
			],
			color: "#8f5f32",
			candidates: [
				{
					id: "tree-a-x-2.5",
					feature: "x",
					threshold: 2.5
				},
				{
					id: "tree-a-x-3.5",
					feature: "x",
					threshold: 3.5
				},
				{
					id: "tree-a-x-4.5",
					feature: "x",
					threshold: 4.5
				},
				{
					id: "tree-a-x-5.5",
					feature: "x",
					threshold: 5.5
				}
			]
		}, {
			id: "tree-b",
			label: "Tree B (y only)",
			allowedFeature: "y",
			draws: [
				"A",
				"C",
				"D",
				"E",
				"F",
				"F",
				"G",
				"H"
			],
			color: "#725fa3",
			candidates: [
				{
					id: "tree-b-y-2.5",
					feature: "y",
					threshold: 2.5
				},
				{
					id: "tree-b-y-4.5",
					feature: "y",
					threshold: 4.5
				},
				{
					id: "tree-b-y-6.5",
					feature: "y",
					threshold: 6.5
				}
			]
		}],
		probes: [{
			id: "P",
			x: 2.5,
			y: 6.5
		}, {
			id: "Q",
			x: 6.5,
			y: 3
		}],
		bounds: plotBounds
	},
	forestVoteGeometry: {
		id: "forestVoteGeometry",
		kind: "forestVoteGeometry",
		label: "Aggregate five overlapping stump predictions",
		classes: randomForestClasses,
		rows: forestRows,
		trees: [
			{
				id: "T1",
				feature: "x",
				threshold: 3.5,
				leftLabel: 0,
				rightLabel: 1
			},
			{
				id: "T2",
				feature: "y",
				threshold: 4.5,
				leftLabel: 0,
				rightLabel: 1
			},
			{
				id: "T3",
				feature: "x",
				threshold: 5.5,
				leftLabel: 0,
				rightLabel: 1
			},
			{
				id: "T4",
				feature: "y",
				threshold: 2.5,
				leftLabel: 1,
				rightLabel: 0
			},
			{
				id: "T5",
				feature: "x",
				threshold: 7,
				leftLabel: 1,
				rightLabel: 0
			}
		],
		probes: [
			{
				id: "P",
				x: 2,
				y: 6
			},
			{
				id: "Q",
				x: 4,
				y: 3
			},
			{
				id: "R",
				x: 6,
				y: 6
			},
			{
				id: "S",
				x: 7.5,
				y: 2
			},
			{
				id: "T",
				x: 5,
				y: 5
			}
		],
		bounds: plotBounds
	},
	oobEstimate: {
		id: "oobEstimate",
		kind: "oobEstimate",
		label: "Out-of-bag votes (blank means the row trained that tree)",
		classes: randomForestClasses,
		rows: forestRows,
		trees: [
			{
				id: "T1",
				predictions: {
					A: 0,
					C: 0,
					E: 1,
					G: 1
				}
			},
			{
				id: "T2",
				predictions: {
					B: 0,
					C: 1,
					F: 1,
					H: 0
				}
			},
			{
				id: "T3",
				predictions: {
					A: 0,
					D: 1,
					E: 1,
					H: 1
				}
			},
			{
				id: "T4",
				predictions: {
					B: 0,
					D: 1,
					F: 1,
					G: 1
				}
			},
			{
				id: "T5",
				predictions: {
					A: 1,
					C: 0,
					F: 0,
					H: 0
				}
			},
			{
				id: "T6",
				predictions: {
					B: 1,
					D: 0,
					E: 0,
					G: 1
				}
			}
		]
	},
	varianceReduction: {
		id: "varianceReduction",
		kind: "varianceReduction",
		label: "How tree correlation limits variance reduction",
		classes: randomForestClasses,
		singleTreeVariance: .24,
		scenarios: [
			{
				id: "A",
				label: "Forest A",
				treeCount: 25,
				correlation: .08
			},
			{
				id: "B",
				label: "Forest B",
				treeCount: 100,
				correlation: .45
			},
			{
				id: "C",
				label: "Forest C",
				treeCount: 16,
				correlation: .02
			}
		],
		interventions: [
			{
				id: "feature-subsampling",
				label: "Sample a subset of features at each split",
				description: "Trees are less likely to repeat the same dominant split."
			},
			{
				id: "same-bootstrap",
				label: "Give every tree the same bootstrap sample",
				description: "Trees see more similar training data."
			},
			{
				id: "same-seed",
				label: "Reuse one random seed for every tree",
				description: "Trees repeat more of the same random choices."
			}
		]
	},
	codeTrace: {
		id: "codeTrace",
		kind: "codeTrace",
		label: "Trace a compact random-forest implementation",
		classes: randomForestClasses,
		statements: [
			{
				id: "S1",
				code: "for tree_seed in seeds:"
			},
			{
				id: "S2",
				code: "    sample = rng.choice(n, size=n, replace=True)"
			},
			{
				id: "S3",
				code: "    features = rng.choice(p, size=m, replace=False)"
			},
			{
				id: "S4",
				code: "    tree.fit(X[sample][:, features], y[sample])"
			},
			{
				id: "S5",
				code: "    vote = tree.predict(X_query[:, features])"
			},
			{
				id: "S6",
				code: "    votes.append(vote)"
			},
			{
				id: "S7",
				code: "return majority_vote(votes, axis=0)"
			}
		],
		rows: [
			{
				id: "A",
				features: [1, 9],
				label: 0
			},
			{
				id: "B",
				features: [2, 4],
				label: 0
			},
			{
				id: "C",
				features: [8, 6],
				label: 1
			},
			{
				id: "D",
				features: [9, 2],
				label: 1
			}
		],
		bootstrapDraws: [
			"C",
			"A",
			"C",
			"D"
		],
		selectedFeatureIndices: [1],
		query: [7, 5],
		treeVotes: [
			1,
			0,
			1,
			1,
			0
		],
		statementOptions: [
			{
				id: "S2",
				label: "S2"
			},
			{
				id: "S3",
				label: "S3"
			},
			{
				id: "S4",
				label: "S4"
			},
			{
				id: "S5",
				label: "S5"
			},
			{
				id: "S7",
				label: "S7"
			}
		]
	}
};
//#endregion
//#region src/lib/randomForestMath.ts
/**
* Count bootstrap multiplicities without collapsing repeated draws. Keeping the
* row IDs in the result makes the value suitable for JSON submission and for a
* later Gradescope implementation in another language.
*/
function bootstrapMultiplicities(rowIds, draws) {
	const counts = Object.fromEntries(rowIds.map((rowId) => [rowId, 0]));
	draws.forEach((rowId) => {
		if (!(rowId in counts)) throw new Error(`Unknown bootstrap row ID: ${rowId}`);
		counts[rowId] += 1;
	});
	return counts;
}
function outOfBagIds(rowIds, draws) {
	const selected = new Set(draws);
	return rowIds.filter((rowId) => !selected.has(rowId));
}
function giniFromBinaryCounts(counts) {
	const total = counts.negative + counts.positive;
	if (total === 0) return 0;
	const negativeRatio = counts.negative / total;
	const positiveRatio = counts.positive / total;
	return 1 - negativeRatio ** 2 - positiveRatio ** 2;
}
function majorityVote(labels) {
	const positiveVotes = labels.filter((label) => label === 1).length;
	return positiveVotes > labels.length - positiveVotes ? 1 : 0;
}
function countLabels(rows) {
	return rows.reduce((counts, row) => row.label === 1 ? {
		...counts,
		positive: counts.positive + 1
	} : {
		...counts,
		negative: counts.negative + 1
	}, {
		negative: 0,
		positive: 0
	});
}
function expandBootstrapRows(rows, draws) {
	const rowsById = new Map(rows.map((row) => [row.id, row]));
	return draws.map((rowId) => {
		const row = rowsById.get(rowId);
		if (!row) throw new Error(`Unknown bootstrap row ID: ${rowId}`);
		return row;
	});
}
function evaluateStump(rows, candidate, draws = rows.map((row) => row.id)) {
	const bootstrapRows = expandBootstrapRows(rows, draws);
	const leftRows = bootstrapRows.filter((row) => row[candidate.feature] <= candidate.threshold);
	const rightRows = bootstrapRows.filter((row) => row[candidate.feature] > candidate.threshold);
	const leftCounts = countLabels(leftRows);
	const rightCounts = countLabels(rightRows);
	const total = bootstrapRows.length || 1;
	const weightedGini = leftRows.length / total * giniFromBinaryCounts(leftCounts) + rightRows.length / total * giniFromBinaryCounts(rightCounts);
	return {
		candidate,
		leftCounts,
		rightCounts,
		leftLabel: majorityVote([...Array.from({ length: leftCounts.negative }, () => 0), ...Array.from({ length: leftCounts.positive }, () => 1)]),
		rightLabel: majorityVote([...Array.from({ length: rightCounts.negative }, () => 0), ...Array.from({ length: rightCounts.positive }, () => 1)]),
		weightedGini
	};
}
function findBestStump(rows, candidates, draws = rows.map((row) => row.id)) {
	const [firstCandidate, ...remainingCandidates] = candidates;
	if (!firstCandidate) throw new Error("findBestStump requires at least one candidate split.");
	return remainingCandidates.reduce((best, candidate) => {
		const next = evaluateStump(rows, candidate, draws);
		return next.weightedGini < best.weightedGini ? next : best;
	}, evaluateStump(rows, firstCandidate, draws));
}
function trainedStumpFromEvaluation(evaluation) {
	return {
		id: evaluation.candidate.id,
		feature: evaluation.candidate.feature,
		threshold: evaluation.candidate.threshold,
		leftLabel: evaluation.leftLabel,
		rightLabel: evaluation.rightLabel
	};
}
function predictStump(stump, point) {
	return point[stump.feature] <= stump.threshold ? stump.leftLabel : stump.rightLabel;
}
function forestVotes(stumps, point) {
	return stumps.map((stump) => predictStump(stump, point));
}
function predictForest(stumps, point) {
	return majorityVote(forestVotes(stumps, point));
}
function aggregateOobPredictions(rowIds, trees) {
	return rowIds.map((rowId) => {
		const votes = trees.flatMap((tree) => tree.predictions[rowId] === void 0 ? [] : [tree.predictions[rowId]]);
		return {
			rowId,
			votes,
			prediction: votes.length ? majorityVote(votes) : null
		};
	});
}
function oobAccuracy(rows, trees) {
	const rowsWithPrediction = aggregateOobPredictions(rows.map((row) => row.id), trees).filter((prediction) => prediction.prediction !== null);
	if (!rowsWithPrediction.length) return 0;
	const labelsById = new Map(rows.map((row) => [row.id, row.label]));
	return rowsWithPrediction.filter((prediction) => labelsById.get(prediction.rowId) === prediction.prediction).length / rowsWithPrediction.length;
}
/**
* Approximate variance of the average of T exchangeable tree predictions.
* rho is their pairwise correlation and singleTreeVariance is sigma squared.
*/
function correlatedEnsembleVariance(singleTreeVariance, correlation, treeCount) {
	if (treeCount < 1 || !Number.isInteger(treeCount)) throw new Error("treeCount must be a positive integer.");
	if (correlation < 0 || correlation > 1) throw new Error("correlation must lie between 0 and 1.");
	return correlation * singleTreeVariance + (1 - correlation) * singleTreeVariance / treeCount;
}
//#endregion
//#region src/data/randomForestAssignment.ts
var NUMERIC_TOLERANCE = .0015;
function sameIds(actual, expected) {
	return Array.isArray(actual) && actual.every((value) => typeof value === "string") && [...actual].sort().join("|") === [...expected].sort().join("|");
}
function sameLabelRecord(actual, expected) {
	return Object.entries(expected).every(([id, label]) => (actual === null || actual === void 0 ? void 0 : actual[id]) === label);
}
function validateBootstrapAudit(datasetId) {
	const dataset = randomForestDatasets[datasetId];
	const rowIds = dataset.rows.map((row) => row.id);
	const expectedCounts = bootstrapMultiplicities(rowIds, dataset.draws);
	const expectedOobIds = outOfBagIds(rowIds, dataset.draws);
	return (submission) => {
		const payload = submission;
		const countsCorrect = Object.entries(expectedCounts).every(([rowId, count]) => {
			var _payload$multipliciti;
			return ((_payload$multipliciti = payload.multiplicities) === null || _payload$multipliciti === void 0 ? void 0 : _payload$multipliciti[rowId]) === count;
		});
		const oobCorrect = sameIds(payload.oobIds, expectedOobIds);
		return {
			correct: countsCorrect && oobCorrect,
			message: countsCorrect && oobCorrect ? "Correct! Good Job!" : "Count every repeated draw, then mark exactly the rows whose count is zero."
		};
	};
}
function expectedFeatureGeometryAnswers(dataset) {
	const selectedSplits = {};
	const trainedTrees = new Map(dataset.trees.map((tree) => {
		const best = findBestStump(dataset.rows, tree.candidates, tree.draws);
		selectedSplits[tree.id] = best.candidate.id;
		return [tree.id, trainedStumpFromEvaluation(best)];
	}));
	return {
		selectedSplits,
		predictions: Object.fromEntries(dataset.probes.map((probe) => [probe.id, Object.fromEntries(dataset.trees.map((tree) => [tree.id, predictStump(trainedTrees.get(tree.id), probe)]))]))
	};
}
function validateFeatureGeometry(datasetId) {
	const dataset = randomForestDatasets[datasetId];
	const expected = expectedFeatureGeometryAnswers(dataset);
	return (submission) => {
		const payload = submission;
		const splitsCorrect = Object.entries(expected.selectedSplits).every(([treeId, splitId]) => {
			var _payload$selectedSpli;
			return ((_payload$selectedSpli = payload.selectedSplits) === null || _payload$selectedSpli === void 0 ? void 0 : _payload$selectedSpli[treeId]) === splitId;
		});
		const predictionsCorrect = Object.entries(expected.predictions).every(([probeId, labels]) => {
			var _payload$predictions;
			return sameLabelRecord((_payload$predictions = payload.predictions) === null || _payload$predictions === void 0 ? void 0 : _payload$predictions[probeId], labels);
		});
		return {
			correct: splitsCorrect && predictionsCorrect,
			message: splitsCorrect && predictionsCorrect ? "Correct! Good Job!" : "Score each tree on its own repeated bootstrap rows and only its allowed feature, then trace both probe points."
		};
	};
}
function validateForestGeometry(datasetId) {
	const dataset = randomForestDatasets[datasetId];
	const expected = Object.fromEntries(dataset.probes.map((probe) => [probe.id, predictForest(dataset.trees, probe)]));
	return (submission) => {
		const correct = sameLabelRecord(submission.predictions, expected);
		return {
			correct,
			message: correct ? "Correct! Good Job!" : "Trace all five tree rules for each probe and use the majority, not the nearest training point."
		};
	};
}
function expectedOobAnswers(dataset) {
	const aggregated = aggregateOobPredictions(dataset.rows.map((row) => row.id), dataset.trees);
	return {
		predictions: Object.fromEntries(aggregated.map((entry) => [entry.rowId, entry.prediction])),
		accuracy: oobAccuracy(dataset.rows, dataset.trees)
	};
}
function validateOobEstimate(datasetId) {
	const dataset = randomForestDatasets[datasetId];
	const expected = expectedOobAnswers(dataset);
	return (submission) => {
		const payload = submission;
		const predictionsCorrect = sameLabelRecord(payload.predictions, expected.predictions);
		const accuracyCorrect = typeof payload.accuracy === "number" && Math.abs(payload.accuracy - expected.accuracy) <= NUMERIC_TOLERANCE;
		const correct = predictionsCorrect && accuracyCorrect;
		return {
			correct,
			message: correct ? "Correct! Good Job!" : "For each row, vote using only nonblank OOB cells, then compare those eight votes with the true labels."
		};
	};
}
function expectedVarianceAnswers(dataset) {
	const variances = Object.fromEntries(dataset.scenarios.map((scenario) => [scenario.id, correlatedEnsembleVariance(dataset.singleTreeVariance, scenario.correlation, scenario.treeCount)]));
	return {
		variances,
		bestScenarioId: dataset.scenarios.reduce((best, scenario) => variances[scenario.id] < variances[best.id] ? scenario : best).id,
		interventionId: "feature-subsampling"
	};
}
function validateVariance(datasetId) {
	const dataset = randomForestDatasets[datasetId];
	const expected = expectedVarianceAnswers(dataset);
	return (submission) => {
		const payload = submission;
		const correct = Object.entries(expected.variances).every(([scenarioId, variance]) => {
			var _payload$variances;
			return typeof ((_payload$variances = payload.variances) === null || _payload$variances === void 0 ? void 0 : _payload$variances[scenarioId]) === "number" && Math.abs(payload.variances[scenarioId] - variance) <= NUMERIC_TOLERANCE;
		}) && payload.bestScenarioId === expected.bestScenarioId && payload.interventionId === expected.interventionId;
		return {
			correct,
			message: correct ? "Correct! Good Job!" : "The correlation term does not vanish as more trees are added; calculate all three values before choosing."
		};
	};
}
var randomForestAssignment = {
	id: "random-forests",
	version: 6,
	title: "Random Forests",
	topic: "Ensemble Learning",
	description: "Build a forest from bootstrapped, decorrelated trees; aggregate their predictions; and estimate how well the ensemble generalizes.",
	published: false,
	questions: [
		{
			id: "rf-bootstrap-oob",
			kind: "randomForest",
			title: "Audit a Bootstrap Sample",
			prompt: "Record how many times every training row appears in the draw, then identify the out-of-bag rows.",
			instructions: "A bootstrap sample contains n draws with replacement. Repeated rows count repeatedly; rows with multiplicity zero are OOB for this tree.",
			datasetId: "bootstrapAudit",
			interactionMode: "bootstrapAudit",
			hintSchedule: [2, 4],
			hints: ["Tally the draw from left to right rather than treating it as a set.", "Exactly three row IDs never appear in this sample."],
			validator: validateBootstrapAudit("bootstrapAudit"),
			reveal: { explanation: "Bootstrap sampling changes row weights: duplicates influence the fitted tree multiple times, while omitted rows provide out-of-bag evaluation cases." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "rf-feature-subsampling-geometry",
			kind: "randomForest",
			title: "Grow Two Decorrelated Stumps",
			prompt: "Each tree gets a different bootstrap sample and is allowed to split on only one randomly selected feature. Choose its lowest-Gini threshold, then trace both probes through both fitted stumps.",
			instructions: "Repeated bootstrap IDs count repeatedly. A leaf predicts its majority class; break an exact class tie toward Class 0.",
			datasetId: "featureSubsamplingGeometry",
			interactionMode: "featureSubsamplingGeometry",
			hintSchedule: [2, 4],
			hints: ["Tree A can draw only a vertical line and Tree B only a horizontal line; score each on its own listed draws.", "After choosing a split, recount the bootstrap labels on each side to obtain the two leaf predictions."],
			validator: validateFeatureGeometry("featureSubsamplingGeometry"),
			reveal: { explanation: "Random feature subsets force otherwise strong trees to consider different split directions. Their errors become less correlated, which makes averaging more effective." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "rf-geometric-vote",
			kind: "randomForest",
			title: "Map a Forest by Majority Vote",
			prompt: "Classify each labeled probe by tracing all five axis-aligned trees and taking their majority vote.",
			instructions: "Click a probe in the plot or use the answer buttons. Some trees reverse the usual leaf labels, so the nearest training point is not a reliable shortcut.",
			datasetId: "forestVoteGeometry",
			interactionMode: "forestVoteGeometry",
			hintSchedule: [2, 4],
			hints: ["Make a five-entry vote tally for one probe at a time.", "T4 predicts Class 1 below its horizontal line, while T5 predicts Class 1 to the left of its vertical line."],
			validator: validateForestGeometry("forestVoteGeometry"),
			reveal: { explanation: "A forest can form a nontrivial, piecewise axis-aligned boundary even when every constituent model is only a one-split tree." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "rf-oob-estimate",
			kind: "randomForest",
			title: "Compute an OOB Estimate",
			prompt: "For each training row, aggregate only the trees for which that row was out of bag. Then compute OOB accuracy.",
			instructions: "A blank cell means the tree trained on that row, so including that tree would leak training information into the estimate.",
			datasetId: "oobEstimate",
			interactionMode: "oobEstimate",
			hintSchedule: [2, 4],
			hints: ["Each row has exactly three nonblank OOB votes.", "After voting, compare the eight aggregate predictions against the label column; two are wrong."],
			validator: validateOobEstimate("oobEstimate"),
			reveal: { explanation: "OOB prediction evaluates each row only with trees that did not train on it, producing a validation-like estimate without a separate holdout set." },
			successCopy: "Correct! Good Job!"
		},
		{
			id: "rf-variance-correlation",
			kind: "randomForest",
			title: "Balance Forest Size and Correlation",
			prompt: "Compute the approximate variance of each averaged forest, select the lowest-variance scenario, and choose the intervention that directly reduces tree correlation.",
			instructions: "Use Var(average) = rho * sigma² + (1 - rho) * sigma² / T with single-tree variance sigma² = 0.24. Enter decimals to three places.",
			datasetId: "varianceReduction",
			interactionMode: "varianceReduction",
			hintSchedule: [2, 4],
			hints: ["The rho * sigma² term remains even as T becomes very large.", "One scenario with only 16 trees beats the 100-tree forest because its trees are much less correlated."],
			validator: validateVariance("varianceReduction"),
			reveal: { explanation: "Adding trees reduces the independent part of variance, but correlated errors create a floor. Feature subsampling targets that correlation directly." },
			successCopy: "Correct! Good Job!"
		},
		randomForestCodeLab
	]
};
//#endregion
//#region src/data/regressionCodeLabQuestions.ts
var linearRegressionCode = `import numpy as np

class LinearRegression():
    def __init__(self):
        pass

    def fit(self,X,y):
        '''stores the slope and intercept
        for the model defined by X and y'''
        Xnew=np.ones((X.shape[0],X.shape[1]+1))  # S1
        Xnew[:,1:]=X  # S2
        coeffs=np.linalg.inv(Xnew.T@Xnew)@(Xnew.T@y)  # S3
        self.intercept=coeffs[0]  # S4
        self.coef=coeffs[1:]  # S5

    def predict(self,x):
        '''x is expected to have shape
        (num_test_obs,num_feats)'''
        return x@self.coef+self.intercept  # S6`;
var polynomialRegressionCode = `import numpy as np

class StandardScaler():
    def __init__(self):
        pass

    def fit(self,X):
        self.mean=X.mean(axis=0)  # S1
        self.std=X.std(axis=0)  # S2

    def transform(self,X):
        return (X-self.mean)/self.std  # S3

    def inverse_transform(self,X):
        return X*self.std+self.mean  # S4

class PolynomialFeatures():
    def __init__(self,degree,include_bias=False):
        self.degree=degree
        self.include_bias=include_bias

    def fit_transform(self,X):
        if self.include_bias:
            out=np.ones((len(X),self.degree+1))  # S5
            for i in range(self.degree+1):
              out[:,i]=X**i  # S6

        else:
            out=np.zeros((len(X),self.degree))  # S7
            for i in range(self.degree):
              out[:,i]=X**(i+1)  # S8

        return out  # S9`;
var overfittingCode = `import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

deg8=PolynomialFeatures(8,include_bias=True)  # S1
deg8_train_feats=deg8.fit_transform(scaled_Xtrain)  # S2
deg8_test_feats=deg8.fit_transform(scaled_Xtest)  # S3

deg8_model=LinearRegression(fit_intercept=False)  # S4
deg8_model.fit(deg8_train_feats,ytrain)  # S5

deg8_train_predictions=deg8_model.predict(deg8_train_feats)  # S6
deg8_test_predictions=deg8_model.predict(deg8_test_feats)  # S7`;
var gradientDescentCode = `import numpy as np

class GDRegressor():
    def __init__(self,learning_rate,max_iter):
        self.lr=learning_rate
        self.max_iter=max_iter

    def fit(self,X,y):
        self.coef=np.ones((X.shape[1],))  # S1
        self.intercept=1  # S2
        for i in range(self.max_iter):
            residuals=self.predict(X)-y  # S3
            coef_grad=(X.T)@residuals/len(X)  # S4
            intercept_grad=np.mean(residuals)  # S5
            self.coef-=self.lr*coef_grad  # S6
            self.intercept-=self.lr*intercept_grad  # S7

    def predict(self,X):
        return X@self.coef+self.intercept  # S8`;
var linearRegressionNotebookLab = defineCodeLabQuestion({
	id: "linear-regression-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace the Normal-Equation Model",
	prompt: "Use the completed `5LinearRegression.ipynb` notebook to trace its normal-equation implementation, then diagnose a prediction method that drops the fitted intercept.",
	instructions: "The displayed class is the notebook implementation with statement labels added. Run the fixture and invocation conceptually from top to bottom. Treat values shown as integers as their floating-point equivalents.",
	datasetId: "linear-regression-notebook-v1",
	variantId: "linear-regression-notebook-v1",
	language: "python",
	code: linearRegressionCode,
	fixtureTitle: "Deterministic line with a nonzero intercept",
	fixtureHeading: "Trace data",
	fixture: `X_trace = np.array([
    [0.0],
    [1.0],
    [2.0],
])
y_trace = np.array([1.0, 3.0, 5.0])`,
	invocationTitle: "Notebook commands to trace",
	invocationLead: "After defining the class and trace arrays, Python evaluates:",
	invocation: `model = LinearRegression()
model.fit(X_trace, y_trace)

coef = model.coef.tolist()
intercept = model.intercept
predictions = model.predict(
    np.array([[3.0], [4.0]])
).tolist()`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"S1 and S2 create the design matrix `[[1, 0], [1, 1], [1, 2]]`; the first coefficient therefore belongs to the intercept column.",
		"The three target values lie exactly on `y = 2x + 1`.",
		"A test at `x = 0` isolates the intercept, while a difference between two predictions isolates the slope."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the normal-equation fit",
			prompt: "Mentally execute the notebook class on the trace data. What parameter values and predictions are produced?",
			successCopy: "Correct: the normal equation recovers the exact line `y = 2x + 1`, so the two new predictions are 7 and 9.",
			fields: [
				{
					id: "COEF",
					label: "coef",
					correctOptionId: "COEF_2",
					options: [
						{
							id: "COEF_2",
							label: "[2.0]"
						},
						{
							id: "COEF_1",
							label: "[1.0]"
						},
						{
							id: "COEF_2_1",
							label: "[2.0, 1.0]"
						}
					]
				},
				{
					id: "INTERCEPT",
					label: "intercept",
					correctOptionId: "INTERCEPT_1",
					options: [
						{
							id: "INTERCEPT_1",
							label: "1.0"
						},
						{
							id: "INTERCEPT_0",
							label: "0.0"
						},
						{
							id: "INTERCEPT_2",
							label: "2.0"
						}
					]
				},
				{
					id: "PREDICTIONS",
					label: "predictions",
					correctOptionId: "PREDICTIONS_7_9",
					options: [
						{
							id: "PREDICTIONS_7_9",
							label: "[7.0, 9.0]"
						},
						{
							id: "PREDICTIONS_6_8",
							label: "[6.0, 8.0]"
						},
						{
							id: "PREDICTIONS_NESTED",
							label: "[[7.0], [9.0]]"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Read a changed prediction method",
			prompt: "Suppose S6 were changed to `return x@self.coef`, leaving the fitted parameters unchanged. What would `predictions` become?",
			successCopy: "Correct: the mutant retains the fitted slope of 2 but omits the fitted intercept of 1, lowering every prediction by one.",
			fields: [{
				id: "MUTATED_PREDICTIONS",
				label: "predictions after the change",
				correctOptionId: "MUTATED_6_8",
				options: [
					{
						id: "MUTATED_6_8",
						label: "[6.0, 8.0]"
					},
					{
						id: "MUTATED_7_9",
						label: "[7.0, 9.0]"
					},
					{
						id: "MUTATED_3_4",
						label: "[3.0, 4.0]"
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which assertion passes for the notebook implementation but fails when S6 omits the intercept?",
			successCopy: "Correct: at `x = 0`, the notebook returns the fitted intercept 1, whereas the mutant always returns zero.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_INTERCEPT",
				options: [
					{
						id: "TEST_INTERCEPT",
						label: "Check the prediction at zero",
						description: "`assert np.allclose(model.predict(np.array([[0.0]])), [1.0])`"
					},
					{
						id: "TEST_COEF_SHAPE",
						label: "Check only the coefficient shape",
						description: "`assert model.coef.shape == (1,)`"
					},
					{
						id: "TEST_OUTPUT_SHAPE",
						label: "Check only the prediction shape",
						description: "`assert model.predict(np.array([[3.0], [4.0]])).shape == (2,)`"
					},
					{
						id: "TEST_SLOPE_DIFFERENCE",
						label: "Check only the change between predictions",
						description: "`assert np.allclose(np.diff(model.predict(np.array([[3.0], [4.0]]))), [2.0])`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The leading ones in `Xnew` create an intercept coefficient. S3 solves for `[1, 2]`, S4 stores 1 as the intercept, and S5 stores `[2]` as the slope array. The notebook prediction method uses both quantities. Removing the intercept preserves output shapes and differences between predictions, so a prediction at zero distinguishes the two versions." },
	successCopy: "Notebook Lab complete: the normal-equation fit, intercept mutation, and distinguishing test are all correct."
});
var polynomialRegressionNotebookLab = defineCodeLabQuestion({
	id: "polynomial-regression-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace Scaling and Polynomial Features",
	prompt: "Use the completed `6PolynomialRegression.ipynb` notebook to trace its `StandardScaler` and `PolynomialFeatures` implementations.",
	instructions: "The displayed classes reproduce the notebook code with statement labels added. The two trace values were chosen so their population mean and standard deviation are exact integers.",
	datasetId: "polynomial-regression-notebook-v1",
	variantId: "polynomial-regression-notebook-v1",
	language: "python",
	code: polynomialRegressionCode,
	fixtureTitle: "Two values with mean 2 and standard deviation 1",
	fixtureHeading: "Trace data",
	fixture: `X_trace = np.array([1.0, 3.0])`,
	invocationTitle: "Notebook commands to trace",
	invocationLead: "After defining the classes and trace array, Python evaluates:",
	invocation: `scaler = StandardScaler()
scaler.fit(X_trace)
scaled = scaler.transform(X_trace)

poly = PolynomialFeatures(3)
features = poly.fit_transform(scaled)
restored = scaler.inverse_transform(scaled)`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"For `[1, 3]`, S1 stores 2 and S2 stores the population standard deviation 1.",
		"Because `include_bias` uses its default value, S7 creates three columns and S8 fills them with powers 1, 2, and 3.",
		"The mutation begins with power zero, so both entries in its first column are 1."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace scaling and feature engineering",
			prompt: "Mentally execute the notebook classes. What are the scaled values, cubic feature matrix, and restored values?",
			successCopy: "Correct: scaling maps 1 and 3 to -1 and 1, powers 1 through 3 fill the three feature columns, and inverse transformation recovers the original values.",
			fields: [
				{
					id: "SCALED",
					label: "scaled.tolist()",
					correctOptionId: "SCALED_NEG1_1",
					options: [
						{
							id: "SCALED_NEG1_1",
							label: "[-1.0, 1.0]"
						},
						{
							id: "SCALED_0_1",
							label: "[0.0, 1.0]"
						},
						{
							id: "SCALED_NEG2_2",
							label: "[-2.0, 2.0]"
						}
					]
				},
				{
					id: "FEATURES",
					label: "features.tolist()",
					correctOptionId: "FEATURES_POWERS_1_TO_3",
					options: [
						{
							id: "FEATURES_POWERS_1_TO_3",
							label: "[[-1.0, 1.0, -1.0], [1.0, 1.0, 1.0]]"
						},
						{
							id: "FEATURES_POWERS_0_TO_2",
							label: "[[1.0, -1.0, 1.0], [1.0, 1.0, 1.0]]"
						},
						{
							id: "FEATURES_ONLY_TWO_COLUMNS",
							label: "[[-1.0, 1.0], [1.0, 1.0]]"
						}
					]
				},
				{
					id: "RESTORED",
					label: "restored.tolist()",
					correctOptionId: "RESTORED_1_3",
					options: [
						{
							id: "RESTORED_1_3",
							label: "[1.0, 3.0]"
						},
						{
							id: "RESTORED_NEG1_1",
							label: "[-1.0, 1.0]"
						},
						{
							id: "RESTORED_0_4",
							label: "[0.0, 4.0]"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Read a changed exponent",
			prompt: "Suppose S8 were changed from `out[:,i]=X**(i+1)` to `out[:,i]=X**i`. What would `features.tolist()` become?",
			successCopy: "Correct: the changed loop creates powers zero, one, and two instead of powers one, two, and three.",
			fields: [{
				id: "MUTATED_FEATURES",
				label: "features.tolist() after the change",
				correctOptionId: "MUTATED_POWERS_0_TO_2",
				options: [
					{
						id: "MUTATED_POWERS_0_TO_2",
						label: "[[1.0, -1.0, 1.0], [1.0, 1.0, 1.0]]"
					},
					{
						id: "MUTATED_UNCHANGED",
						label: "[[-1.0, 1.0, -1.0], [1.0, 1.0, 1.0]]"
					},
					{
						id: "MUTATED_TWO_COLUMNS",
						label: "[[1.0, -1.0], [1.0, 1.0]]"
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which assertion passes for the notebook implementation but fails when S8 starts at power zero?",
			successCopy: "Correct: without a bias column, the reference first feature must equal the original input. The mutant instead fills that column with ones.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_FIRST_COLUMN",
				options: [
					{
						id: "TEST_FIRST_COLUMN",
						label: "Check that the first feature is the input",
						description: "`assert np.allclose(features[:, 0], scaled)`"
					},
					{
						id: "TEST_SHAPE",
						label: "Check only the matrix shape",
						description: "`assert features.shape == (2, 3)`"
					},
					{
						id: "TEST_POSITIVE_ROW",
						label: "Check the row produced by positive one",
						description: "`assert np.allclose(features[1], [1.0, 1.0, 1.0])`"
					},
					{
						id: "TEST_FINITE",
						label: "Check only that all entries are finite",
						description: "`assert np.all(np.isfinite(features))`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The scaler stores mean 2 and standard deviation 1, so its output is `[-1, 1]`. With `include_bias=False`, the notebook allocates exactly `degree` columns and S8 starts at exponent one. Replacing `i+1` with `i` silently inserts a bias column and drops the cubic column without changing the matrix shape." },
	successCopy: "Notebook Lab complete: scaling, polynomial feature construction, mutation diagnosis, and testing are all correct."
});
var overfittingNotebookLab = defineCodeLabQuestion({
	id: "overfitting-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace Degree-Eight Features",
	prompt: "Use the completed `7Overfitting.ipynb` notebook to trace the degree-eight feature matrix used by its sklearn linear model.",
	instructions: "The displayed statements reproduce the notebook degree-eight block with statement labels added. This deterministic trace isolates that runnable block: the notebook later calls an undefined `PolynomialRegression` in its metrics loop, and its `test_size=0.8` call places 80% of the data in the test set.",
	datasetId: "overfitting-notebook-v1",
	variantId: "overfitting-notebook-v1",
	language: "python",
	code: overfittingCode,
	fixtureTitle: "Deterministic scaled train and test arrays",
	fixtureHeading: "Trace data",
	fixture: `scaled_Xtrain = np.array([
    [-1.0],
    [ 0.0],
    [ 2.0],
])
ytrain = np.array([1.0, 2.0, 5.0])
scaled_Xtest = np.array([[1.0]])`,
	invocationTitle: "Feature expressions to inspect",
	invocationLead: "After running S1 through S7 on the fixture, Python evaluates:",
	invocation: `feature_shape = deg8_train_feats.shape
negative_row = deg8_train_feats[0, :].tolist()
positive_row = deg8_train_feats[2, :].tolist()`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"A degree-eight transformer with `include_bias=True` makes columns for exponents zero through eight, for nine columns total.",
		"Powers of -1 alternate between -1 and 1, while the zero-degree column is always 1.",
		"Turning off `include_bias` removes only the exponent-zero column; the final `x**8` column remains."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the degree-eight feature matrix",
			prompt: "Mentally execute the displayed sklearn transformation. What shape and two feature rows are produced?",
			successCopy: "Correct: `include_bias=True` produces nine columns ordered as `1, x, x**2, ..., x**8`.",
			fields: [
				{
					id: "FEATURE_SHAPE",
					label: "feature_shape",
					correctOptionId: "SHAPE_3_9",
					options: [
						{
							id: "SHAPE_3_9",
							label: "(3, 9)"
						},
						{
							id: "SHAPE_3_8",
							label: "(3, 8)"
						},
						{
							id: "SHAPE_9_3",
							label: "(9, 3)"
						}
					]
				},
				{
					id: "NEGATIVE_ROW",
					label: "negative_row",
					correctOptionId: "NEGATIVE_WITH_BIAS",
					options: [
						{
							id: "NEGATIVE_WITH_BIAS",
							label: "[1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0]"
						},
						{
							id: "NEGATIVE_WITHOUT_BIAS",
							label: "[-1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0]"
						},
						{
							id: "NEGATIVE_ALL_ONES",
							label: "[1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]"
						}
					]
				},
				{
					id: "POSITIVE_ROW",
					label: "positive_row",
					correctOptionId: "POSITIVE_WITH_BIAS",
					options: [
						{
							id: "POSITIVE_WITH_BIAS",
							label: "[1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0, 128.0, 256.0]"
						},
						{
							id: "POSITIVE_WITHOUT_BIAS",
							label: "[2.0, 4.0, 8.0, 16.0, 32.0, 64.0, 128.0, 256.0]"
						},
						{
							id: "POSITIVE_EVEN_SEQUENCE",
							label: "[1.0, 2.0, 4.0, 6.0, 8.0, 10.0, 12.0, 14.0, 16.0]"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Remove the explicit bias feature",
			prompt: "Suppose S1 were changed to `PolynomialFeatures(8,include_bias=False)`. What would the feature shape and `negative_row` become?",
			successCopy: "Correct: disabling the bias removes the leading exponent-zero column, leaving powers one through eight.",
			fields: [{
				id: "MUTATED_SUMMARY",
				label: "(feature_shape, negative_row) after the change",
				correctOptionId: "MUTATED_NO_BIAS",
				options: [
					{
						id: "MUTATED_NO_BIAS",
						label: "((3, 8), [-1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0])"
					},
					{
						id: "MUTATED_UNCHANGED",
						label: "((3, 9), [1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0])"
					},
					{
						id: "MUTATED_DROP_HIGHEST",
						label: "((3, 8), [1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0])"
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which assertion passes for the notebook feature construction but fails when `include_bias=False`?",
			successCopy: "Correct: only the reference matrix has nine columns. Both versions retain three rows, finite entries, and the final value `2**8 = 256`.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_NINE_COLUMNS",
				options: [
					{
						id: "TEST_NINE_COLUMNS",
						label: "Check for the bias column in the shape",
						description: "`assert deg8_train_feats.shape == (3, 9)`"
					},
					{
						id: "TEST_THREE_ROWS",
						label: "Check only the number of observations",
						description: "`assert deg8_train_feats.shape[0] == 3`"
					},
					{
						id: "TEST_HIGHEST_POWER",
						label: "Check only the highest power",
						description: "`assert deg8_train_feats[-1, -1] == 256`"
					},
					{
						id: "TEST_FINITE_FEATURES",
						label: "Check only that all entries are finite",
						description: "`assert np.all(np.isfinite(deg8_train_feats))`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The notebook asks sklearn for all polynomial powers through degree eight and explicitly includes the constant column, so the feature matrix has nine columns. Its linear model correspondingly uses `fit_intercept=False`. Disabling the bias removes the first column but does not remove `x**8`. Separately, the later metrics loop cannot execute until `PolynomialRegression` is defined or replaced with the imported sklearn classes." },
	successCopy: "Notebook Lab complete: degree-eight features, explicit bias handling, mutation diagnosis, and testing are all correct."
});
var gradientDescentNotebookLab = defineCodeLabQuestion({
	id: "gradient-descent-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace One Gradient Step",
	prompt: "Use the completed `8GradientDescent.ipynb` notebook to trace one iteration of its `GDRegressor` and diagnose a reversed residual.",
	instructions: "The displayed class is the notebook implementation with statement labels added. With `max_iter=1`, begin from the coefficient and intercept values assigned at S1 and S2 and execute exactly one update.",
	datasetId: "gradient-descent-notebook-v1",
	variantId: "gradient-descent-notebook-v1",
	language: "python",
	code: gradientDescentCode,
	fixtureTitle: "Two observations for one gradient step",
	fixtureHeading: "Trace data",
	fixture: `X_trace = np.array([
    [0.0],
    [1.0],
])
y_trace = np.array([1.0, 3.0])`,
	invocationTitle: "Notebook commands to trace",
	invocationLead: "After defining the class and trace arrays, Python evaluates:",
	invocation: `model = GDRegressor(learning_rate=0.1, max_iter=1)
model.fit(X_trace, y_trace)

coef = model.coef.tolist()
intercept = model.intercept
predictions = model.predict(X_trace).tolist()`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"Before the update, S1 and S2 make the predictions `[1, 2]`, so S3 gives residuals `[0, -1]`.",
		"S4 and S5 both equal `-0.5`; subtracting `0.1 * -0.5` adds 0.05 to each parameter.",
		"Reversing the residual reverses both gradients while S6 and S7 still subtract them, so that mutation moves uphill on this fixture."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace one notebook iteration",
			prompt: "Mentally execute one iteration. What are the initial residuals, updated parameters, and predictions after the update?",
			successCopy: "Correct: both gradients are -0.5, so one step raises the coefficient and intercept from 1 to 1.05 and produces predictions 1.05 and 2.10.",
			fields: [
				{
					id: "INITIAL_RESIDUALS",
					label: "residuals at S3",
					correctOptionId: "RESIDUALS_0_NEG1",
					options: [
						{
							id: "RESIDUALS_0_NEG1",
							label: "[0.0, -1.0]"
						},
						{
							id: "RESIDUALS_0_1",
							label: "[0.0, 1.0]"
						},
						{
							id: "RESIDUALS_NEG1_NEG2",
							label: "[-1.0, -2.0]"
						}
					]
				},
				{
					id: "UPDATED_PARAMETERS",
					label: "(coef, intercept)",
					correctOptionId: "PARAMETERS_1_05",
					options: [
						{
							id: "PARAMETERS_1_05",
							label: "([1.05], 1.05)"
						},
						{
							id: "PARAMETERS_0_95",
							label: "([0.95], 0.95)"
						},
						{
							id: "PARAMETERS_1_10",
							label: "([1.10], 1.10)"
						}
					]
				},
				{
					id: "PREDICTIONS",
					label: "predictions",
					correctOptionId: "PREDICTIONS_1_05_2_10",
					options: [
						{
							id: "PREDICTIONS_1_05_2_10",
							label: "[1.05, 2.10]"
						},
						{
							id: "PREDICTIONS_0_95_1_90",
							label: "[0.95, 1.90]"
						},
						{
							id: "PREDICTIONS_1_05_3_10",
							label: "[1.05, 3.10]"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Reverse the residual",
			prompt: "Suppose S3 were changed to `residuals=y-self.predict(X)`, while S6 and S7 still subtract the gradients. What parameters and predictions would result?",
			successCopy: "Correct: reversing the residual makes both gradients positive 0.5, so the unchanged subtraction updates both parameters to 0.95.",
			fields: [{
				id: "MUTATED_RESULT",
				label: "(coef, intercept, predictions) after the change",
				correctOptionId: "MUTATED_0_95",
				options: [
					{
						id: "MUTATED_0_95",
						label: "([0.95], 0.95, [0.95, 1.90])"
					},
					{
						id: "MUTATED_1_05",
						label: "([1.05], 1.05, [1.05, 2.10])"
					},
					{
						id: "MUTATED_UNCHANGED",
						label: "([1.0], 1.0, [1.0, 2.0])"
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which test passes for the notebook update but fails for the reversed-residual mutation?",
			successCopy: "Correct: the notebook step lowers MSE from 0.5 to 0.40625, while the reversed-residual mutation raises it to 0.60625.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_MSE_DECREASES",
				options: [
					{
						id: "TEST_MSE_DECREASES",
						label: "Check that one step lowers MSE",
						description: "`assert ((model.predict(X_trace) - y_trace) ** 2).mean() < 0.5`"
					},
					{
						id: "TEST_COEF_SHAPE",
						label: "Check only the coefficient shape",
						description: "`assert model.coef.shape == (1,)`"
					},
					{
						id: "TEST_OUTPUT_SHAPE",
						label: "Check only the prediction shape",
						description: "`assert model.predict(X_trace).shape == (2,)`"
					},
					{
						id: "TEST_FINITE",
						label: "Check only that predictions are finite",
						description: "`assert np.all(np.isfinite(model.predict(X_trace)))`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The notebook defines residual as prediction minus target and subtracts its resulting gradients. On the fixture, the initial predictions are `[1, 2]`, the residuals are `[0, -1]`, and both gradients are -0.5. The reference therefore moves both parameters upward to 1.05 and reduces MSE. Reversing only the residual reverses the update direction and increases MSE." },
	successCopy: "Notebook Lab complete: the gradient step, reversed-residual mutation, and distinguishing test are all correct."
});
//#endregion
//#region src/data/classificationCodeLabQuestions.ts
var batchGradientDescentCode = `import numpy as np

class SGDRegressor():
    def __init__(self,learning_rate, max_iter, batch_size):
        self.lr=learning_rate
        self.max_iter=max_iter #number of epochs
        self.batch_size=batch_size

    def fit(self,X,y):
        self.coef=np.ones((X.shape[1],)) #initial values
        self.intercept=1 #initial value
        indices=np.arange(len(X)) # S1
        for i in range(self.max_iter):
            np.random.seed(i) #Just so everyone gets the same answer! # S2
            np.random.shuffle(indices) # S3
            X_shuffle=X[indices]
            y_shuffle=y[indices]
            for j in range(0,len(X),self.batch_size):
                X_batch=X_shuffle[j:j+self.batch_size]
                y_batch=y_shuffle[j:j+self.batch_size]
                residuals=self.predict(X_batch)-y_batch
                #coef_grad=(X_batch.T)@residuals/len(X_batch)
                coef_grad=(X_batch.T)@residuals/len(X) # S4
                #intercept_grad=np.mean(residuals)
                intercept_grad=np.sum(residuals)/len(X) # S5
                self.coef-=self.lr*coef_grad
                self.intercept-=self.lr*intercept_grad

    def predict(self,X):
        return X@self.coef+self.intercept`;
var regularizationCode = `import numpy as np

class SGDRegressor():
    def __init__(self,learning_rate, max_iter, batch_size, penalty='l2', alpha=0.0001):
        self.lr=learning_rate
        self.max_iter=max_iter #number of epochs
        self.batch_size=batch_size
        self.penalty=penalty #either 'l1' or 'l2'
        self.alpha=alpha #amount of regularization to apply

    def fit(self,X,y):
        self.coef=np.ones((X.shape[1],)) #Initial values
        self.intercept=1 #Initial value
        if self.penalty=='l1':
            #penalty_grad=lambda x:2*(x>0)-1
            penalty_grad=lambda x:np.sign(x) # S1
        elif self.penalty=='l2':
            penalty_grad=lambda x:x # S2
        indices=np.arange(len(X))
        for i in range(self.max_iter):
            np.random.seed(i) #Just so everyone gets the same answer!
            np.random.shuffle(indices)
            X_shuffle=X[indices]
            y_shuffle=y[indices]
            for j in range(0,len(X),self.batch_size):
                X_batch=X_shuffle[j:j+self.batch_size]
                y_batch=y_shuffle[j:j+self.batch_size]
                residuals=self.predict(X_batch)-y_batch
                coef_grad=(X_batch.T)@residuals/len(X_batch)
                intercept_grad=np.mean(residuals)
                self.coef-=self.lr*coef_grad+self.alpha*penalty_grad(self.coef) # S3
                self.intercept-=self.lr*intercept_grad+self.alpha*penalty_grad(self.intercept) # S4

    def predict(self,X):
        return X@self.coef+self.intercept

    def mse(self,X,y): #Not a sklearn method, but added here for convenience
        return ((self.predict(X)-y)**2).mean()`;
var logisticRegressionCode = `import numpy as np

class LogisticRegression():
    def __init__(self,learning_rate, max_iter, batch_size, penalty='l2', alpha=0.0001):
        self.lr=learning_rate
        self.max_iter=max_iter #number of epochs
        self.batch_size=batch_size
        self.penalty=penalty #either 'l1' or 'l2'
        self.alpha=alpha #amount of regularization to apply

    def fit(self,X,y):
        self.coef=np.ones((X.shape[1],)) #Initial values
        self.intercept=1 #Initial value
        if self.penalty=='l1':
            penalty_grad=lambda x:2*(x>0)-1
        elif self.penalty=='l2':
            penalty_grad=lambda x:x
        indices=np.arange(len(X))
        for i in range(self.max_iter):
            np.random.seed(i) #Just so everyone gets the same answer!
            np.random.shuffle(indices)
            X_shuffle=X[indices]
            y_shuffle=y[indices]
            for j in range(0,len(X),self.batch_size):
                X_batch=X_shuffle[j:j+self.batch_size]
                y_batch=y_shuffle[j:j+self.batch_size]
                residuals=self.predict_proba(X_batch)-y_batch # S1
                coef_grad=(X_batch.T)@residuals/len(X_batch) # S2
                intercept_grad=np.mean(residuals) # S3
                self.coef-=self.lr*coef_grad+self.alpha*penalty_grad(self.coef)
                self.intercept-=self.lr*intercept_grad+self.alpha*penalty_grad(self.intercept)

    def predict_proba(self,X):
        '''returns the predicted probabilites that each x in X
        is in the "True" class'''
        t=X@self.coef+self.intercept # S4
        return 1/(1+np.exp(-t)) # S5

    def predict(self,X):
        '''returns a prediction, for each x in X, that the class
        is "True".'''
        return self.predict_proba(X)>0.5 # S6

    def score(self,X,y):
        '''returns accuracy of the model'''
        return (self.predict(X)==y).mean()

    def NegLogLoss(self,X,y): #Not a sklearn method!
        '''returns the negative of the mean Log Loss'''
        probs=self.predict_proba(X)
        return -np.mean(y*np.log(probs)+(1-y)*np.log(1-probs))`;
var softmaxCode = `import numpy as np

class OneHotEncoder():
    def __init__(self):
        pass

    def fit(self,y):
        self.categories=np.unique(y) #Array of unique categories that appear in y # S1
        self.n_features_in=len(self.categories) #Number of categories

    def transform(self,y):
        Y=np.zeros((len(y),self.n_features_in))
        for i in range(self.n_features_in):
            Y[:,i]=(y==self.categories[i])
        return Y

    def fit_transform(self,y):
        '''Convenience method that applies fit and then
        immediately transforms'''
        self.fit(y)
        return self.transform(y)

class SoftmaxRegression():
    def __init__(self,learning_rate, max_iter, batch_size, penalty='l2', alpha=0.0001):
        self.lr=learning_rate
        self.max_iter=max_iter
        self.batch_size=batch_size
        self.penalty=penalty
        self.alpha=alpha
        self.encoder=OneHotEncoder()

    def fit(self,X,y):
        Y=self.encoder.fit_transform(y)
        self.coef=np.ones((X.shape[1],self.encoder.n_features_in))
        self.intercept=np.ones((self.encoder.n_features_in,))
        if self.penalty=='l1':
            penalty_grad=lambda x:2*(x>0)-1
        elif self.penalty=='l2':
            penalty_grad=lambda x:x
        indices=np.arange(len(X))
        for i in range(self.max_iter):
            np.random.seed(i)
            np.random.shuffle(indices)
            X_shuffle=X[indices]
            Y_shuffle=Y[indices]
            for j in range(0,len(X),self.batch_size):
                X_batch=X_shuffle[j:j+self.batch_size]
                Y_batch=Y_shuffle[j:j+self.batch_size]
                residuals=self.predict_proba(X_batch)-Y_batch # S2
                coef_grad=(X_batch.T)@residuals/len(X_batch) # S3
                intercept_grad=np.mean(residuals) # S4: scalar in the notebook
                self.coef-=self.lr*coef_grad+self.alpha*penalty_grad(self.coef)
                self.intercept-=self.lr*intercept_grad+self.alpha*penalty_grad(self.intercept)

    def predict_proba(self,X):
        '''returns the matrix of predicted probabilites'''
        t=X@self.coef+self.intercept # S5
        e=np.exp(t) # S6
        return e/np.sum(e,axis=1)[:,np.newaxis] # S7

    def predict(self,X):
        '''returns a prediction, for each observation in X,
        of one category.'''
        probs=self.predict_proba(X)
        indices=np.argmax(probs,axis=1) # S8
        return self.encoder.categories[indices] # S9

    def score(self,X,y):
        '''returns accuracy of the model'''
        return (self.predict(X)==y).mean()

    def CEloss(self,X,y): #Not a sklearn method!
        '''returns the Categorical Cross Entropy loss'''
        probs=self.predict_proba(X)
        Y=self.encoder.transform(y)
        return -np.sum(Y*np.log(probs))/len(y)`;
var batchGradientDescentNotebookLab = defineCodeLabQuestion({
	id: "batch-gradient-descent-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace Mini-batch Gradient Descent",
	prompt: "Use the completed `9BatchGradientDescent.ipynb` notebook to trace its mini-batch regression implementation, including its full-data gradient denominator.",
	instructions: "The displayed class is the notebook implementation. In particular, S4 and S5 divide each batch contribution by `len(X)`, not by the current batch size.",
	datasetId: "batch-gradient-descent-notebook-v1",
	variantId: "batch-gradient-descent-notebook-v1",
	language: "python",
	code: batchGradientDescentCode,
	fixtureTitle: "Notebook class with a deterministic four-row trace",
	fixture: `X_trace = np.array([
    [0.0],
    [0.0],
    [1.0],
    [1.0],
])
y_trace = np.zeros(4)

mod = SGDRegressor(
    learning_rate=0.5,
    max_iter=1,
    batch_size=2,
)`,
	invocationTitle: "Statements to trace",
	invocationLead: "After the displayed setup runs, Python evaluates:",
	invocation: `mod.fit(X_trace, y_trace)
query = np.array([[0.0], [1.0]])
pred = mod.predict(query)`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"With seed 0, S3 changes `[0, 1, 2, 3]` to `[2, 3, 1, 0]`, so the two rows with feature value 1 form the first batch.",
		"For the first batch, the residuals are `[2, 2]`; S4 and S5 both divide their sums by all four rows.",
		"For the mutation, dividing by the two-row batch doubles each first-batch gradient."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the notebook updates",
			prompt: "Mentally execute the displayed statements through both batches of the single epoch.",
			successCopy: "Correct: epoch 0 shuffles the row indices to `[2, 3, 1, 0]`. The two updates leave `coef = [0.5]`, `intercept = 0.375`, and predictions `[0.375, 0.875]`.",
			fields: [
				{
					id: "SHUFFLED_INDICES",
					label: "indices after S3 in epoch 0",
					correctOptionId: "INDICES_2_3_1_0",
					options: [
						{
							id: "INDICES_2_3_1_0",
							label: "[2, 3, 1, 0]"
						},
						{
							id: "INDICES_0_1_2_3",
							label: "[0, 1, 2, 3]"
						},
						{
							id: "INDICES_3_2_1_0",
							label: "[3, 2, 1, 0]"
						}
					]
				},
				{
					id: "FINAL_COEF",
					label: "mod.coef.tolist()",
					correctOptionId: "COEF_POINT_5",
					options: [
						{
							id: "COEF_POINT_5",
							label: "[0.5]"
						},
						{
							id: "COEF_ZERO",
							label: "[0.0]"
						},
						{
							id: "COEF_POINT_75",
							label: "[0.75]"
						}
					]
				},
				{
					id: "FINAL_INTERCEPT",
					label: "round(float(mod.intercept), 3)",
					correctOptionId: "INTERCEPT_POINT_375",
					options: [
						{
							id: "INTERCEPT_POINT_375",
							label: "0.375"
						},
						{
							id: "INTERCEPT_POINT_5",
							label: "0.500"
						},
						{
							id: "INTERCEPT_ZERO",
							label: "0.000"
						}
					]
				},
				{
					id: "PREDICTIONS",
					label: "pred.tolist()",
					correctOptionId: "PRED_POINT_375_POINT_875",
					options: [
						{
							id: "PRED_POINT_375_POINT_875",
							label: "[0.375, 0.875]"
						},
						{
							id: "PRED_POINT_5_1",
							label: "[0.5, 1.0]"
						},
						{
							id: "PRED_ZERO_ZERO",
							label: "[0.0, 0.0]"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Change the gradient denominator",
			prompt: "Suppose S4 and S5 both divide by `len(X_batch)` instead of `len(X)`. After rerunning the same fixture, what values result?",
			successCopy: "Correct: the two-row denominator makes the first update twice as large, taking both parameters to zero. The second batch then has zero residuals.",
			fields: [{
				id: "MUTATED_PARAMETERS",
				label: "mod.coef.tolist(), float(mod.intercept)",
				correctOptionId: "MUTATED_ZERO_ZERO",
				options: [
					{
						id: "MUTATED_ZERO_ZERO",
						label: "[0.0], 0.0"
					},
					{
						id: "MUTATED_REFERENCE",
						label: "[0.5], 0.375"
					},
					{
						id: "MUTATED_HALF_HALF",
						label: "[0.5], 0.5"
					}
				]
			}, {
				id: "MUTATED_PREDICTIONS",
				label: "pred.tolist() after rerunning the invocation",
				correctOptionId: "MUTATED_PRED_ZERO_ZERO",
				options: [
					{
						id: "MUTATED_PRED_ZERO_ZERO",
						label: "[0.0, 0.0]"
					},
					{
						id: "MUTATED_PRED_REFERENCE",
						label: "[0.375, 0.875]"
					},
					{
						id: "MUTATED_PRED_HALF_HALF",
						label: "[0.5, 0.5]"
					}
				]
			}]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which assertion passes for the notebook implementation but fails after both denominators are changed to `len(X_batch)`?",
			successCopy: "Correct: both versions preserve the output shape and metadata, but only the notebook denominators produce `[0.375, 0.875]`.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_REFERENCE_PREDICTIONS",
				options: [
					{
						id: "TEST_REFERENCE_PREDICTIONS",
						label: "Check the two predicted values",
						description: "`assert np.allclose(mod.predict(query), [0.375, 0.875])`"
					},
					{
						id: "TEST_OUTPUT_SHAPE",
						label: "Check only the prediction shape",
						description: "`assert mod.predict(query).shape == (2,)`"
					},
					{
						id: "TEST_BATCH_SIZE",
						label: "Check only the stored batch size",
						description: "`assert mod.batch_size == 2`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The notebook scales each batch contribution by the four-row dataset size. The first batch changes `(coef, intercept)` from `(1, 1)` to `(0.5, 0.5)`, and the second changes only the intercept to `0.375`. A two-row denominator instead sends both parameters to zero in the first update." },
	successCopy: "Notebook Lab complete: shuffling, batch updates, and the notebook’s gradient denominator are all correct."
});
var regularizationNotebookLab = defineCodeLabQuestion({
	id: "regularization-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace the Regularized Updates",
	prompt: "Use the completed `10Regularization.ipynb` notebook to trace its L1 update and distinguish it from an implementation that puts the penalty inside the learning-rate factor.",
	instructions: "The displayed class exactly follows the notebook: S3 and S4 apply `lr` to the data gradient and `alpha` separately to the penalty gradient, including the intercept.",
	datasetId: "regularization-notebook-v1",
	variantId: "regularization-notebook-v1",
	language: "python",
	code: regularizationCode,
	fixtureTitle: "Notebook class with a deterministic two-epoch trace",
	fixture: `X_trace = np.zeros((2, 2))
y_trace = np.ones(2)

mod = SGDRegressor(
    learning_rate=0.1,
    max_iter=2,
    batch_size=2,
    penalty='l1',
    alpha=0.2,
)`,
	invocationTitle: "Statements to trace",
	invocation: `mod.fit(X_trace, y_trace)
pred = mod.predict(X_trace)
trace_mse = mod.mse(X_trace, y_trace)`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"At the start, every prediction equals the target 1, so the first data gradients are zero.",
		"S1 gives a penalty gradient of 1 for every positive parameter. S3 and S4 subtract `alpha * 1 = 0.2` on the first epoch.",
		"Under the mutation, the first penalty step is only `learning_rate * alpha = 0.02`."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace two L1-regularized epochs",
			prompt: "Mentally execute both epochs through the completed notebook implementation.",
			successCopy: "Correct: the coefficients receive only the two L1 steps and finish at `0.6`. The changing intercept also receives a data-gradient correction, so it finishes at `0.62`.",
			fields: [
				{
					id: "FINAL_COEFFICIENTS",
					label: "np.round(mod.coef, 3).tolist()",
					correctOptionId: "COEF_POINT_6_POINT_6",
					options: [
						{
							id: "COEF_POINT_6_POINT_6",
							label: "[0.6, 0.6]"
						},
						{
							id: "COEF_POINT_8_POINT_8",
							label: "[0.8, 0.8]"
						},
						{
							id: "COEF_POINT_96_POINT_96",
							label: "[0.96, 0.96]"
						}
					]
				},
				{
					id: "FINAL_INTERCEPT",
					label: "round(float(mod.intercept), 3)",
					correctOptionId: "INTERCEPT_POINT_62",
					options: [
						{
							id: "INTERCEPT_POINT_62",
							label: "0.620"
						},
						{
							id: "INTERCEPT_POINT_6",
							label: "0.600"
						},
						{
							id: "INTERCEPT_POINT_962",
							label: "0.962"
						}
					]
				},
				{
					id: "PREDICTIONS",
					label: "np.round(pred, 3).tolist()",
					correctOptionId: "PRED_POINT_62_POINT_62",
					options: [
						{
							id: "PRED_POINT_62_POINT_62",
							label: "[0.62, 0.62]"
						},
						{
							id: "PRED_POINT_6_POINT_6",
							label: "[0.6, 0.6]"
						},
						{
							id: "PRED_POINT_962_POINT_962",
							label: "[0.962, 0.962]"
						}
					]
				},
				{
					id: "MSE",
					label: "round(float(trace_mse), 4)",
					correctOptionId: "MSE_POINT_1444",
					options: [
						{
							id: "MSE_POINT_1444",
							label: "0.1444"
						},
						{
							id: "MSE_POINT_0014",
							label: "0.0014"
						},
						{
							id: "MSE_POINT_38",
							label: "0.3800"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Move the penalty inside the learning-rate factor",
			prompt: "Suppose S3 and S4 are changed to subtract `self.lr * (gradient + self.alpha * penalty_grad(parameter))`. What results after rerunning the same fixture?",
			successCopy: "Correct: the effective penalty step falls from `0.2` to `0.02`. The coefficients finish at `0.96`, the intercept at `0.962`, and the MSE rounds to `0.0014`.",
			fields: [
				{
					id: "MUTATED_COEFFICIENTS",
					label: "np.round(mod.coef, 3).tolist()",
					correctOptionId: "MUTATED_COEF_POINT_96",
					options: [
						{
							id: "MUTATED_COEF_POINT_96",
							label: "[0.96, 0.96]"
						},
						{
							id: "MUTATED_COEF_POINT_6",
							label: "[0.6, 0.6]"
						},
						{
							id: "MUTATED_COEF_POINT_8",
							label: "[0.8, 0.8]"
						}
					]
				},
				{
					id: "MUTATED_INTERCEPT",
					label: "round(float(mod.intercept), 3)",
					correctOptionId: "MUTATED_INTERCEPT_POINT_962",
					options: [
						{
							id: "MUTATED_INTERCEPT_POINT_962",
							label: "0.962"
						},
						{
							id: "MUTATED_INTERCEPT_POINT_62",
							label: "0.620"
						},
						{
							id: "MUTATED_INTERCEPT_POINT_96",
							label: "0.960"
						}
					]
				},
				{
					id: "MUTATED_MSE",
					label: "round(float(trace_mse), 4)",
					correctOptionId: "MUTATED_MSE_POINT_0014",
					options: [
						{
							id: "MUTATED_MSE_POINT_0014",
							label: "0.0014"
						},
						{
							id: "MUTATED_MSE_POINT_1444",
							label: "0.1444"
						},
						{
							id: "MUTATED_MSE_POINT_038",
							label: "0.0380"
						}
					]
				}
			]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which assertion passes for the notebook update but fails when the penalty is moved inside the learning-rate factor?",
			successCopy: "Correct: both implementations retain the same shapes and settings, but only the notebook’s separately scaled penalty produces coefficients `[0.6, 0.6]`.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_NOTEBOOK_COEFFICIENTS",
				options: [
					{
						id: "TEST_NOTEBOOK_COEFFICIENTS",
						label: "Check the final coefficient values",
						description: "`assert np.allclose(mod.coef, [0.6, 0.6])`"
					},
					{
						id: "TEST_COEFFICIENT_SHAPE",
						label: "Check only the coefficient shape",
						description: "`assert mod.coef.shape == (2,)`"
					},
					{
						id: "TEST_PENALTY_NAME",
						label: "Check only the penalty setting",
						description: "`assert mod.penalty == \"l1\"`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "In the completed notebook, `lr` scales only the data gradient. The L1 term subtracts `alpha = 0.2` directly from each positive parameter on every epoch. Moving that term inside the `lr` factor changes the numerical algorithm and yields much smaller penalty steps." },
	successCopy: "Notebook Lab complete: L1 penalty gradients and the notebook’s update scaling are all correct."
});
var logisticRegressionNotebookLab = defineCodeLabQuestion({
	id: "logistic-regression-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace Logistic Predictions",
	prompt: "Use the completed `11LogisticRegression.ipynb` notebook to trace sigmoid probabilities, the strict prediction threshold, accuracy, and negative mean log loss.",
	instructions: "The displayed class is the notebook implementation. The fixture supplies a deterministic fitted state so the questions exercise the notebook methods without depending on a long training run.",
	datasetId: "logistic-regression-notebook-v1",
	variantId: "logistic-regression-notebook-v1",
	language: "python",
	code: logisticRegressionCode,
	fixtureTitle: "Notebook class with a fixed fitted state",
	fixture: `mod = LogisticRegression(
    learning_rate=0.01,
    max_iter=1,
    batch_size=3,
    alpha=0,
)
mod.coef = np.array([1.0, -1.0])
mod.intercept = 0.0

X_trace = np.array([
    [0.0, 0.0],
    [2.0, 0.0],
    [0.0, 2.0],
])
y_trace = np.array([False, True, False])`,
	invocationTitle: "Statements to trace",
	invocation: `probs = mod.predict_proba(X_trace)
predictions = mod.predict(X_trace)
accuracy = mod.score(X_trace, y_trace)
loss = mod.NegLogLoss(X_trace, y_trace)`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"S4 gives linear scores `[0, 2, -2]`. Apply the sigmoid at S5 to each score independently.",
		"The first probability is exactly `0.5`; S6 uses a strict greater-than comparison.",
		"Changing only S6 cannot change `predict_proba` or `NegLogLoss`."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the notebook prediction methods",
			prompt: "Mentally execute the four displayed statements through the completed notebook methods.",
			successCopy: "Correct: the scores `[0, 2, -2]` become probabilities `[0.5, 0.881, 0.119]`. The strict threshold classifies all three rows correctly, and the negative mean log loss rounds to `0.316`.",
			fields: [
				{
					id: "PROBABILITIES",
					label: "np.round(probs, 3).tolist()",
					correctOptionId: "PROBS_POINT_5_POINT_881_POINT_119",
					options: [
						{
							id: "PROBS_POINT_5_POINT_881_POINT_119",
							label: "[0.5, 0.881, 0.119]"
						},
						{
							id: "PROBS_POINT_5_POINT_667_POINT_333",
							label: "[0.5, 0.667, 0.333]"
						},
						{
							id: "PROBS_ZERO_ONE_ZERO",
							label: "[0.0, 1.0, 0.0]"
						}
					]
				},
				{
					id: "PREDICTIONS",
					label: "predictions.tolist()",
					correctOptionId: "PRED_FALSE_TRUE_FALSE",
					options: [
						{
							id: "PRED_FALSE_TRUE_FALSE",
							label: "[False, True, False]"
						},
						{
							id: "PRED_TRUE_TRUE_FALSE",
							label: "[True, True, False]"
						},
						{
							id: "PRED_FALSE_FALSE_TRUE",
							label: "[False, False, True]"
						}
					]
				},
				{
					id: "ACCURACY",
					label: "round(float(accuracy), 3)",
					correctOptionId: "ACCURACY_ONE",
					options: [
						{
							id: "ACCURACY_ONE",
							label: "1.000"
						},
						{
							id: "ACCURACY_TWO_THIRDS",
							label: "0.667"
						},
						{
							id: "ACCURACY_ONE_THIRD",
							label: "0.333"
						}
					]
				},
				{
					id: "NEG_LOG_LOSS",
					label: "round(float(loss), 3)",
					correctOptionId: "LOSS_POINT_316",
					options: [
						{
							id: "LOSS_POINT_316",
							label: "0.316"
						},
						{
							id: "LOSS_POINT_5",
							label: "0.500"
						},
						{
							id: "LOSS_POINT_684",
							label: "0.684"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Change the classification threshold",
			prompt: "Suppose S6 is changed from `>0.5` to `>=0.5`. What changes when the same statements run?",
			successCopy: "Correct: only the zero-score row changes class. Accuracy falls to two-thirds, while the probability-based negative log loss is unchanged.",
			fields: [
				{
					id: "MUTATED_PREDICTIONS",
					label: "predictions.tolist()",
					correctOptionId: "MUTATED_TRUE_TRUE_FALSE",
					options: [
						{
							id: "MUTATED_TRUE_TRUE_FALSE",
							label: "[True, True, False]"
						},
						{
							id: "MUTATED_FALSE_TRUE_FALSE",
							label: "[False, True, False]"
						},
						{
							id: "MUTATED_TRUE_FALSE_TRUE",
							label: "[True, False, True]"
						}
					]
				},
				{
					id: "MUTATED_ACCURACY",
					label: "round(float(accuracy), 3)",
					correctOptionId: "MUTATED_ACCURACY_TWO_THIRDS",
					options: [
						{
							id: "MUTATED_ACCURACY_TWO_THIRDS",
							label: "0.667"
						},
						{
							id: "MUTATED_ACCURACY_ONE",
							label: "1.000"
						},
						{
							id: "MUTATED_ACCURACY_ONE_THIRD",
							label: "0.333"
						}
					]
				},
				{
					id: "MUTATED_LOSS",
					label: "round(float(loss), 3)",
					correctOptionId: "MUTATED_LOSS_UNCHANGED",
					options: [
						{
							id: "MUTATED_LOSS_UNCHANGED",
							label: "0.316"
						},
						{
							id: "MUTATED_LOSS_POINT_5",
							label: "0.500"
						},
						{
							id: "MUTATED_LOSS_UNDEFINED",
							label: "undefined"
						}
					]
				}
			]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which assertion passes for the notebook’s strict threshold but fails after S6 is changed to `>=0.5`?",
			successCopy: "Correct: a zero score is the boundary case. Both implementations assign the same probability `0.5`, but only the notebook predicts `False`.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_ZERO_SCORE_CLASS",
				options: [
					{
						id: "TEST_ZERO_SCORE_CLASS",
						label: "Check the class at a zero score",
						description: "`assert mod.predict(np.array([[0.0, 0.0]])).tolist() == [False]`"
					},
					{
						id: "TEST_ZERO_SCORE_PROBABILITY",
						label: "Check only the probability at a zero score",
						description: "`assert np.allclose(mod.predict_proba(np.array([[0.0, 0.0]])), [0.5])`"
					},
					{
						id: "TEST_POSITIVE_SCORE_CLASS",
						label: "Check a class away from the boundary",
						description: "`assert mod.predict(np.array([[2.0, 0.0]])).tolist() == [True]`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The notebook’s sigmoid maps zero to exactly `0.5`, and `predict` uses `>0.5`, so the first row is `False`. Changing only that comparison alters the first class and accuracy, but it cannot alter probabilities or negative log loss." },
	successCopy: "Notebook Lab complete: sigmoid probabilities, thresholding, accuracy, and log loss are all correct."
});
var softmaxNotebookLab = defineCodeLabQuestion({
	id: "softmax-notebook-lab",
	kind: "codeLab",
	title: "Notebook Lab: Trace Multiclass Probabilities",
	prompt: "Use the completed `12Softmax.ipynb` notebook to trace one-hot category order, row-wise softmax probabilities, category prediction, and categorical cross-entropy.",
	instructions: "The displayed classes reproduce the notebook implementation. S4 deliberately remains the notebook’s scalar `np.mean(residuals)`; the deterministic fixture supplies a fitted state and exercises the prediction and evaluation methods.",
	datasetId: "softmax-notebook-v1",
	variantId: "softmax-notebook-v1",
	language: "python",
	code: softmaxCode,
	fixtureTitle: "Notebook classes with a fixed fitted state",
	fixture: `mod = SoftmaxRegression(
    learning_rate=0.01,
    max_iter=1,
    batch_size=3,
    alpha=0,
)
mod.encoder.fit(np.array(['cat', 'dog', 'owl']))
mod.coef = np.array([
    [1.0, 0.0, -1.0],
    [0.0, 1.0,  0.0],
])
mod.intercept = np.zeros(3)

X_trace = np.array([
    [1.0, 0.0],
    [0.0, 1.0],
    [0.0, 0.0],
])
y_trace = np.array(['cat', 'dog', 'owl'])`,
	invocationTitle: "Statements to trace",
	invocation: `probs = mod.predict_proba(X_trace)
predictions = mod.predict(X_trace)
accuracy = mod.score(X_trace, y_trace)
loss = mod.CEloss(X_trace, y_trace)`,
	hintSchedule: [
		2,
		4,
		6
	],
	hints: [
		"S1 sorts the category names. The columns therefore represent `cat`, `dog`, and `owl`, in that order.",
		"At S7, each row is divided by its own sum. Equal scores in the last row therefore become three probabilities of one-third.",
		"`np.argmax` and `np.argmin` both choose the first index when a row has a tie."
	],
	stages: [
		{
			id: "TRACE",
			kind: "executionTrace",
			title: "1. Trace the notebook prediction methods",
			prompt: "Mentally execute the four displayed statements through the completed notebook methods.",
			successCopy: "Correct: the first probability row is `[0.665, 0.245, 0.090]`. The equal third row ties and `argmax` selects the first category, giving predictions `cat, dog, cat`, accuracy two-thirds, and loss `0.686`.",
			fields: [
				{
					id: "FIRST_PROBABILITY_ROW",
					label: "np.round(probs[0], 3).tolist()",
					correctOptionId: "PROBS_POINT_665_POINT_245_POINT_09",
					options: [
						{
							id: "PROBS_POINT_665_POINT_245_POINT_09",
							label: "[0.665, 0.245, 0.090]"
						},
						{
							id: "PROBS_POINT_5_POINT_333_POINT_167",
							label: "[0.500, 0.333, 0.167]"
						},
						{
							id: "PROBS_ONE_ZERO_NEG_ONE",
							label: "[1.000, 0.000, -1.000]"
						}
					]
				},
				{
					id: "PREDICTIONS",
					label: "predictions.tolist()",
					correctOptionId: "PRED_CAT_DOG_CAT",
					options: [
						{
							id: "PRED_CAT_DOG_CAT",
							label: "['cat', 'dog', 'cat']"
						},
						{
							id: "PRED_CAT_DOG_OWL",
							label: "['cat', 'dog', 'owl']"
						},
						{
							id: "PRED_OWL_CAT_CAT",
							label: "['owl', 'cat', 'cat']"
						}
					]
				},
				{
					id: "ACCURACY",
					label: "round(float(accuracy), 3)",
					correctOptionId: "ACCURACY_TWO_THIRDS",
					options: [
						{
							id: "ACCURACY_TWO_THIRDS",
							label: "0.667"
						},
						{
							id: "ACCURACY_ONE",
							label: "1.000"
						},
						{
							id: "ACCURACY_ONE_THIRD",
							label: "0.333"
						}
					]
				},
				{
					id: "CROSS_ENTROPY",
					label: "round(float(loss), 3)",
					correctOptionId: "LOSS_POINT_686",
					options: [
						{
							id: "LOSS_POINT_686",
							label: "0.686"
						},
						{
							id: "LOSS_POINT_333",
							label: "0.333"
						},
						{
							id: "LOSS_POINT_1099",
							label: "1.099"
						}
					]
				}
			]
		},
		{
			id: "MUTATION",
			kind: "diagnoseMutation",
			title: "2. Reverse the category-selection rule",
			prompt: "Suppose S8 is changed from `np.argmax(probs,axis=1)` to `np.argmin(probs,axis=1)`. What changes when the same statements run?",
			successCopy: "Correct: the changed method selects `owl`, `cat`, and then the first tied category `cat`. None matches the supplied target, while the probability matrix and cross-entropy remain unchanged.",
			fields: [
				{
					id: "MUTATED_PREDICTIONS",
					label: "predictions.tolist()",
					correctOptionId: "MUTATED_OWL_CAT_CAT",
					options: [
						{
							id: "MUTATED_OWL_CAT_CAT",
							label: "['owl', 'cat', 'cat']"
						},
						{
							id: "MUTATED_CAT_DOG_CAT",
							label: "['cat', 'dog', 'cat']"
						},
						{
							id: "MUTATED_DOG_CAT_OWL",
							label: "['dog', 'cat', 'owl']"
						}
					]
				},
				{
					id: "MUTATED_ACCURACY",
					label: "round(float(accuracy), 3)",
					correctOptionId: "MUTATED_ACCURACY_ZERO",
					options: [
						{
							id: "MUTATED_ACCURACY_ZERO",
							label: "0.000"
						},
						{
							id: "MUTATED_ACCURACY_ONE_THIRD",
							label: "0.333"
						},
						{
							id: "MUTATED_ACCURACY_TWO_THIRDS",
							label: "0.667"
						}
					]
				},
				{
					id: "MUTATED_PROBABILITIES",
					label: "Effect on probs",
					correctOptionId: "MUTATED_PROBS_UNCHANGED",
					options: [
						{
							id: "MUTATED_PROBS_UNCHANGED",
							label: "The probability matrix is unchanged."
						},
						{
							id: "MUTATED_PROBS_NEGATED",
							label: "Every probability is negated."
						},
						{
							id: "MUTATED_PROBS_COLUMNS",
							label: "The columns, rather than rows, sum to 1."
						}
					]
				}
			]
		},
		{
			id: "TEST",
			kind: "distinguishingTest",
			title: "3. Choose a distinguishing test",
			prompt: "Which assertion passes for the notebook’s S8 `argmax` but fails after it is changed to `argmin`?",
			successCopy: "Correct: the mutation changes only category selection. Probability shape, row sums, and encoder category order remain the same.",
			fields: [{
				id: "TEST_ID",
				label: "Test",
				correctOptionId: "TEST_REFERENCE_CATEGORIES",
				options: [
					{
						id: "TEST_REFERENCE_CATEGORIES",
						label: "Check all predicted categories",
						description: "`assert mod.predict(X_trace).tolist() == ['cat', 'dog', 'cat']`"
					},
					{
						id: "TEST_ROW_SUMS",
						label: "Check only the probability row sums",
						description: "`assert np.allclose(mod.predict_proba(X_trace).sum(axis=1), 1)`"
					},
					{
						id: "TEST_ENCODER_ORDER",
						label: "Check only the encoder category order",
						description: "`assert mod.encoder.categories.tolist() == ['cat', 'dog', 'owl']`"
					}
				]
			}]
		}
	],
	reveal: { explanation: "The encoder sorts the categories, and S7 normalizes each score row. S8 then chooses the first largest probability. Replacing `argmax` with `argmin` changes only the selected category indices; it does not recompute probabilities or categorical cross-entropy. The fit method’s S4 remains a scalar mean exactly as written in the notebook." },
	successCopy: "Notebook Lab complete: one-hot category order, softmax probabilities, predictions, and cross-entropy are all correct."
});
//#endregion
//#region src/data/notebookAssignments.ts
function part(id, prompt, correctOptionId, choices) {
	return {
		id,
		prompt,
		correctOptionId,
		options: choices.map(([optionId, title, description]) => ({
			id: optionId,
			title,
			description
		}))
	};
}
function notebookQuestion(input) {
	const { explanation, ...question } = input;
	return {
		...question,
		kind: "multipleChoice",
		hintSchedule: [2, 4],
		validator: validateMultipleChoiceSelections(Object.fromEntries(input.parts.map((questionPart) => [questionPart.id, questionPart.correctOptionId])), "At least one selection does not match the displayed notebook code."),
		reveal: { explanation },
		successCopy: "Correct! Good Job!"
	};
}
var linearRegressionQuestions = [
	notebookQuestion({
		id: "linear-regression-endpoints",
		title: "Read the Endpoint Model",
		prompt: "Trace how `MaxMinLinearRegression.fit` chooses two observations and turns them into a line.",
		instructions: "The indices are selected from X first; the corresponding y values are then read at those same indices.",
		datasetId: "linearRegressionNotebook",
		parts: [part("selected-rows", "Which two rows define this model?", "x-extremes", [
			[
				"x-extremes",
				"The rows with minimum and maximum X",
				"`np.argmin(X)` and `np.argmax(X)` select the endpoint rows."
			],
			[
				"y-extremes",
				"The rows with minimum and maximum y",
				"The target values do not choose the rows."
			],
			[
				"first-last",
				"The first and last stored rows",
				"Array order matters only if it happens to match the X extremes."
			]
		]), part("intercept", "After computing the slope, how is the intercept obtained?", "through-min", [
			[
				"through-min",
				"`ymin - coef * Xmin`",
				"This makes the fitted line pass through the selected minimum-X observation."
			],
			[
				"mean-y",
				"`y.mean()`",
				"The endpoint model does not center the target values."
			],
			[
				"through-max-wrong",
				"`ymax + coef * Xmax`",
				"The sign would not make the line pass through the maximum-X observation."
			]
		])],
		hints: ["Follow `indmin` and `indmax` into all four scalar values.", "Substitute Xmin into `coef * x + intercept` and require the result to equal ymin."],
		explanation: "The endpoint implementation chooses rows solely from the smallest and largest X values, computes the rise over run, and chooses an intercept that makes the line pass through `(Xmin, ymin)`."
	}),
	notebookQuestion({
		id: "linear-regression-normal-equation",
		title: "Build the Normal-Equation Design Matrix",
		prompt: "Read the shape changes and matrix products in `LinearRegression.fit`.",
		instructions: "Let the input feature matrix X have shape `(n, m)`.",
		datasetId: "linearRegressionNotebook",
		parts: [part("design-shape", "What is the shape of `Xnew`?", "n-m-plus-one", [
			[
				"n-m-plus-one",
				"`(n, m + 1)`",
				"The extra leading column stores ones for the intercept."
			],
			[
				"n-plus-one-m",
				"`(n + 1, m)`",
				"No observation row is added."
			],
			[
				"m-n",
				"`(m, n)`",
				"The feature matrix is not transposed when it is constructed."
			]
		]), part("ones-purpose", "Why does the first column remain all ones?", "intercept-coefficient", [
			[
				"intercept-coefficient",
				"It makes the intercept one entry of `coeffs`",
				"Multiplying the ones column by `coeffs[0]` adds the same value to every prediction."
			],
			[
				"avoid-inverse",
				"It prevents use of a matrix inverse",
				"The implementation still calls `np.linalg.inv`."
			],
			[
				"normalize-target",
				"It scales y to unit length",
				"The target array is not normalized by this operation."
			]
		])],
		hints: ["Read both arguments passed to `np.ones`.", "Imagine multiplying one row `[1, x1, x2]` by the coefficient vector."],
		explanation: "The notebook augments every observation with a leading 1, so the first normal-equation coefficient is the intercept and the remaining entries are feature coefficients."
	}),
	notebookQuestion({
		id: "linear-regression-prediction-shapes",
		title: "Respect Prediction Shapes",
		prompt: "Determine which arrays represent observations and features in the notebook’s prediction calls.",
		instructions: "For a one-feature model, a batch of q observations must have shape `(q, 1)`.",
		datasetId: "linearRegressionNotebook",
		parts: [part("two-observations", "Which input correctly represents two one-feature observations, 200 and 220?", "column-batch", [
			[
				"column-batch",
				"`np.array([[200], [220]])`",
				"There are two rows and one feature column."
			],
			[
				"flat-two",
				"`np.array([200, 220])`",
				"This has two entries on one axis and does not align with a one-entry coefficient vector."
			],
			[
				"row-two",
				"`np.array([[200, 220]])`",
				"This represents one observation with two features."
			]
		]), part("dwg-shape", "If each source array has length n, what is the shape of `DWG = np.array([disp, wt, gr]).T`?", "n-three", [
			[
				"n-three",
				"`(n, 3)`",
				"The transpose turns the three source rows into three feature columns."
			],
			[
				"three-n",
				"`(3, n)`",
				"That is the shape before `.T`."
			],
			[
				"n-one",
				"`(n, 1)`",
				"All three features remain present."
			]
		])],
		hints: ["Rows represent observations and columns represent features.", "Construct the array before and after applying `.T`."],
		explanation: "The prediction method uses matrix multiplication against one coefficient per feature. A batch therefore needs one row per observation; transposing the three source arrays creates the `(n, 3)` feature matrix used by the final model."
	}),
	notebookQuestion({
		id: "linear-regression-losses",
		title: "Interpret RSS and MSE",
		prompt: "Compare the two loss calculations and the effect of expanding the feature matrix.",
		instructions: "Both losses use the same squared residuals.",
		datasetId: "linearRegressionNotebook",
		parts: [part("rss-mse", "How are RSS and MSE related for n observations?", "rss-n-mse", [
			[
				"rss-n-mse",
				"`RSS = n * MSE`",
				"MSE is the mean of the n squared residuals."
			],
			[
				"same-always",
				"`RSS = MSE`",
				"They coincide only in the special case n = 1."
			],
			[
				"rss-sqrt",
				"`RSS = sqrt(MSE)`",
				"Neither notebook expression takes this square root."
			]
		]), part("extra-features", "What can be said about training RSS after adding weight and gear ratio to displacement and refitting least squares?", "cannot-increase", [
			[
				"cannot-increase",
				"It cannot be larger than the best displacement-only training RSS",
				"The expanded model can reproduce the old solution by assigning zero to the added coefficients."
			],
			[
				"must-increase",
				"It must increase because there are more coefficients",
				"More available coefficients do not force a worse optimum."
			],
			[
				"test-guarantee",
				"Its test RSS must also decrease",
				"A training improvement does not guarantee better generalization."
			]
		])],
		hints: ["Compare `.sum()` with `.mean()` on the same array.", "Ask whether the larger model can represent every prediction made by the smaller model."],
		explanation: "MSE divides RSS by the observation count. Adding columns enlarges the set of linear predictions, so the optimized training RSS cannot increase, although held-out performance can still worsen."
	})
];
var polynomialRegressionQuestions = [
	notebookQuestion({
		id: "polynomial-scaling",
		title: "Trace StandardScaler",
		prompt: "Read what the notebook scaler learns and how it reverses a transformation.",
		instructions: "For a matrix, `axis=0` computes one value per feature column.",
		datasetId: "polynomialRegressionNotebook",
		parts: [part("learned-values", "What does `fit` store for an `(n, m)` matrix?", "m-means-stds", [
			[
				"m-means-stds",
				"m column means and m column standard deviations",
				"Both reductions use `axis=0`."
			],
			[
				"n-row-values",
				"n row means and n row standard deviations",
				"That would require `axis=1`."
			],
			[
				"one-global-pair",
				"one global mean and standard deviation",
				"The axis argument prevents a global reduction."
			]
		]), part("inverse", "Which expression reverses `transform`?", "multiply-add", [
			[
				"multiply-add",
				"`X * self.std + self.mean`",
				"Undo division first, then restore the mean."
			],
			[
				"subtract-divide",
				"`(X - self.mean) / self.std`",
				"That applies the forward transformation again."
			],
			[
				"add-divide",
				"`(X + self.mean) / self.std`",
				"The operations are not inverted in reverse order."
			]
		])],
		hints: ["Track the output shape of an `axis=0` reduction.", "Reverse subtraction/division in reverse order."],
		explanation: "The scaler stores column statistics. Its inverse multiplies a standardized value by the stored standard deviation and then adds the stored mean."
	}),
	notebookQuestion({
		id: "polynomial-feature-shapes",
		title: "Build Polynomial Features",
		prompt: "Determine the columns produced by both branches of `PolynomialFeatures.fit_transform`.",
		instructions: "The notebook accepts a one-dimensional input X.",
		datasetId: "polynomialRegressionNotebook",
		parts: [part("degree-three-no-bias", "For degree 3 with `include_bias=False`, what columns are returned?", "powers-one-three", [
			[
				"powers-one-three",
				"`X, X**2, X**3`",
				"The loop stores powers `i + 1` for i = 0, 1, 2."
			],
			[
				"powers-zero-two",
				"`1, X, X**2`",
				"That is the include-bias convention for degree 2."
			],
			[
				"only-cube",
				"`X**3` only",
				"Every power through the requested degree is included."
			]
		]), part("degree-three-bias-shape", "For n values, degree 3, and `include_bias=True`, what is the output shape?", "n-four", [
			[
				"n-four",
				"`(n, 4)`",
				"The columns are powers 0, 1, 2, and 3."
			],
			[
				"n-three",
				"`(n, 3)`",
				"This omits the bias column."
			],
			[
				"four-n",
				"`(4, n)`",
				"Observations remain rows."
			]
		])],
		hints: ["List the loop indices in each branch.", "`X**0` is the bias column of ones."],
		explanation: "Without bias the implementation returns degree columns for powers 1 through degree. With bias it returns degree + 1 columns beginning with power zero."
	}),
	notebookQuestion({
		id: "polynomial-linear-model",
		title: "Interpret the Engineered Model",
		prompt: "Explain why the notebook can fit a curved function with `LinearRegression`.",
		instructions: "Distinguish linearity in the coefficients from linearity in the original input.",
		datasetId: "polynomialRegressionNotebook",
		parts: [part("nonlinearity-source", "Where does the nonlinearity in displacement come from?", "engineered-powers", [
			[
				"engineered-powers",
				"The feature matrix contains powers of scaled displacement",
				"The model is linear in coefficients but nonlinear in the original scalar input."
			],
			[
				"changed-loss",
				"LinearRegression switches to a nonlinear loss",
				"The loss and solver remain ordinary least squares."
			],
			[
				"inverse-scaler",
				"The inverse scaler curves the target",
				"The target mpg is not inverse-transformed."
			]
		]), part("scale-first", "Why does the notebook scale displacement before taking high powers?", "control-magnitudes", [
			[
				"control-magnitudes",
				"To keep polynomial feature magnitudes manageable",
				"Centered, unit-scale values avoid enormous raw powers."
			],
			[
				"sort-values",
				"To sort observations by displacement",
				"Sorting is performed separately with `np.argsort`."
			],
			[
				"add-bias",
				"To create the intercept column",
				"Scaling does not add a column."
			]
		])],
		hints: ["Write a prediction as c1*x + c2*x².", "Compare 400³ with a standardized value near 1 cubed."],
		explanation: "Linear regression can weight nonlinear basis functions such as x² and x³. Scaling before constructing them improves numerical behavior without changing which row is which."
	}),
	notebookQuestion({
		id: "polynomial-code-trace",
		title: "Trace a Feature Matrix",
		prompt: "Mentally execute the notebook class on a two-value input.",
		instructions: "Use `X = np.array([2, 3])` and degree 2.",
		datasetId: "polynomialRegressionNotebook",
		parts: [part("bias-output", "What does `PolynomialFeatures(2, include_bias=True).fit_transform(X)` return?", "bias-matrix", [
			[
				"bias-matrix",
				"`[[1, 2, 4], [1, 3, 9]]`",
				"The columns are X**0, X**1, and X**2."
			],
			[
				"no-bias-matrix",
				"`[[2, 4], [3, 9]]`",
				"This is the no-bias branch."
			],
			[
				"transposed-matrix",
				"`[[1, 1], [2, 3], [4, 9]]`",
				"The implementation keeps observations in rows."
			]
		]), part("column-index", "In `scaled_disp2[:, 1]`, what does column 1 contain?", "squared-scaled", [
			[
				"squared-scaled",
				"`scaled_disp**2`",
				"Zero-based column 1 is the second engineered feature."
			],
			[
				"raw-disp",
				"unscaled displacement",
				"The feature generator receives `scaled_disp`."
			],
			[
				"bias",
				"ones",
				"The notebook created `quad` with the default `include_bias=False`."
			]
		])],
		hints: ["Evaluate powers 0, 1, and 2 row by row.", "Check how `quad` was constructed before `scaled_disp2`."],
		explanation: "The include-bias branch begins with ones. The notebook’s `quad` object omits bias, so its two columns are scaled displacement and its square."
	})
];
var overfittingQuestions = [
	notebookQuestion({
		id: "overfitting-split",
		title: "Read the Actual Train/Test Split",
		prompt: "Compare the prose near the split with the executable argument in the notebook.",
		instructions: "Answer from the displayed Python call, not from the nearby prose.",
		datasetId: "overfittingNotebook",
		parts: [part("split-fractions", "What fractions does `test_size=0.8` request?", "twenty-eighty", [
			[
				"twenty-eighty",
				"20% training and 80% testing",
				"The explicit size reserves 80% for the test arrays."
			],
			[
				"eighty-twenty",
				"80% training and 20% testing",
				"That would use `test_size=0.2` or `train_size=0.8`."
			],
			[
				"eighty-eighty",
				"80% in both sets",
				"The returned sets are disjoint."
			]
		]), part("repeatability", "Why can the exact rows change between fresh notebook runs?", "no-random-state", [
			[
				"no-random-state",
				"`random_state` is not supplied",
				"The split is not fixed by the call."
			],
			[
				"sorted-input",
				"The input was sorted first",
				"Sorting alone does not randomize or stabilize the random split."
			],
			[
				"test-large",
				"The test set is larger",
				"Its size does not determine repeatability."
			]
		])],
		hints: ["The named argument describes the test arrays.", "Look for a seed or `random_state` in the function call."],
		explanation: "The executable code reserves 80% for testing even though the prose says 80/20 in the opposite direction. With no `random_state`, the membership is not reproducible across fresh runs."
	}),
	notebookQuestion({
		id: "overfitting-preprocessing",
		title: "Avoid Preprocessing Leakage",
		prompt: "Trace which data determine the scaling statistics.",
		instructions: "Fitting learns parameters; transforming applies already learned parameters.",
		datasetId: "overfittingNotebook",
		parts: [part("scaler-fit", "Which array is used in `disp_scaler.fit(...)`?", "xtrain", [
			[
				"xtrain",
				"`Xtrain` only",
				"Only the training displacement values determine mean and scale."
			],
			[
				"xtest",
				"`Xtest` only",
				"Test values are transformed but not used to fit."
			],
			[
				"all-disp",
				"the complete `disp` array",
				"That would leak test-distribution information into preprocessing."
			]
		]), part("same-scaler", "Why is the fitted training scaler also used on Xtest?", "same-coordinate-system", [
			[
				"same-coordinate-system",
				"To put train and test rows in the same learned coordinate system",
				"The model expects features transformed with its training parameters."
			],
			[
				"force-zero-test-mean",
				"To guarantee Xtest has mean zero",
				"A test set need not have zero mean under training statistics."
			],
			[
				"increase-degree",
				"To add polynomial columns",
				"PolynomialFeatures performs that separate step."
			]
		])],
		hints: ["Locate the single `.fit` call.", "The test set should simulate future unseen observations."],
		explanation: "The notebook correctly learns scaling parameters from Xtrain and reuses them for Xtest, preventing test-set information from influencing model preparation."
	}),
	notebookQuestion({
		id: "overfitting-degree-eight",
		title: "Count Degree-Eight Features",
		prompt: "Read the polynomial and linear-model configuration together.",
		instructions: "`PolynomialFeatures` counts the bias as degree zero.",
		datasetId: "overfittingNotebook",
		parts: [part("feature-count", "How many columns does degree 8 produce with `include_bias=True` for one input feature?", "nine-columns", [
			[
				"nine-columns",
				"9 columns",
				"The powers are 0 through 8."
			],
			[
				"eight-columns",
				"8 columns",
				"This omits the requested bias column."
			],
			[
				"sixteen-columns",
				"16 columns",
				"The train/test split does not double the feature count."
			]
		]), part("no-intercept", "Why is `LinearRegression(fit_intercept=False)` paired with those features?", "bias-is-intercept", [
			[
				"bias-is-intercept",
				"The power-zero column already represents an intercept",
				"A separate fitted intercept would duplicate the constant term."
			],
			[
				"prevent-overfit",
				"It guarantees the model cannot overfit",
				"A degree-eight model can still overfit."
			],
			[
				"required-shape",
				"The nine-column matrix otherwise has the wrong shape",
				"The matrix shape is acceptable either way."
			]
		])],
		hints: ["List powers beginning at zero.", "A coefficient multiplying an all-ones column is a constant offset."],
		explanation: "Including bias creates nine columns, with the first all ones. Setting `fit_intercept=False` avoids fitting a second constant term."
	}),
	notebookQuestion({
		id: "overfitting-metrics-loop",
		title: "Audit the Metrics Loop",
		prompt: "Identify what the cell records and what happens if the notebook is run exactly as supplied.",
		instructions: "Names must have been defined or imported before Python can call them.",
		datasetId: "overfittingNotebook",
		parts: [part("first-failure", "What happens at `poly_model = PolynomialRegression(d+1)` in this notebook?", "name-error", [
			[
				"name-error",
				"A NameError occurs because `PolynomialRegression` is not defined or imported",
				"The imports include `PolynomialFeatures`, not a `PolynomialRegression` class."
			],
			[
				"sklearn-model",
				"It constructs sklearn LinearRegression automatically",
				"Python does not infer this alias."
			],
			[
				"degree-error",
				"It raises an error only when d reaches 8",
				"The undefined name fails on the first iteration."
			]
		]), part("best-degree-rule", "If the loop were made executable, which expression selects the degree with minimum test MSE?", "test-argmin-plus-one", [
			[
				"test-argmin-plus-one",
				"`metrics[:, 1].argmin() + 1`",
				"Column 1 is test MSE and row 0 represents degree 1."
			],
			[
				"train-argmin",
				"`metrics[:, 0].argmin()`",
				"This uses training MSE and returns a zero-based row."
			],
			[
				"test-argmax",
				"`metrics[:, 1].argmax() + 1`",
				"The objective is to minimize MSE."
			]
		])],
		hints: ["Search the earlier cells for a definition of `PolynomialRegression`.", "Map row d to polynomial degree d + 1."],
		explanation: "As supplied, the metrics loop cannot run because `PolynomialRegression` is undefined. Once a working model is substituted, the second metrics column is test MSE and its zero-based minimum position must be shifted by one to obtain the degree."
	})
];
var gradientDescentQuestions = [
	notebookQuestion({
		id: "gradient-function",
		title: "Read the Two-Variable Gradient",
		prompt: "Match the update expressions in `fGD` to the gradient of the displayed function.",
		instructions: "Both new coordinates are calculated before either current coordinate is replaced.",
		datasetId: "gradientDescentNotebook",
		parts: [part("gradient-x", "What is the x component of the gradient?", "gx", [
			[
				"gx",
				"`2*x + 2*y - 4`",
				"Differentiate x², 2xy, and -4x with respect to x."
			],
			[
				"gy",
				"`2*x + 4*y - 4`",
				"This is the y component."
			],
			[
				"value",
				"`x**2 + 2*x*y - 4*x`",
				"This is not a derivative."
			]
		]), part("update-timing", "Which values are used to compute `x_new` and `y_new` during one epoch?", "same-old-pair", [
			[
				"same-old-pair",
				"Both use the same old x and y",
				"Assignments to x and y happen after both new values are computed."
			],
			[
				"updated-x",
				"`y_new` uses the newly updated x",
				"x is not replaced until the next line after `y_new`."
			],
			[
				"updated-y",
				"`x_new` uses the newly updated y",
				"No update occurs before `x_new` is calculated."
			]
		])],
		hints: ["Differentiate term by term.", "Read the four assignment lines in exact order."],
		explanation: "The gradient is `(2x + 2y - 4, 2x + 4y - 4)`. The implementation performs a simultaneous-style update because both new coordinates use the previous pair."
	}),
	notebookQuestion({
		id: "gradient-regressor-gradients",
		title: "Trace GDRegressor Gradients",
		prompt: "Determine the residual and gradient shapes in the full-dataset update.",
		instructions: "Let X have shape `(n, m)` and y have shape `(n,)`.",
		datasetId: "gradientDescentNotebook",
		parts: [part("residual-definition", "How are residuals defined?", "prediction-minus-y", [
			[
				"prediction-minus-y",
				"`self.predict(X) - y`",
				"This is the exact notebook line."
			],
			[
				"y-minus-prediction",
				"`y - self.predict(X)`",
				"That reverses the gradient sign."
			],
			[
				"squared-residuals",
				"`(self.predict(X) - y)**2`",
				"The gradient uses unsquared residuals."
			]
		]), part("gradient-shapes", "What are the coefficient-gradient and intercept-gradient shapes?", "m-and-scalar", [
			[
				"m-and-scalar",
				"`(m,)` and scalar",
				"`X.T @ residuals` produces one value per feature; `mean` produces one value."
			],
			[
				"n-and-m",
				"`(n,)` and `(m,)`",
				"The gradient is with respect to parameters, not observations."
			],
			[
				"scalar-scalar",
				"both scalar",
				"Multiple feature coefficients need separate gradient entries."
			]
		])],
		hints: ["Write the shapes in `(m,n) @ (n,)`.", "The intercept is one shared parameter."],
		explanation: "Predicted-minus-actual residuals form an n-vector. Multiplication by X transpose produces one gradient per feature, while their mean is the scalar intercept gradient."
	}),
	notebookQuestion({
		id: "gradient-hyperparameters",
		title: "Interpret Scaling and Hyperparameters",
		prompt: "Connect notebook preprocessing and constructor arguments to gradient-descent behavior.",
		instructions: "The optimizer follows a fixed learning rate for a fixed number of iterations.",
		datasetId: "gradientDescentNotebook",
		parts: [part("why-scale", "Why is displacement standardized before fitting `mpg_mod`?", "balanced-gradient-scale", [
			[
				"balanced-gradient-scale",
				"To put feature magnitudes on a scale suitable for stable updates",
				"Very large feature values can create very large coefficient gradients."
			],
			[
				"make-target-bool",
				"To convert mpg to Boolean labels",
				"This remains a regression problem."
			],
			[
				"normal-equation",
				"To make `np.linalg.inv` possible",
				"GDRegressor does not use a matrix inverse."
			]
		]), part("large-lr", "What can happen if the learning rate is too large?", "overshoot-diverge", [
			[
				"overshoot-diverge",
				"Updates can overshoot and diverge",
				"The step size can repeatedly cross or move away from the minimum."
			],
			[
				"more-exact",
				"The normal equation becomes more exact",
				"No normal equation is used."
			],
			[
				"fewer-features",
				"Feature columns are automatically removed",
				"Learning rate does not perform feature selection."
			]
		])],
		hints: ["Inspect the multiplication inside `coef_grad`.", "Think of repeatedly stepping past a minimum."],
		explanation: "Scaling moderates gradient magnitudes, making one learning rate more useful. A learning rate that is too large can prevent convergence regardless of the maximum iteration count."
	}),
	notebookQuestion({
		id: "gradient-one-update",
		title: "Calculate One Full-Gradient Update",
		prompt: "Execute one update of `GDRegressor` on a tiny dataset.",
		instructions: "Use `X = [[0], [1]]`, `y = [1, 3]`, learning rate 0.2, and the notebook initial coefficient/intercept of 1.",
		datasetId: "gradientDescentNotebook",
		parts: [part("initial-residuals", "What are the residuals before the update?", "zero-neg-one", [
			[
				"zero-neg-one",
				"`[0, -1]`",
				"Initial predictions are `[1, 2]`."
			],
			[
				"zero-one",
				"`[0, 1]`",
				"This uses actual minus predicted."
			],
			[
				"one-one",
				"`[1, 1]`",
				"It ignores the intercept in the predictions."
			]
		]), part("updated-parameters", "What are the coefficient and intercept after the update?", "both-one-point-one", [
			[
				"both-one-point-one",
				"`coef = [1.1]`, `intercept = 1.1`",
				"Both gradients are -0.5, so subtracting 0.2 times the gradient adds 0.1."
			],
			[
				"both-point-nine",
				"`coef = [0.9]`, `intercept = 0.9`",
				"This follows the reversed residual convention."
			],
			[
				"coef-one-intercept",
				"`coef = [1.0]`, `intercept = 1.1`",
				"The second row gives a nonzero coefficient gradient."
			]
		])],
		hints: ["First compute `X @ [1] + 1`.", "Use `(X.T @ residuals) / 2` and `mean(residuals)`."],
		explanation: "The initial predictions are 1 and 2, so the residuals are 0 and -1. Both gradients equal -0.5, and the learning-rate step raises each parameter from 1 to 1.1."
	})
];
var batchGradientDescentQuestions = [
	notebookQuestion({
		id: "batch-shuffling",
		title: "Trace Epoch Shuffling",
		prompt: "Read how the notebook constructs reproducible shuffled batches.",
		instructions: "The same `indices` array indexes both X and y.",
		datasetId: "batchGradientDescentNotebook",
		parts: [part("seed-effect", "What does `np.random.seed(i)` accomplish inside the epoch loop?", "reproducible-by-epoch", [
			[
				"reproducible-by-epoch",
				"Each epoch’s shuffle is reproducible and depends on i",
				"Fresh runs use the same permutation sequence."
			],
			[
				"same-every-epoch",
				"Every epoch receives exactly the same permutation",
				"The seed changes with i."
			],
			[
				"no-shuffle",
				"It disables random shuffling",
				"`np.random.shuffle` still permutes the indices."
			]
		]), part("pairing", "Why do features and targets stay correctly paired?", "same-permutation", [
			[
				"same-permutation",
				"Both arrays are indexed by the same shuffled indices",
				"Each target moves with its observation row."
			],
			[
				"sorted-target",
				"y is sorted after shuffling",
				"No sorting occurs."
			],
			[
				"seed-target",
				"A separate target seed repairs the order",
				"There is only one index permutation."
			]
		])],
		hints: ["Compare the seeds in epochs 0 and 1.", "Read the right sides of `X_shuffle` and `y_shuffle`."],
		explanation: "Seeding with the epoch index yields deterministic but different epoch permutations. Applying one permutation to both arrays preserves row-target correspondence."
	}),
	notebookQuestion({
		id: "batch-slices",
		title: "Count Batch Updates",
		prompt: "Interpret the inner range and its final possibly short slice.",
		instructions: "Python slices stop at the array end even when the requested endpoint is larger.",
		datasetId: "batchGradientDescentNotebook",
		parts: [part("updates-per-epoch", "For n rows and batch size b, how many updates occur per epoch?", "ceiling", [
			[
				"ceiling",
				"`ceil(n / b)`",
				"Every nonempty slice causes one update, including a final partial batch."
			],
			[
				"floor",
				"`floor(n / b)`",
				"This drops the final partial batch."
			],
			[
				"n",
				"n updates",
				"That is true only for batch size 1."
			]
		]), part("notebook-count", "For 100,000 rows and batch size 4,150, how many updates occur per epoch?", "twenty-five", [
			[
				"twenty-five",
				"25",
				"Twenty-four full starts cover through index 95,449, followed by one final slice."
			],
			[
				"twenty-four",
				"24",
				"This omits the partial final batch."
			],
			[
				"four-thousand",
				"4,150",
				"That is the batch size, not the update count."
			]
		])],
		hints: ["List starts 0, b, 2b, ... below n.", "Use a ceiling because 100000 is not divisible by 4150."],
		explanation: "The range visits every valid batch start. A non-divisible row count creates one shorter final batch, so the update count is the ceiling of n divided by batch size."
	}),
	notebookQuestion({
		id: "batch-gradient-scaling",
		title: "Read the Notebook’s Gradient Scaling",
		prompt: "Distinguish the active denominator from the commented alternative.",
		instructions: "Answer from the uncommented code.",
		datasetId: "batchGradientDescentNotebook",
		parts: [part("denominator", "What divides the active coefficient and intercept sums?", "full-length", [
			[
				"full-length",
				"`len(X)`",
				"Both active gradient lines use the full dataset length."
			],
			[
				"batch-length",
				"`len(X_batch)`",
				"Those batch-mean alternatives are commented out."
			],
			[
				"epochs",
				"`self.max_iter`",
				"Epoch count does not normalize a batch gradient."
			]
		]), part("relative-scale", "For a full batch of size b < n, how does this compare with dividing by b?", "b-over-n", [
			[
				"b-over-n",
				"The active gradient is `b/n` times the batch-mean gradient",
				"The same numerator is divided by n instead of b."
			],
			[
				"n-over-b",
				"The active gradient is `n/b` times larger",
				"Dividing by the larger n makes it smaller."
			],
			[
				"identical",
				"They are always identical",
				"They coincide only when b = n."
			]
		])],
		hints: ["Ignore the lines beginning with `#`.", "Compare `S/n` with `S/b`."],
		explanation: "The supplied implementation scales each batch contribution by the entire dataset length. Relative to a batch mean, that shrinks a full b-row batch gradient by b/n."
	}),
	notebookQuestion({
		id: "batch-special-cases",
		title: "Connect Batch Size to GD and SGD",
		prompt: "Identify limiting cases of the notebook’s batch loop.",
		instructions: "Keep the other constructor arguments fixed.",
		datasetId: "batchGradientDescentNotebook",
		parts: [part("batch-one", "What does `batch_size=1` represent?", "stochastic", [
			[
				"stochastic",
				"One stochastic update per shuffled observation",
				"Each slice contains one row."
			],
			[
				"full-batch",
				"One full-dataset update per epoch",
				"That requires a batch at least as large as n."
			],
			[
				"no-updates",
				"No updates because the batch is too small",
				"Every one-row slice is nonempty."
			]
		]), part("batch-at-least-n", "What happens when `batch_size >= len(X)`?", "one-update", [
			[
				"one-update",
				"There is one full-dataset update per epoch",
				"Only the j = 0 slice is produced."
			],
			[
				"n-updates",
				"There are n updates per epoch",
				"The range step is the large batch size."
			],
			[
				"empty",
				"The first slice is empty",
				"The slice begins at zero and includes all rows."
			]
		])],
		hints: ["Write the starts produced by `range(0, n, batch_size)`.", "A slice from zero past the end returns all available rows."],
		explanation: "A one-row batch gives stochastic updates; a batch at least as large as the data yields a single full-gradient-style update during each epoch."
	})
];
var regularizationQuestions = [
	notebookQuestion({
		id: "regularization-penalties",
		title: "Compare L1 and L2 Penalty Gradients",
		prompt: "Trace the lambdas selected by the `penalty` constructor argument.",
		instructions: "Use the exact NumPy functions in the supplied class.",
		datasetId: "regularizationNotebook",
		parts: [part("gradients", "Which pair matches the implementation?", "l1-sign-l2-value", [
			[
				"l1-sign-l2-value",
				"L1 uses `sign(x)`; L2 uses `x`",
				"Those are the two assigned lambdas."
			],
			[
				"l1-x-l2-sign",
				"L1 uses `x`; L2 uses `sign(x)`",
				"This reverses the branches."
			],
			[
				"both-square",
				"Both use `x**2`",
				"The derivative, not the penalty value, is used."
			]
		]), part("l1-at-zero", "What does the notebook’s L1 gradient return at exactly zero?", "zero", [
			[
				"zero",
				"0",
				"`np.sign(0)` is zero."
			],
			[
				"one",
				"1",
				"That would come from the commented alternative `2*(x>0)-1` only for positive values."
			],
			[
				"undefined",
				"It raises an exception",
				"NumPy defines the sign output at zero."
			]
		])],
		hints: ["Read which lambda is active rather than commented.", "Evaluate `np.sign(0)`."],
		explanation: "The L1 branch uses NumPy sign, which is -1, 0, or 1. The L2 branch uses the current parameter value, so larger magnitudes receive larger shrinkage."
	}),
	notebookQuestion({
		id: "regularization-update",
		title: "Parse the Regularized Update",
		prompt: "Read the placement of learning rate and alpha in the two update statements.",
		instructions: "Python evaluates both additive terms before subtracting them.",
		datasetId: "regularizationNotebook",
		parts: [part("alpha-scaling", "Which expression is subtracted from a coefficient?", "exact-update", [
			[
				"exact-update",
				"`lr * coef_grad + alpha * penalty_grad(coef)`",
				"Only the data-gradient term is multiplied by learning rate."
			],
			[
				"lr-all",
				"`lr * (coef_grad + alpha * penalty_grad(coef))`",
				"That would also scale the penalty term by lr."
			],
			[
				"alpha-data",
				"`alpha * coef_grad + lr * penalty_grad(coef)`",
				"The hyperparameters are exchanged."
			]
		]), part("intercept-penalty", "Does this implementation regularize the intercept?", "yes", [
			[
				"yes",
				"Yes, with the same selected penalty gradient",
				"The intercept update includes `self.alpha*penalty_grad(self.intercept)`."
			],
			[
				"no",
				"No, only coefficients are penalized",
				"That is common elsewhere but not what this notebook does."
			],
			[
				"l1-only",
				"Only when penalty is L1",
				"Both branches define `penalty_grad` used by the intercept line."
			]
		])],
		hints: ["Notice where the multiplication by `self.lr` ends.", "Read the complete intercept update line."],
		explanation: "The notebook adds an alpha-scaled penalty gradient outside the learning-rate product and applies the same form to the intercept as to every coefficient."
	}),
	notebookQuestion({
		id: "regularization-polynomial",
		title: "Use L2 Against Polynomial Overfitting",
		prompt: "Interpret the degree-12 experiment and its expected loss tradeoff.",
		instructions: "The polynomial transformer is configured without a bias column.",
		datasetId: "regularizationNotebook",
		parts: [part("degree-columns", "How many feature columns are produced from one input feature?", "twelve", [
			[
				"twelve",
				"12",
				"The columns contain powers 1 through 12."
			],
			[
				"thirteen",
				"13",
				"There is no power-zero bias column."
			],
			[
				"sixteen",
				"16",
				"Sixteen is the original observation count."
			]
		]), part("expected-tradeoff", "What comparison does the notebook expect after adding L2 regularization?", "train-up-test-down", [
			[
				"train-up-test-down",
				"Higher training MSE but lower testing MSE",
				"Some training fit is traded for better generalization."
			],
			[
				"both-zero",
				"Both MSE values become zero",
				"Regularization does not guarantee exact predictions."
			],
			[
				"train-down-test-up",
				"Lower training MSE but higher testing MSE",
				"That is the opposite of the stated purpose in this experiment."
			]
		])],
		hints: ["Check `include_bias=False`.", "Regularization deliberately restricts an overly flexible fit."],
		explanation: "The degree-12 no-bias matrix has twelve columns. L2 shrinkage can worsen the fit to training rows while reducing variance enough to improve test error."
	}),
	notebookQuestion({
		id: "regularization-feature-selection",
		title: "Trace the Feature-Selection Slice",
		prompt: "Read how the California housing matrix is scaled and reduced.",
		instructions: "Column indices follow the DataFrame order from MedInc through Longitude.",
		datasetId: "regularizationNotebook",
		parts: [part("scaler-data", "Which data determine the scaling parameters?", "train-only", [
			[
				"train-only",
				"`X_train` only",
				"The scaler is fit before transforming either split."
			],
			[
				"test-only",
				"`X_test` only",
				"The test set is transformed but never fitted."
			],
			[
				"both",
				"The concatenated train and test matrices",
				"The code never concatenates them."
			]
		]), part("selected-features", "Which named features are kept by `[:, [0, 1]]`?", "medinc-houseage", [
			[
				"medinc-houseage",
				"MedInc and HouseAge",
				"They are the first two feature columns in the selected DataFrame range."
			],
			[
				"latitude-longitude",
				"Latitude and Longitude",
				"Those are the final two columns."
			],
			[
				"medinc-longitude",
				"MedInc and Longitude",
				"That would use indices 0 and 7."
			]
		])],
		hints: ["Find the one `.fit` call on `Xscaler`.", "Read the California housing column order shown by the DataFrame."],
		explanation: "Training rows alone determine scaling. The hard-coded two-column slice retains the first two housing features, MedInc and HouseAge, for the smaller model."
	})
];
var logisticRegressionQuestions = [
	notebookQuestion({
		id: "logistic-sigmoid",
		title: "Trace Sigmoid and the Class Rule",
		prompt: "Convert a linear score into a probability and then into a Boolean prediction.",
		instructions: "The comparison in `predict` is strictly greater than 0.5.",
		datasetId: "logisticRegressionNotebook",
		parts: [part("zero-score", "What probability is produced when t = 0?", "half", [
			[
				"half",
				"0.5",
				"`exp(0)` is 1, so the sigmoid denominator is 2."
			],
			[
				"zero",
				"0",
				"The sigmoid never maps a finite score to exactly zero."
			],
			[
				"one",
				"1",
				"That is only approached for very large positive scores."
			]
		]), part("boundary-class", "What class does the notebook predict when the probability is exactly 0.5?", "false", [
			[
				"false",
				"`False`",
				"The expression `0.5 > 0.5` is false."
			],
			[
				"true",
				"`True`",
				"That would require `>= 0.5`."
			],
			[
				"error",
				"A tie error",
				"NumPy Boolean comparison handles equality directly."
			]
		])],
		hints: ["Substitute zero into `1/(1+exp(-t))`.", "Pay attention to `>` versus `>=`."],
		explanation: "The sigmoid maps zero to exactly 0.5, and the implementation assigns that boundary probability to False because its comparison is strict."
	}),
	notebookQuestion({
		id: "logistic-gradient",
		title: "Connect Logistic and Linear Gradients",
		prompt: "Identify what changed when the SGD regressor became a classifier.",
		instructions: "The coefficient and intercept gradient formulas retain their earlier structure.",
		datasetId: "logisticRegressionNotebook",
		parts: [part("residual", "What is one logistic residual?", "prob-minus-y", [
			[
				"prob-minus-y",
				"`predicted_probability - y`",
				"The notebook subtracts the 0/1 target from `predict_proba`."
			],
			[
				"class-minus-y",
				"`predicted_class - y`",
				"The gradient uses probabilities, not thresholded classes."
			],
			[
				"score-minus-y",
				"`linear_score - y`",
				"The sigmoid is applied before residuals are formed."
			]
		]), part("coef-gradient", "What is the coefficient-gradient expression for a batch?", "xt-residual-mean", [
			[
				"xt-residual-mean",
				"`X_batch.T @ residuals / len(X_batch)`",
				"This is the exact active line."
			],
			[
				"residual-xt",
				"`residuals.T @ X_batch.T`",
				"Those dimensions do not produce one gradient per feature."
			],
			[
				"mean-only",
				"`np.mean(residuals)`",
				"That is the intercept gradient."
			]
		])],
		hints: ["Look at the first line inside the batch loop that differs from regression.", "The feature matrix weights each residual in the coefficient gradient."],
		explanation: "Logistic regression changes residuals to probability minus target. Once those residuals are available, the coefficient and intercept gradients have the same matrix/mean forms as linear regression."
	}),
	notebookQuestion({
		id: "logistic-evaluation",
		title: "Distinguish Accuracy and Log Loss",
		prompt: "Compare the notebook’s `score` and `NegLogLoss` methods.",
		instructions: "Accuracy uses classes; log loss uses probabilities.",
		datasetId: "logisticRegressionNotebook",
		parts: [part("score", "What does `score` return?", "fraction-correct", [
			[
				"fraction-correct",
				"The fraction of Boolean predictions equal to y",
				"Boolean equality is averaged across rows."
			],
			[
				"mean-probability",
				"The mean predicted probability",
				"`score` calls `predict`, not `predict_proba` directly."
			],
			[
				"negative-loss",
				"The negative mean log loss",
				"That has its own method."
			]
		]), part("confident-wrong", "How does log loss treat an increasingly confident wrong prediction?", "larger-penalty", [
			[
				"larger-penalty",
				"Its penalty grows",
				"The assigned correct-class probability approaches zero and its negative log grows."
			],
			[
				"same-penalty",
				"Its penalty is unchanged once the class is wrong",
				"That describes 0/1 error, not log loss."
			],
			[
				"smaller-penalty",
				"Its penalty shrinks",
				"Confidence in the wrong class moves the loss in the opposite direction."
			]
		])],
		hints: ["Read the return line of each method.", "Consider `-log(p)` as the correct-class probability p approaches zero."],
		explanation: "Accuracy records only whether the thresholded class is right. Negative mean log loss retains confidence information and strongly penalizes wrong predictions made with high confidence."
	}),
	notebookQuestion({
		id: "logistic-iris-shapes",
		title: "Read the Iris Feature Matrix",
		prompt: "Trace the two selected columns and the decision-boundary expression.",
		instructions: "The notebook predicts whether each row is virginica.",
		datasetId: "logisticRegressionNotebook",
		parts: [part("x-shape", "What is the shape of X after selecting Petal Length and Petal Width?", "one-fifty-two", [
			[
				"one-fifty-two",
				"`(150, 2)`",
				"There are 150 iris rows and two selected feature columns."
			],
			[
				"two-one-fifty",
				"`(2, 150)`",
				"Observations remain rows."
			],
			[
				"one-fifty-four",
				"`(150, 4)`",
				"The other two iris measurements were not selected."
			]
		]), part("boundary-slope", "What slope does `func` use for the 0.5 decision boundary?", "negative-ratio", [
			[
				"negative-ratio",
				"`-coef[0] / coef[1]`",
				"Setting the linear score to zero and solving for feature 2 gives this slope."
			],
			[
				"positive-ratio",
				"`coef[0] / coef[1]`",
				"This misses the sign introduced when moving the first term."
			],
			[
				"intercept-only",
				"`-intercept`",
				"The coefficients determine the slope."
			]
		])],
		hints: ["Count the DataFrame columns inside the double brackets.", "At probability 0.5, the linear score t equals zero."],
		explanation: "The model uses two petal measurements for each of 150 flowers. Its probability boundary occurs where the linear score is zero, giving slope `-coef[0]/coef[1]`."
	})
];
var softmaxQuestions = [
	notebookQuestion({
		id: "softmax-one-hot",
		title: "Trace One-Hot Encoding",
		prompt: "Read what `fit` learns and why the same fitted encoder is reused.",
		instructions: "`np.unique` determines the stored category order.",
		datasetId: "softmaxNotebook",
		parts: [part("category-order", "For `y = ['b', 'a', 'c', 'b']`, what is `encoder.categories`?", "a-b-c", [
			[
				"a-b-c",
				"`['a', 'b', 'c']`",
				"`np.unique` returns the distinct strings in sorted order."
			],
			[
				"b-a-c",
				"`['b', 'a', 'c']`",
				"First-appearance order is not retained by `np.unique` here."
			],
			[
				"zero-one-two",
				"`[0, 1, 2]`",
				"The stored values are the original category labels."
			]
		]), part("reuse", "Why call `encoder.transform(z)` instead of fitting a new encoder to z?", "same-columns", [
			[
				"same-columns",
				"To preserve the training category columns and their order",
				"The model output columns correspond to the fitted training categories."
			],
			[
				"fewer-rows",
				"To make z contain fewer observations",
				"Encoding does not change row count."
			],
			[
				"scale-labels",
				"To standardize string magnitudes",
				"One-hot encoding is not numeric scaling."
			]
		])],
		hints: ["Recall the ordering behavior of `np.unique`.", "Each probability column must keep one stable meaning."],
		explanation: "The encoder stores sorted unique training labels. Reusing it ensures every later one-hot or probability column refers to the same category even if a new array omits one category."
	}),
	notebookQuestion({
		id: "softmax-shapes",
		title: "Check Softmax Parameter Shapes",
		prompt: "Follow matrix multiplication through a model with n observations, m features, and k classes.",
		instructions: "Broadcasting adds one k-entry intercept row to every observation.",
		datasetId: "softmaxNotebook",
		parts: [part("coefficient-shape", "What is the shape of `self.coef`?", "m-k", [
			[
				"m-k",
				"`(m, k)`",
				"`(n, m) @ (m, k)` produces one k-score row per observation."
			],
			[
				"k-m",
				"`(k, m)`",
				"Its inner dimension would not align with X as written."
			],
			[
				"n-k",
				"`(n, k)`",
				"That is the score/probability shape, not a parameter shape."
			]
		]), part("probability-shape", "What is the shape of `predict_proba(X)`?", "n-k", [
			[
				"n-k",
				"`(n, k)`",
				"Each observation receives one probability per class."
			],
			[
				"n-m",
				"`(n, m)`",
				"Feature count does not determine output class count."
			],
			[
				"k-only",
				"`(k,)`",
				"That would describe only one observation."
			]
		])],
		hints: ["Apply the matrix multiplication shape rule.", "There is one output row per input row."],
		explanation: "An m-by-k coefficient matrix turns each m-feature row into k class scores, so both scores and probabilities have shape n by k."
	}),
	notebookQuestion({
		id: "softmax-normalization",
		title: "Normalize and Predict Classes",
		prompt: "Read the axis used by softmax and the mapping from a maximum column to a label.",
		instructions: "Each row represents one observation.",
		datasetId: "softmaxNotebook",
		parts: [part("normalization-axis", "Why does the denominator sum with `axis=1`?", "row-sum-one", [
			[
				"row-sum-one",
				"It makes each observation’s class probabilities sum to 1",
				"Axis 1 reduces across the class columns within each row."
			],
			[
				"column-sum-one",
				"It makes each class column sum to 1 across the dataset",
				"That would normalize across observations."
			],
			[
				"single-number",
				"It produces one denominator for the whole matrix",
				"An axis-specific reduction returns one value per row."
			]
		]), part("prediction-map", "After `argmax(probs, axis=1)`, how are class labels recovered?", "categories-index", [
			[
				"categories-index",
				"`self.encoder.categories[indices]`",
				"The maximum column index selects its stored category."
			],
			[
				"return-indices",
				"The numeric indices are returned directly",
				"The notebook maps them back to original labels."
			],
			[
				"refit-encoder",
				"The encoder is refit on the indices",
				"Prediction does not alter the encoder."
			]
		])],
		hints: ["Axis 1 runs horizontally across class columns.", "The encoder records what each column means."],
		explanation: "Softmax normalizes each score row independently. The largest probability column is an integer position, which is mapped back through the fitted category array."
	}),
	notebookQuestion({
		id: "softmax-loss-gradient",
		title: "Audit the Multiclass Loss and Intercept Gradient",
		prompt: "Compare the shapes implied by categorical cross entropy with the exact intercept-gradient line.",
		instructions: "Let residuals have shape `(batch_size, k)`.",
		datasetId: "softmaxNotebook",
		parts: [part("loss-selection", "Why does `Y * np.log(probs)` retain only the assigned class contribution in each row?", "one-hot-mask", [
			[
				"one-hot-mask",
				"Y is one-hot, so all non-assigned class entries are multiplied by zero",
				"Only the true-category column contains a one."
			],
			[
				"argmax-first",
				"`argmax` runs before multiplication",
				"CEloss does not call argmax."
			],
			[
				"logs-zero",
				"All nonmaximum log probabilities are zero",
				"Their logs are generally negative, not zero."
			]
		]), part("actual-intercept-gradient", "What shape does the notebook’s `np.mean(residuals)` return?", "scalar", [
			[
				"scalar",
				"A scalar",
				"With no axis argument, NumPy averages every entry."
			],
			[
				"k-vector",
				"A `(k,)` vector",
				"That would require `np.mean(residuals, axis=0)`."
			],
			[
				"batch-vector",
				"A `(batch_size,)` vector",
				"That would require reducing across class columns."
			]
		])],
		hints: ["One-hot rows contain exactly one 1.", "Check the default behavior of `np.mean` without an axis."],
		explanation: "One-hot multiplication selects each row’s assigned-class log probability. The supplied fit code computes a scalar intercept gradient, which broadcasts equally to every class; a class-specific gradient would average residuals along axis 0."
	})
];
function assignment(input) {
	return {
		id: input.id,
		displayNumber: input.displayNumber,
		version: 1,
		title: input.title,
		topic: input.topic,
		description: input.description,
		published: true,
		questions: [...input.questions, input.lab]
	};
}
//#endregion
//#region src/data/assignments.ts
var assignmentRegistry = [
	numpyAssignment,
	pcaAssignment,
	kmeansAssignment,
	knnAssignment,
	decisionTreeAssignment,
	randomForestAssignment,
	...[
		assignment({
			id: "linear-regression",
			displayNumber: 5,
			title: "Linear Regression",
			topic: "Regression",
			description: "Read endpoint and least-squares implementations, track feature-matrix shapes, and interpret RSS and MSE.",
			questions: linearRegressionQuestions,
			lab: linearRegressionNotebookLab
		}),
		assignment({
			id: "polynomial-regression",
			displayNumber: 6,
			title: "Polynomial Regression",
			topic: "Feature Engineering",
			description: "Trace scaling and polynomial feature construction, then connect engineered powers to nonlinear predictions.",
			questions: polynomialRegressionQuestions,
			lab: polynomialRegressionNotebookLab
		}),
		assignment({
			id: "overfitting",
			displayNumber: 7,
			title: "Overfitting",
			topic: "Model Evaluation",
			description: "Audit train/test preprocessing, polynomial complexity, and training-versus-testing error directly from the notebook.",
			questions: overfittingQuestions,
			lab: overfittingNotebookLab
		}),
		assignment({
			id: "gradient-descent",
			displayNumber: 8,
			title: "Gradient Descent",
			topic: "Optimization",
			description: "Trace simultaneous gradient updates and the full-dataset GDRegressor implementation for mean squared error.",
			questions: gradientDescentQuestions,
			lab: gradientDescentNotebookLab
		}),
		assignment({
			id: "batch-gradient-descent",
			displayNumber: 9,
			title: "Batch Gradient Descent",
			topic: "Optimization",
			description: "Follow reproducible shuffling, batch slices, gradient scaling, and the relationship among full, batch, and stochastic updates.",
			questions: batchGradientDescentQuestions,
			lab: batchGradientDescentNotebookLab
		}),
		assignment({
			id: "regularization",
			displayNumber: 10,
			title: "Regularization",
			topic: "Generalization",
			description: "Compare L1 and L2 updates, evaluate the overfitting tradeoff, and trace L1-guided feature selection.",
			questions: regularizationQuestions,
			lab: regularizationNotebookLab
		}),
		assignment({
			id: "logistic-regression",
			displayNumber: 11,
			title: "Logistic Regression",
			topic: "Binary Classification",
			description: "Connect sigmoid probabilities, cross-entropy gradients, thresholded predictions, and the Iris decision boundary.",
			questions: logisticRegressionQuestions,
			lab: logisticRegressionNotebookLab
		}),
		assignment({
			id: "softmax",
			displayNumber: 12,
			title: "Softmax",
			topic: "Multiclass Classification",
			description: "Trace one-hot encoding, multiclass parameter shapes, row-wise softmax probabilities, and categorical cross entropy.",
			questions: softmaxQuestions,
			lab: softmaxNotebookLab
		})
	]
];
var publishedAssignments = assignmentRegistry.filter((assignment) => assignment.published);
var assignmentsById = Object.fromEntries(assignmentRegistry.map((assignment) => [assignment.id, assignment]));
//#endregion
//#region gradescope/src/grader.ts
var _process$argv$;
var SUBMISSION_FORMAT_VERSION = 2;
var CODE_LAB_FORMAT_VERSION = 1;
var MAX_CONFIG_BYTES = 64 * 1024;
var MAX_SUBMISSION_BYTES = 5 * 1024 * 1024;
var MAX_JSON_NODES = 15e4;
var MAX_JSON_DEPTH = 80;
function isRecord(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
/**
* Keep the exported pure grader safe even when it is called directly rather
* than through the byte-capped CLI. This also rejects values that JSON cannot
* represent, such as cycles, undefined, and non-finite numbers.
*/
function isSafeJsonValue(value, depth = 0, budget = {
	nodes: 0,
	seen: /* @__PURE__ */ new WeakSet()
}) {
	budget.nodes += 1;
	if (budget.nodes > MAX_JSON_NODES || depth > MAX_JSON_DEPTH) return false;
	if (value === null || typeof value === "string" || typeof value === "boolean") return true;
	if (typeof value === "number") return Number.isFinite(value);
	if (typeof value !== "object") return false;
	if (budget.seen.has(value)) return false;
	budget.seen.add(value);
	let safe;
	if (Array.isArray(value)) safe = value.every((entry) => isSafeJsonValue(entry, depth + 1, budget));
	else safe = Object.entries(value).every(([, entry]) => isSafeJsonValue(entry, depth + 1, budget));
	budget.seen.delete(value);
	return safe;
}
function normalizeConfig(config) {
	if (typeof config === "string") return config.length > 0 ? { assignmentId: config } : null;
	if (!isRecord(config) || typeof config.assignmentId !== "string") return null;
	if (config.assignmentVersion !== void 0 && (!Number.isInteger(config.assignmentVersion) || Number(config.assignmentVersion) < 1)) return null;
	return {
		assignmentId: config.assignmentId,
		...config.assignmentVersion === void 0 ? {} : { assignmentVersion: Number(config.assignmentVersion) }
	};
}
function getPublishedAssignmentSummaries() {
	return publishedAssignments.map((assignment) => ({
		id: assignment.id,
		displayNumber: assignment.displayNumber,
		title: assignment.title,
		version: assignment.version,
		questionCount: assignment.questions.length
	}));
}
var listAssignments = getPublishedAssignmentSummaries;
function invalidResults(message) {
	return {
		score: 0,
		output: message,
		tests: [{
			name: "Submission validation",
			score: 0,
			max_score: 100,
			status: "failed",
			output: message
		}]
	};
}
function validateSubmissionEnvelope(raw, assignment) {
	if (!isSafeJsonValue(raw) || !isRecord(raw)) return { error: "The uploaded submission is not a valid, safely sized JSON object." };
	if (raw.formatVersion !== SUBMISSION_FORMAT_VERSION) return { error: `Submission format version ${SUBMISSION_FORMAT_VERSION} is required.` };
	if (raw.assignmentId !== assignment.id) return { error: `This autograder accepts only the ${assignment.id} assignment.` };
	if (raw.assignmentVersion !== assignment.version) return { error: `Assignment version ${assignment.version} is required; export a fresh submission from the current app.` };
	if (!Array.isArray(raw.questions)) return { error: "The submission must contain a questions array." };
	const expectedIds = assignment.questions.map((question) => question.id);
	const expectedIdSet = new Set(expectedIds);
	const questionsById = /* @__PURE__ */ new Map();
	for (const rawQuestion of raw.questions) {
		if (!isRecord(rawQuestion) || typeof rawQuestion.id !== "string" || !Object.prototype.hasOwnProperty.call(rawQuestion, "latestAnswer") || !Array.isArray(rawQuestion.attemptHistory)) return { error: "Every question record must include an ID, latestAnswer, and attemptHistory." };
		if (!expectedIdSet.has(rawQuestion.id) || questionsById.has(rawQuestion.id)) return { error: "The submission question IDs do not exactly match this assignment and version." };
		questionsById.set(rawQuestion.id, rawQuestion);
	}
	if (questionsById.size !== expectedIds.length) return { error: "The submission question IDs do not exactly match this assignment and version." };
	return {
		envelope: raw,
		questionsById
	};
}
function validatorAccepts(question, answer) {
	try {
		return question.validator(answer).correct === true;
	} catch {
		return false;
	}
}
function makeTest(name, earned, maxScore, correctOutput = "Correct.") {
	return {
		name,
		score: earned ? maxScore : 0,
		max_score: maxScore,
		status: earned ? "passed" : "failed",
		output: earned ? correctOutput : "Incorrect or missing raw answer."
	};
}
function gradeMultipleChoice(question, rawAnswer, questionPoints) {
	const selectedIds = isRecord(rawAnswer) && isRecord(rawAnswer.selectedIds) ? rawAnswer.selectedIds : {};
	const unitPoints = questionPoints / question.parts.length;
	return question.parts.map((part) => {
		const earned = validatorAccepts(question, { selectedIds: Object.fromEntries(question.parts.map((candidatePart) => [candidatePart.id, candidatePart.id === part.id ? selectedIds[part.id] : candidatePart.correctOptionId])) });
		return makeTest(`${question.title} — ${part.prompt}`, earned, unitPoints);
	});
}
function isCodeLabEnvelope(question, rawAnswer) {
	return isRecord(rawAnswer) && rawAnswer.formatVersion === CODE_LAB_FORMAT_VERSION && rawAnswer.questionId === question.id && rawAnswer.variantId === question.variantId && isRecord(rawAnswer.stages);
}
function gradeCodeLab(question, rawAnswer, questionPoints) {
	const fields = question.stages.flatMap((stage) => stage.fields.map((field) => ({
		stage,
		field
	})));
	const unitPoints = questionPoints / fields.length;
	const envelopeIsValid = isCodeLabEnvelope(question, rawAnswer);
	return fields.map(({ stage, field }) => {
		const submittedStage = (envelopeIsValid ? rawAnswer.stages : {})[stage.id];
		const submittedValue = isRecord(submittedStage) ? submittedStage[field.id] : void 0;
		const stages = Object.fromEntries(question.stages.map((candidateStage) => [candidateStage.id, Object.fromEntries(candidateStage.fields.map((candidateField) => [candidateField.id, candidateStage.id === stage.id && candidateField.id === field.id ? submittedValue : candidateField.correctOptionId]))]));
		const candidate = {
			formatVersion: CODE_LAB_FORMAT_VERSION,
			questionId: question.id,
			variantId: question.variantId,
			stages
		};
		const earned = envelopeIsValid && validatorAccepts(question, candidate);
		return makeTest(`${question.title} — ${stage.title}: ${field.label}`, earned, unitPoints);
	});
}
function rawAnswers(questionExport) {
	const answers = [];
	for (const attempt of questionExport.attemptHistory) if (isRecord(attempt) && Object.prototype.hasOwnProperty.call(attempt, "answer")) answers.push(attempt.answer);
	answers.push(questionExport.latestAnswer);
	return answers;
}
function stripKmeansReferenceOverrides(answer) {
	if (!isRecord(answer)) return answer;
	const canonicalAnswer = { ...answer };
	delete canonicalAnswer.referenceCentroids;
	delete canonicalAnswer.referenceAssignments;
	return canonicalAnswer;
}
function phasesForQuestion(question) {
	if (question.kind === "tableEntry") return [
		"centeredData",
		"covariance",
		"direction"
	].map((step) => ({
		name: step,
		matches: (answer) => isRecord(answer) && answer.step === step
	}));
	if (question.kind === "kmeans2d") {
		if (question.interactionMode === "lloydIteration") {
			var _dataset$iterationAss, _dataset$iterationAss2, _dataset$iterationCen, _dataset$iterationCen2;
			const dataset = kmeansInteractiveDatasets[question.datasetId];
			const assignmentCount = (_dataset$iterationAss = dataset === null || dataset === void 0 || (_dataset$iterationAss2 = dataset.iterationAssignments) === null || _dataset$iterationAss2 === void 0 ? void 0 : _dataset$iterationAss2.length) !== null && _dataset$iterationAss !== void 0 ? _dataset$iterationAss : 0;
			const centroidCount = (_dataset$iterationCen = dataset === null || dataset === void 0 || (_dataset$iterationCen2 = dataset.iterationCentroids) === null || _dataset$iterationCen2 === void 0 ? void 0 : _dataset$iterationCen2.length) !== null && _dataset$iterationCen !== void 0 ? _dataset$iterationCen : 0;
			if (assignmentCount === 0 || assignmentCount !== centroidCount) throw new Error(`No canonical Lloyd sequence for ${question.datasetId}.`);
			return Array.from({ length: assignmentCount }, (_, iteration) => iteration).flatMap((iteration) => ["assignments", "centroids"].map((step) => ({
				name: `iteration ${iteration + 1} ${step}`,
				matches: (answer) => isRecord(answer) && answer.step === step && answer.iteration === iteration
			})));
		}
		if (question.interactionMode === "metricComparison") return ["euclidean", "manhattan"].map((step) => ({
			name: `${step} assignments`,
			matches: (answer) => isRecord(answer) && answer.step === step
		}));
		return null;
	}
	if (question.kind === "knn2d") {
		const dataset = knnInteractiveDatasets[question.datasetId];
		if (question.interactionMode === "predictSequence") {
			if (!dataset || dataset.kind !== "predictSequence") throw new Error(`No canonical prediction sequence for ${question.datasetId}.`);
			return dataset.kSequence.map((k, step) => ({
				name: `k = ${k}`,
				matches: (answer) => isRecord(answer) && answer.step === step
			}));
		}
		if (question.interactionMode === "decisionBoundary") {
			if (!dataset || dataset.kind !== "decisionBoundary") throw new Error(`No canonical boundary sequence for ${question.datasetId}.`);
			return dataset.kSequence.map((k, step) => ({
				name: `k = ${k} boundary`,
				matches: (answer) => isRecord(answer) && answer.step === step
			}));
		}
		if (question.interactionMode === "scalingTrap") return ["raw", "normalized"].map((step) => ({
			name: step === "raw" ? "unscaled prediction" : "normalized prediction",
			matches: (answer) => isRecord(answer) && answer.step === step
		}));
		if (question.interactionMode === "metricComparison") return ["euclidean", "manhattan"].map((step) => ({
			name: `${step} prediction`,
			matches: (answer) => isRecord(answer) && answer.step === step
		}));
	}
	return null;
}
function gradeProgressiveQuestion(question, questionExport, phases, questionPoints) {
	const answers = rawAnswers(questionExport);
	const unitPoints = questionPoints / phases.length;
	const isKmeans = question.kind === "kmeans2d";
	return phases.map((phase) => {
		const earned = answers.filter(phase.matches).some((answer) => validatorAccepts(question, isKmeans ? stripKmeansReferenceOverrides(answer) : answer));
		return makeTest(`${question.title} — ${phase.name}`, earned, unitPoints);
	});
}
function gradeQuestion(question, questionExport, questionPoints) {
	if (question.kind === "multipleChoice") return gradeMultipleChoice(question, questionExport.latestAnswer, questionPoints);
	if (question.kind === "codeLab") return gradeCodeLab(question, questionExport.latestAnswer, questionPoints);
	const phases = phasesForQuestion(question);
	if (phases) return gradeProgressiveQuestion(question, questionExport, phases, questionPoints);
	const rawAnswer = question.kind === "kmeans2d" ? stripKmeansReferenceOverrides(questionExport.latestAnswer) : questionExport.latestAnswer;
	return [makeTest(question.title, validatorAccepts(question, rawAnswer), questionPoints)];
}
function normalizeHundredPointMaximum(tests) {
	if (tests.length === 0) return tests;
	const normalized = tests.map((test) => ({ ...test }));
	const lastIndex = normalized.length - 1;
	const finalMaximum = 100 - normalized.slice(0, lastIndex).reduce((sum, test) => sum + test.max_score, 0);
	const finalTest = normalized[lastIndex];
	finalTest.max_score = finalMaximum;
	if (finalTest.status === "passed") finalTest.score = finalMaximum;
	return normalized;
}
/** Grade one app export using the published assignment's exact validators. */
function gradeSubmission(configInput, submissionInput) {
	try {
		const config = normalizeConfig(configInput);
		if (!config) return invalidResults("The autograder assignment configuration is invalid.");
		const assignment = assignmentsById[config.assignmentId];
		if (!assignment || !assignment.published) return invalidResults(`Unknown or unpublished assignment: ${config.assignmentId}.`);
		if (config.assignmentVersion !== void 0 && config.assignmentVersion !== assignment.version) return invalidResults(`This autograder was configured for assignment version ${config.assignmentVersion}, but the bundled assignment is version ${assignment.version}.`);
		const validated = validateSubmissionEnvelope(submissionInput, assignment);
		if ("error" in validated) return invalidResults(validated.error);
		const questionPoints = 100 / assignment.questions.length;
		const tests = normalizeHundredPointMaximum(assignment.questions.flatMap((question) => gradeQuestion(question, validated.questionsById.get(question.id), questionPoints)));
		const allPassed = tests.every((test) => test.status === "passed");
		const rawScore = tests.reduce((sum, test) => sum + test.score, 0);
		return {
			score: allPassed ? 100 : Math.max(0, Math.min(100, rawScore)),
			tests,
			output: `Graded ${assignment.questions.length} questions for ${assignment.title} (version ${assignment.version}). Exported status and attempt outcomes were ignored.`
		};
	} catch {
		return invalidResults("The submission could not be graded because its structure is malformed.");
	}
}
var grade = gradeSubmission;
function readJsonFile(path$1, maxBytes, label) {
	if ((0, fs.statSync)(path$1).size > maxBytes) throw new Error(`${label} exceeds the ${Math.floor(maxBytes / 1024)} KiB size limit.`);
	try {
		return JSON.parse((0, fs.readFileSync)(path$1, "utf8"));
	} catch {
		throw new Error(`${label} is not valid JSON.`);
	}
}
function parseCliPaths(args) {
	var _config, _submission, _ref, _ref2, _results;
	const positionals = [];
	let config;
	let submission;
	let results;
	for (let index = 0; index < args.length; index += 1) {
		const argument = args[index];
		const next = args[index + 1];
		if (argument === "--config" || argument === "--assignment-config") {
			config = next;
			index += 1;
		} else if (argument === "--submission") {
			submission = next;
			index += 1;
		} else if (argument === "--results") {
			results = next;
			index += 1;
		} else if (!argument.startsWith("--")) positionals.push(argument);
	}
	return {
		config: (_config = config) !== null && _config !== void 0 ? _config : positionals[0],
		submission: (_submission = submission) !== null && _submission !== void 0 ? _submission : positionals[1],
		results: (_ref = (_ref2 = (_results = results) !== null && _results !== void 0 ? _results : positionals[2]) !== null && _ref2 !== void 0 ? _ref2 : process.env.GRADESCOPE_RESULTS_PATH) !== null && _ref !== void 0 ? _ref : "/autograder/results/results.json"
	};
}
function writeResults(path$2, results) {
	(0, fs.mkdirSync)((0, path.dirname)(path$2), { recursive: true });
	(0, fs.writeFileSync)(path$2, `${JSON.stringify(results, null, 2)}\n`, "utf8");
}
/**
* CLI contract:
*   grader.cjs <assignment-config.json> <submission.json> <results.json>
* or the equivalent --config/--submission/--results flags.
*/
function runCli(args = process.argv.slice(2)) {
	if (args.includes("--list-assignments")) {
		process.stdout.write(`${JSON.stringify(getPublishedAssignmentSummaries(), null, 2)}\n`);
		return 0;
	}
	const paths = parseCliPaths(args);
	let results;
	try {
		if (!paths.config || !paths.submission) throw new Error("The assignment config and submission paths are required.");
		results = gradeSubmission((0, fs.existsSync)(paths.config) ? readJsonFile(paths.config, MAX_CONFIG_BYTES, "Assignment configuration") : paths.config, readJsonFile(paths.submission, MAX_SUBMISSION_BYTES, "Submission"));
	} catch (error) {
		results = invalidResults(error instanceof Error ? error.message : "Malformed autograder input.");
	}
	try {
		writeResults(paths.results, results);
		return 0;
	} catch (error) {
		const fallback = "results.json";
		if (paths.results !== fallback) try {
			writeResults(fallback, results);
			process.stderr.write(`Could not write ${paths.results}; wrote ${fallback} instead.\n`);
			return 0;
		} catch {}
		const message = error instanceof Error ? error.message : "Unknown write error.";
		process.stderr.write(`Could not write Gradescope results: ${message}\n`);
		return 1;
	}
}
var directlyExecutedName = (0, path.basename)((_process$argv$ = process.argv[1]) !== null && _process$argv$ !== void 0 ? _process$argv$ : "");
if (/^grader\.(?:c?js|mjs|ts)$/.test(directlyExecutedName)) process.exitCode = runCli();
//#endregion
exports.getPublishedAssignmentSummaries = getPublishedAssignmentSummaries;
exports.grade = grade;
exports.gradeSubmission = gradeSubmission;
exports.listAssignments = listAssignments;
exports.runCli = runCli;
exports.stripKmeansReferenceOverrides = stripKmeansReferenceOverrides;
